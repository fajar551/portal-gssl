<?php

namespace Modules\Registrar\OpenProvider\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use Modules\Registrar\OpenProvider\API\Domain;
use OpenProvider\API\DomainRegistration;
use OpenProvider\API\APITools;
use Illuminate\Support\Facades\DB;
use Modules\Registrar\OpenProvider\API\ApiClient;
use Modules\Registrar\OpenProvider\API\ApiHelper;
use Modules\Registrar\OpenProvider\API\DomainRegistration as APIDomainRegistration;

class OpenProviderController extends Controller
{
    protected $apiHelper;
    protected $domain;

    public function __construct()
    {
        // Ambil kredensial dari database
        $username = DB::table('tblregistrars')
            ->where('registrar', 'openprovider')
            ->where('setting', 'Username')
            ->value('value');

        $password = DB::table('tblregistrars')
            ->where('registrar', 'openprovider')
            ->where('setting', 'Password')
            ->value('value');

        if (!$username || !$password) {
            throw new \Exception('Kredensial OpenProvider tidak ditemukan');

            $credentials = (object)[
                'username' => $username,
                'password' => $password
            ];
            // dd($credentials); // untuk melihat hasilnya

            if (!$credentials) {
                throw new \Exception('Kredensial OpenProvider tidak ditemukan');
            }

            // Inisialisasi API Interface
            $apiClient = new ApiClient($username, $password);

            
        }

         // Inisialisasi API Helper
    $this->apiHelper = new ApiHelper(new ApiClient($username, $password));
    
        // Debugging
    if ($this->apiHelper) {
        \Log::info('API Helper initialized successfully.');
    } else {
        \Log::error('Failed to initialize API Helper.');
    }
    
    }

    public function registerOpenProvider(Request $request)
    {
        try {
            // Validasi input
            $validated = $request->validate([
                'sld' => 'required|string',
                'tld' => 'required|string',
                'period' => 'required|integer',
                'nameservers' => 'required|array',
                'customer' => 'required|array',
                'dns_management' => 'boolean',
                'is_idn' => 'boolean',
                'idn_language' => 'string|nullable',
                'premium_enabled' => 'boolean',
                'premium_cost' => 'numeric|nullable',
                'id_protection' => 'boolean',
                'dns_template' => 'string|nullable',
                'request_trustee_service' => 'array|nullable'
            ]);

            // Setup domain
            $domain = $this->domain;
            $domain->extension = $validated['tld'];
            $domain->name = $validated['sld'];

            // Setup nameservers
            $nameServers = APITools::createNameserversArray([
                'ns1' => $validated['nameservers'][0],
                'ns2' => $validated['nameservers'][1],
                'ns3' => $validated['nameservers'][2] ?? null,
                'ns4' => $validated['nameservers'][3] ?? null,
            ], $this->apiHelper);

            // Buat domain registration request
            $domainRegistration = new APIDomainRegistration();
            $domainRegistration->domain = $domain;
            $domainRegistration->period = $validated['period'];
            $domainRegistration->nameServers = $nameServers;

            // Set customer handles
            $domainRegistration->ownerHandle = $validated['customer']['owner_handle'];
            $domainRegistration->adminHandle = $validated['customer']['admin_handle'];
            $domainRegistration->techHandle = $validated['customer']['tech_handle'];
            $domainRegistration->billingHandle = $validated['customer']['billing_handle'];

            // Handle IDN domains
            if ($validated['is_idn'] ?? false && !empty($validated['idn_language'])) {
                $domainRegistration->domain->name = idn_to_ascii($domainRegistration->domain->name);
            }

            // Handle premium domains
            if (($validated['premium_enabled'] ?? false) && !empty($validated['premium_cost'])) {
                $domainRegistration->acceptPremiumFee = true;
            }

            // Set additional options
            $domainRegistration->dnsmanagement = $validated['dns_management'] ?? false;
            $domainRegistration->isDnssecEnabled = $validated['dns_management'] ?? false;
            $domainRegistration->isPrivateWhoisEnabled = $validated['id_protection'] ?? false;

            // Handle DNS template
            if (!empty($validated['dns_template'])) {
                $domainRegistration->nsTemplateName = $validated['dns_template'];
            }

            // Handle trustee service
            if (!empty($validated['request_trustee_service'])) {
                $trusteeServiceTlds = array_map(function ($tld) {
                    return ltrim($tld, '.');
                }, $validated['request_trustee_service']);

                if (in_array($domainRegistration->domain->extension, $trusteeServiceTlds)) {
                    $domainRegistration->useDomicile = true;
                }
            }

            // Delay 2 detik untuk memastikan contact sudah diproses
            sleep(2);

            // Register domain
            $result = $this->apiHelper->createDomain($domainRegistration);

            return response()->json([
                'success' => true,
                'message' => 'Domain berhasil didaftarkan',
                'data' => $result
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Gagal mendaftarkan domain: ' . $e->getMessage()
            ], 500);
        }
    }

    public function lockDomainOpenprovider(Request $request)
    {
        try {
            $validated = $request->validate([
                'sld' => 'required|string',
                'tld' => 'required|string'
            ]);
 
            \Log::info('Locking domain:', $validated);
 
            // Inisialisasi objek Domain
            $domain = new Domain();
            $domain->extension = $validated['tld'];
            $domain->name = $validated['sld'];
 
            // Mengunci domain
            $result = $this->apiHelper->lockDomain($domain);
 
            \Log::info('Domain locked successfully:', ['result' => $result]);
 
            return response()->json([
                'success' => true,
                'message' => 'Domain berhasil dikunci',
                'data' => $result
            ]);
        } catch (\Exception $e) {
            \Log::error('Error locking domain:', ['error' => $e->getMessage()]);
            return response()->json([
                'success' => false,
                'message' => 'Gagal mengunci domain: ' . $e->getMessage()
            ], 500);
        }
    }

    public function unlockDomainOpenprovider(Request $request)
    {
        try {
            $validated = $request->validate([
                'sld' => 'required|string',
                'tld' => 'required|string'
            ]);

            \Log::info('Unlocking domain:', $validated);

            $domain = new Domain();
            $domain->extension = $validated['tld'];
            $domain->name = $validated['sld'];

            $result = $this->apiHelper->unlockDomain($domain);

            \Log::info('Domain unlocked successfully:', ['result' => $result]);

            return response()->json([
                'success' => true,
                'message' => 'Domain berhasil dibuka kuncinya',
                'data' => $result
            ]);
        } catch (\Exception $e) {
            \Log::error('Error unlocking domain:', ['error' => $e->getMessage()]);
            return response()->json([
                'success' => false,
                'message' => 'Gagal membuka kunci domain: ' . $e->getMessage()
            ], 500);
        }
    }

    /**
     * Cek ketersediaan domain
     */
    public function checkDomain(Request $request)
    {
        try {
            $validated = $request->validate([
                'sld' => 'required|string',
                'tld' => 'required|string'
            ]);

            $domain = $this->domain;
            $domain->extension = $validated['tld'];
            $domain->name = $validated['sld'];

            $result = $this->apiHelper->checkDomain($domain);

            return response()->json([
                'success' => true,
                'data' => $result
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Gagal mengecek domain: ' . $e->getMessage()
            ], 500);
        }
    }

    public function output()
    {
        // Ambil kredensial dari database
        $username = DB::table('tblregistrars')
            ->where('registrar', 'openprovider')
            ->where('setting', 'Username')
            ->value('value');

        $password = DB::table('tblregistrars')
            ->where('registrar', 'openprovider')
            ->where('setting', 'Password')
            ->value('value');

        if (!$username || !$password) {
            throw new \Exception('Kredensial OpenProvider tidak ditemukan');
        }

        $credentials = (object)[
            'username' => $username,
            'password' => $password
        ];

        // dd($credentials); // untuk melihat hasilnya

        // Atau jika ingin menampilkan di view:
        return view('openprovider::test', compact('credentials'));
    }
}