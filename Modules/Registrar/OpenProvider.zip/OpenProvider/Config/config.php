<?php

return [
    'name' => 'OpenProvider'
];
