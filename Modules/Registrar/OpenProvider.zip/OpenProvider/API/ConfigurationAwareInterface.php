<?php

// namespace OpenProvider\API;
namespace Modules\Registrar\OpenProvider\API;


interface ConfigurationAwareInterface
{
    /**
     * @return ConfigurationInterface
     */
    public function getConfiguration(): ConfigurationInterface;
}