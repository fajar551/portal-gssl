<?php

// namespace OpenProvider\API;
namespace Modules\Registrar\OpenProvider\API;

class Configuration implements ConfigurationInterface
{
    private $config;

    public function __construct(array $config)
    {
        $this->config = $config;
    }

    public function get($key = null)
    {
        if ($key === null) {
            return $this->config;
        }
        return $this->config[$key] ?? null;
    }

    public function setHost($host): void
    {
        $this->config['host'] = $host;
    }
    public function getHost(): string
    {
        return $this->config['host'] ?? '';
    }
    public function setUserName($username): void
    {
        $this->config['username'] = $username;
    }
    public function getUserName(): string
    {
        return $this->config['username'] ?? '';
    }
    public function setPassword($password): void
    {
        $this->config['password'] = $password;
    }
    public function getPassword(): string
    {
        return $this->config['password'] ?? '';
    }
    public function setDebug($debug): void
    {
        $this->config['debug'] = $debug;
    }
    public function getDebug(): bool
    {
        return $this->config['debug'] ?? false;
    }
    public function setToken($token): void
    {
        $this->config['token'] = $token;
    }
    public function getToken(): string
    {
        return $this->config['token'] ?? '';
    }
}