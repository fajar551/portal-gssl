<?php

// namespace OpenProvider\API;
namespace Modules\Registrar\OpenProvider\API;


interface ApiCallerInterface
{
    /**
     * @param string $cmd
     * @param array $args
     * @return ResponseInterface
     */
    public function call(string $cmd, array $args = []): ResponseInterface;
}