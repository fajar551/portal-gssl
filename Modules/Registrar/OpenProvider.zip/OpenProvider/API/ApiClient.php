<?php

// namespace OpenProvider\API;
namespace Modules\Registrar\OpenProvider\API;


class ApiClient implements ApiInterface
{
    private $username;
    private $password;
    private $url;

    public function __construct($username, $password, $url = 'https://api.openprovider.eu')
    {
        $this->username = $username;
        $this->password = $password;
        $this->url = $url;
    }

    public function call(string $command, array $args = []): \Modules\Registrar\OpenProvider\API\ApiResponse
    {
        $client = new \GuzzleHttp\Client();

        $response = $client->post($this->url, [
            'json' => [
                'username' => $this->username,
                'password' => $this->password,
                'command' => $command,
                'args' => $args
            ]
        ]);

        return new \Modules\Registrar\OpenProvider\API\ApiResponse($response);
    }

    public function setConfiguration(array $config): void
    {
        if (isset($config['username'])) {
            $this->username = $config['username'];
        }
        if (isset($config['password'])) {
            $this->password = $config['password'];
        }
        if (isset($config['url'])) {
            $this->url = $config['url'];
        }
    }

    /**
     * @param string|null $key
     * @return string|array|null
     */
    public function getConfiguration(): ConfigurationInterface
    {
        return new Configuration([
            'username' => $this->username,
            'password' => $this->password,
            'url' => $this->url
        ]);
    }
}