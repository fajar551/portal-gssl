<?php
namespace Modules\Registrar\OpenProvider\API;

/**
 * Class DomainTransfer
 * OpenProvider Registrar module
 *
 * @copyright Copyright (c) Openprovider 2018
 */

class DomainTransfer extends \Modules\Registrar\OpenProvider\API\DomainRegistration
{
    public $authCode;
}