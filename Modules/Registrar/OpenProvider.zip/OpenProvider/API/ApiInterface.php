<?php

// namespace OpenProvider\API;
namespace Modules\Registrar\OpenProvider\API;

interface ApiInterface extends ApiCallerInterface, ConfigurationAwareInterface
{
}