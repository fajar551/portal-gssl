<?php

namespace Modules\Registrar\OpenProvider\API;

use GuzzleHttp\Client;
use GuzzleHttp\Exception\RequestException;

class ApiClient implements ApiInterface
{
    private $username;
    private $password;
    private $url;
    protected $client;

    public function __construct($username, $password, $url = 'https://api.openprovider.eu')
    {
        $this->username = $username;
        $this->password = $password;
        $this->url = $url;
    }

    public function get($endpoint, $params = [])
    {
        $response = $this->client->get($endpoint, ['query' => $params]);
        return json_decode($response->getBody(), true);
    }

    public function call(string $command, array $args = []): ApiResponse
    {
        $client = new Client();

        try {
            \Log::info('Sending API request', [
                'url' => $this->url,
                'command' => $command,
                'args' => $args
            ]);

            $response = $client->post($this->url, [
                'json' => [
                    'username' => $this->username,
                    'password' => $this->password,
                    'command' => $command,
                    'args' => $args
                ]
            ]);

            $responseBody = $response->getBody()->getContents();
            \Log::info('API Response', ['response' => $responseBody]);

            $responseData = json_decode($responseBody, true);

            if ($responseData === null) {
                \Log::error('Failed to parse API response', ['response' => $responseBody]);
                throw new \Exception('Invalid JSON response');
            }

            return new ApiResponse($responseData);

        } catch (RequestException $e) {
            \Log::error('API Request failed', ['error' => $e->getMessage()]);
            return new ApiResponse(['status' => false, 'message' => $e->getMessage()]);
        }
    }

    public function setConfiguration(array $config): void
    {
        if (isset($config['username'])) {
            $this->username = $config['username'];
        }
        if (isset($config['password'])) {
            $this->password = $config['password'];
        }
        if (isset($config['url'])) {
            $this->url = $config['url'];
        }
    }

    /**
     * @param string|null $key
     * @return string|array|null
     */
    public function getConfiguration(): ConfigurationInterface
    {
        return new Configuration([
            'username' => $this->username,
            'password' => $this->password,
            'url' => $this->url
        ]);
    }
}