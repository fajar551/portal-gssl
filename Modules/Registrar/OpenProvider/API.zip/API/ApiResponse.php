<?php

// namespace OpenProvider\API;
namespace Modules\Registrar\OpenProvider\API;


class ApiResponse implements ResponseInterface
{
    // private $response;
    // private $data;
    // private $total;
    // private $code;
    // private $message;
    public $status;
       public $message;
       public $data;

       public function __construct(array $response)
       {
           $this->status = $response['status'] ?? false;
           $this->message = $response['message'] ?? 'Unknown error';
           $this->data = $response['data'] ?? [];
       }

    public function setData($data): void
    {
        $this->data = $data;
    }

    public function setTotal($total): void
    {
        $this->total = $total;
    }

    public function setCode($code): void
    {
        $this->code = $code;
    }

    public function setMessage($message): void
    {
        $this->message = $message;
    }

    public function getTotal(): int
    {
        return $this->total ?? 0;
    }

    public function isSuccess(): bool
    {
        return $this->response->getStatusCode() === 200;
    }

    public function getMessage(): string
    {
        return '';
    }

    public function getCode(): int
    {
        return $this->response->getStatusCode();
    }

    public function getData(): array
    {
        return json_decode($this->response->getBody(), true);
    }
    // ===================LKH DONE========================== //
}