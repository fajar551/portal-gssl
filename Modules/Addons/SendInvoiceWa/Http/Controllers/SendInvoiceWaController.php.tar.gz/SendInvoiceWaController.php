<?php

namespace Modules\Addons\SendInvoiceWa\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Helpers\InvoiceClass;

use Carbon\Carbon;
use App\Helpers\Client as HelpersClient;
use App\Helpers\Database;
use App\Helpers\Format;
use App\Models\Account;
use App\Models\Client;
use App\Models\Clientgroup;
use App\Models\Hosting;
use App\Models\Invoice;
use App\Models\Invoiceitem;
use App\Traits\DatatableFilter;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;
use App\Helpers\LogActivity;

class SendInvoiceWaController extends Controller
{

    use DatatableFilter;
    protected $prefix;

    public function __construct()
    {
        $this->middleware(['auth:admin']);
        $this->prefix = Database::prefix();
    }

    public function getLateClient()
    {
        $hostings = Hosting::where('domainstatus', 'Active')
            ->where('nextduedate', '<=', now())
            ->get();

        $userIds = $hostings->pluck('userid');
        $relIds = $hostings->pluck('id');

        $maxDueDates = Invoiceitem::whereIn('userid', $userIds)
            ->whereIn('relid', $relIds)
            ->groupBy(['userid', 'relid'])
            ->selectRaw('userid, relid, MAX(duedate) as max_duedate')
            ->get();

        $maxDueDatesFiltered = $maxDueDates->filter(function ($item) {
            return $item->max_duedate <= now()->subMonths(1);
        });

        $maxDueDatesFilteredReal = $maxDueDatesFiltered->filter(function ($item) {
            return $item->max_duedate >= now()->subMonths(4);
        });

        $invoices = Invoiceitem::whereIn('userid', $maxDueDatesFilteredReal->pluck('userid'))
            ->whereIn('relid', $maxDueDatesFilteredReal->pluck('relid'))
            ->whereIn('duedate', $maxDueDatesFilteredReal->pluck('max_duedate'))
            ->select('invoiceid', 'relid', 'duedate', 'userid')
            ->get();

        $invoicesFormatted = $invoices->reject(function ($item) {
            return $item->userid == 18; 
        })->map(function ($item) {
            $client = Client::find($item->userid);

            $fullName = $client ? $client->firstname . ' ' . $client->lastname : 'N/A';

            $email = $client ? $client->email : 'N/A';

            $linkAdmin = $client ? 'https://portal.relabs.id/admin/clients/clientsummary?userid=' . $item->userid : 'N/A';

            $lastInvoiceLink = 'https://portal.relabs.id/admin/billing/invoices/edit/' . $item->invoiceid;

            return [
                'Nama' => $fullName,
                'Email' => $email,
                'Link Admin' => $linkAdmin,
                'Last Invoice' => $lastInvoiceLink,
                'Last Due Date' => $item->duedate,
                'hostingid' => $item->relid,
                'invid' => $item->invoiceid,
                'uid' => $item->userid
            ];
        });

        dd($invoicesFormatted);


        // Create CSV content
        $csvContent = $invoicesFormatted->map(function ($row) {
            return implode(',', $row);
        })->prepend(implode(',', array_keys($invoicesFormatted->first())))->implode("\n");

        // Set headers for CSV download
        $headers = [
            'Content-Type' => 'text/csv',
            'Content-Disposition' => 'attachment; filename="late_clients.csv"',
        ];

        // Return CSV as response
        return response()->make($csvContent, 200, $headers);
    }

    public function resendInvoiceWA(Request $request)
    {
        if ($request->has('show_loading')) {
            return view('pages.billing.invoices.loading-wa');
        }

        $successCount = 0;
        $failedCount = 0;

        try {
            $invoice = DB::table("tblinvoices")->where(['id' => $request->invoiceid])->first();
            $user = DB::table("tblclients")->where(['id' => $invoice->userid])->first();

            $allitem = '';
            $selectinvoiceitemswa2 = "SELECT CONCAT(tblproducts.name, ' - ', tblhosting.domain) as service, tblinvoiceitems.amount, tblhosting.regdate, tblhosting.packageid FROM tblinvoiceitems, tblhosting, tblproducts WHERE tblinvoiceitems.relid = tblhosting.id AND tblhosting.packageid = tblproducts.id AND tblinvoiceitems.invoiceid = ? AND tblinvoiceitems.type IN ('Hosting')";
            $queryselectinvoiceitemswa2 = DB::select($selectinvoiceitemswa2, [$request->invoiceid]);
            $resultselectinvoiceitemsnumrowswa2 = count($queryselectinvoiceitemswa2);

            if ($resultselectinvoiceitemsnumrowswa2 > 0) {
                $customdata1 = [];
                foreach ($queryselectinvoiceitemswa2 as $row1) {
                    $customdata1[] = (array)$row1;
                }

                foreach ($customdata1 as $row) {
                    Log::info(["datawaa", $row]);
                    $hosting = $row['service'];
                    $allitem .= $hosting . ", ";
                }
            }

            $phonenumber = preg_replace("/[^0-9]/", "", trim($user->phonenumber));
            $phonenumber = (substr($phonenumber, 0, 2) != '62') ? '62' . substr($phonenumber, 1) : $phonenumber;
            $totalrupiah = "Rp" . number_format($invoice->total, 2, ',', '.');

            $invoicedata = new \App\Helpers\InvoiceClass($invoice->id);
            $invoiceLink = $invoicedata->getPaymentLink();

            $message = "";
            $messagename = "";
            $norek = "";

            switch ($invoice->paymentmethod) {
                case 'banktransfer':
                    $messagename = "Bank Transfer BCA";
                    $norek = '037-8770800 A/N RELABS NET DAYACIPTA PT';
                    break;
                case 'bcava':
                case 'bcavaxendit':
                case 'mandiriva':
                case 'mandirivaxendit':
                case 'bniva':
                case 'bnivaxendit':
                case 'briva':
                case 'brivaxendit':
                case 'permatabankva':
                case 'permatabankvaxendit':
                case 'sampoernava':
                case 'sampoernavaxendit':
                case 'atmbersamaxendit':
                    $message = str_replace(['<strong>', '</strong>'], '*', $invoiceLink->message);
                    break;
                case 'danaxendit':
                    $messagename = "DANA";
                    $norek = 'Login Akun Relabs -> Buka Invoice -> Ikuti sesuai Petunjuk tertera';
                    break;
                case 'ovoxendit':
                    $messagename = "OVO";
                    $norek = 'Login Akun Relabs -> Buka Invoice -> Ikuti sesuai Petunjuk tertera';
                    break;
                case 'linkajaxendit':
                    $messagename = "LinkAja";
                    $norek = 'Login Akun Relabs -> Buka Invoice -> Ikuti sesuai Petunjuk tertera';
                    break;
                case 'gopaymidtrans':
                    $messagename = "GoPay";
                    $norek = 'Login Akun Relabs -> Buka Invoice -> Ikuti sesuai Petunjuk tertera';
                    break;
                case 'ccmidtrans':
                    $messagename = "Credit Card (Visa, Mastercard, JBC, American Express)";
                    $norek = 'Login Akun Relabs -> Buka Invoice -> Ikuti sesuai Petunjuk tertera';
                    break;
                case 'alfamartxendit':
                    $messagename = "Alfamart";
                    $norek = 'Login Akun Relabs -> Buka Invoice -> Ikuti sesuai Petunjuk tertera';
                    break;
                case 'shopeepayxendit':
                    $messagename = "ShopeePay";
                    $norek = 'Login Akun Relabs -> Buka Invoice -> Ikuti sesuai Petunjuk tertera';
                    break;
                default:
                    $messagename = "";
                    $norek = '';
                    break;
            }

            $url = 'https://portal.qwords.com/apis/wa/relabs.php';
            $data = [
                'phone' => $phonenumber,
                'firstname' => $user->firstname,
                'message' => $message,
                'messagename' => $messagename,
                'norek' => $norek,
                'allitem' => $allitem,
                'invoiceid' => $invoice->id,
                'duedate' => $invoice->duedate,
                'totalrupiah' => $totalrupiah,
            ];

            Log::info("SendWaInvoice data " . json_encode($data));

            // Menjadi ini
            $maxRetries = 3;
            $attempt = 1;
            $success = false;

            while ($attempt <= $maxRetries && !$success) {
                try {
                    $response = Http::timeout(15)
                        ->retry(3, 100)
                        ->post($url, $data);
                        
                    $responseBody = $response->body();
                    Log::info("SendWaInvoice response attempt #{$attempt}: " . $responseBody);
                    
                    if ($response->successful()) {
                        $success = true;
                        break;
                    }
                    
                } catch (\Exception $e) {
                    Log::error("SendWaInvoice attempt #{$attempt} failed: " . $e->getMessage());
                    if ($attempt == $maxRetries) {
                        throw $e;
                    }
                }
                
                $attempt++;
                sleep(2);
            }

            if ($success) {
                LogActivity::Save("Pengiriman WA Berhasil - Invoice #{$invoice->id}");
                $successCount++;
            } else {
                LogActivity::Save("Pengiriman WA Gagal setelah {$maxRetries} percobaan - Invoice #{$invoice->id}");
                $failedCount++;
            }

        } catch (\Exception $e) {
            Log::debug("SendWaInvoice error " . $e->getMessage());
            $failedCount++;
        }

        return "Selesai mengirim WA: Berhasil: {$successCount}, Gagal: {$failedCount}";
    }

    public function resendInvoiceWABulk(Request $request)
    {
        if ($request->has('show_loading')) {
            // Get group name first
            $groupName = DB::table('tblclientgroups')
                ->where('id', $request->groupid)
                ->value('groupname');
                
            return view('pages.billing.invoices.loading-wa', [
                'groupName' => $groupName
            ]);
        }

        // Validasi input
        $request->validate([
            'groupid' => 'required|numeric'
        ]);

        // Get group name untuk logging
        $groupName = DB::table('tblclientgroups')
            ->where('id', $request->groupid)
            ->value('groupname');

        $clients = DB::table("tblclients as c")
            ->join('tblinvoices as i', 'c.id', '=', 'i.userid')
            ->where('c.groupid', $request->groupid)
            ->where('c.status', 'Active')
            ->where('i.status', 'Unpaid')
            ->select('c.*', 'i.id as invoice_id', 'i.total', 'i.paymentmethod', 'i.duedate')
            ->distinct()
            ->get();

        $successCount = 0;
        $failedCount = 0;
        $errors = [];

        try {
            $clients = DB::table("tblclients as c")
                ->join('tblinvoices as i', 'c.id', '=', 'i.userid')
                ->where('c.groupid', $request->groupid)
                ->where('c.status', 'Active')
                ->where('i.status', 'Unpaid')
                ->select('c.*', 'i.id as invoice_id', 'i.total', 'i.paymentmethod', 'i.duedate')
                ->distinct()
                ->get();

            $totalClients = $clients->count();

            if ($totalClients == 0) {
                return "Tidak ada client dengan invoice unpaid ditemukan untuk group ini";
            }

            foreach ($clients as $client) {
                try {
                    $allitem = '';
                    $selectinvoiceitemswa2 = "SELECT CONCAT(tblproducts.name, ' - ', tblhosting.domain) as service, tblinvoiceitems.amount, tblhosting.regdate, tblhosting.packageid FROM tblinvoiceitems, tblhosting, tblproducts WHERE tblinvoiceitems.relid = tblhosting.id AND tblhosting.packageid = tblproducts.id AND tblinvoiceitems.invoiceid = ? AND tblinvoiceitems.type IN ('Hosting')";
                    $queryselectinvoiceitemswa2 = DB::select($selectinvoiceitemswa2, [$client->invoice_id]);
                    $resultselectinvoiceitemsnumrowswa2 = count($queryselectinvoiceitemswa2);

                    if ($resultselectinvoiceitemsnumrowswa2 > 0) {
                        $customdata1 = [];
                        foreach ($queryselectinvoiceitemswa2 as $row1) {
                            $customdata1[] = (array)$row1;
                        }

                        foreach ($customdata1 as $row) {
                            Log::info(["datawaa", $row]);
                            $hosting = $row['service'];
                            $allitem .= $hosting . ", ";
                        }
                    }

                    $phonenumber = preg_replace("/[^0-9]/", "", trim($client->phonenumber));
                    $phonenumber = (substr($phonenumber, 0, 2) != '62') ? '62' . substr($phonenumber, 1) : $phonenumber;
                    $totalrupiah = "Rp" . number_format($client->total, 2, ',', '.');

                    $invoicedata = new \App\Helpers\InvoiceClass($client->invoice_id);
                    $invoiceLink = $invoicedata->getPaymentLink();

                    // Hapus literal \n dan ganti dengan karakter newline sebenarnya
                    $formattedMessage = str_replace('\n', "\n", $request->message);


                    $message = "";
                    $messagename = "";
                    $norek = "";

                    switch ($client->paymentmethod) {
                        case 'banktransfer':
                            $messagename = "Bank Transfer BCA";
                            $norek = '037-8770800 A/N RELABS NET DAYACIPTA PT';
                            break;
                        case 'bcava':
                        case 'bcavaxendit':
                        case 'mandiriva':
                        case 'mandirivaxendit':
                        case 'bniva':
                        case 'bnivaxendit':
                        case 'briva':
                        case 'brivaxendit':
                        case 'permatabankva':
                        case 'permatabankvaxendit':
                        case 'sampoernava':
                        case 'sampoernavaxendit':
                        case 'atmbersamaxendit':
                            $message = str_replace(['<strong>', '</strong>'], '*', $invoiceLink->message);
                            break;
                        case 'danaxendit':
                            $messagename = "DANA";
                            $norek = 'Login Akun Relabs -> Buka Invoice -> Ikuti sesuai Petunjuk tertera';
                            break;
                        case 'ovoxendit':
                            $messagename = "OVO";
                            $norek = 'Login Akun Relabs -> Buka Invoice -> Ikuti sesuai Petunjuk tertera';
                            break;
                        case 'linkajaxendit':
                            $messagename = "LinkAja";
                            $norek = 'Login Akun Relabs -> Buka Invoice -> Ikuti sesuai Petunjuk tertera';
                            break;
                        case 'gopaymidtrans':
                            $messagename = "GoPay";
                            $norek = 'Login Akun Relabs -> Buka Invoice -> Ikuti sesuai Petunjuk tertera';
                            break;
                        case 'ccmidtrans':
                            $messagename = "Credit Card (Visa, Mastercard, JBC, American Express)";
                            $norek = 'Login Akun Relabs -> Buka Invoice -> Ikuti sesuai Petunjuk tertera';
                            break;
                        case 'alfamartxendit':
                            $messagename = "Alfamart";
                            $norek = 'Login Akun Relabs -> Buka Invoice -> Ikuti sesuai Petunjuk tertera';
                            break;
                        case 'shopeepayxendit':
                            $messagename = "ShopeePay";
                            $norek = 'Login Akun Relabs -> Buka Invoice -> Ikuti sesuai Petunjuk tertera';
                            break;
                        default:
                            $messagename = "";
                            $norek = '';
                            break;
                    }

                    $url = 'https://portal.qwords.com/apis/wa/relabs.php';
                    // $data = [
                    //     'phone' => $phonenumber,
                    //     'firstname' => $client->firstname,
                    //     // 'message' => $message,
                    //     'message' => $formattedMessage,
                    //     // 'messagename' => $messagename,
                    //     'norek' => $norek,
                    //     'allitem' => $allitem,
                    //     'invoiceid' => $client->invoice_id,
                    //     'duedate' => $client->duedate,
                    //     'totalrupiah' => $totalrupiah,
                    // ];
                    $data = [
                        'phone' => $phonenumber,
                        'message' => $formattedMessage,
                        'isCustomMessage' => true
                    ];

                    Log::info("SendWaInvoice Bulk data " . json_encode($data));

                    // Menjadi ini
                    $maxRetries = 3;
                    $attempt = 1;
                    $success = false;

                    while ($attempt <= $maxRetries && !$success) {
                        try {
                            $response = Http::timeout(15)
                                ->retry(3, 100)
                                ->post($url, $data);
                                
                            $responseBody = $response->body();
                            Log::info("SendWaInvoice Bulk response attempt #{$attempt}: " . $responseBody);
                            
                            if ($response->successful()) {
                                $success = true;
                                break;
                            }
                            
                        } catch (\Exception $e) {
                            Log::error("SendWaInvoice Bulk attempt #{$attempt} failed: " . $e->getMessage());
                            if ($attempt == $maxRetries) {
                                throw $e;
                            }
                        }
                        
                        $attempt++;
                        sleep(2);
                    }

                    if ($success) {
                        LogActivity::Save("Pengiriman WA Bulk Berhasil - Invoice #{$client->invoice_id}");
                        $successCount++;
                    } else {
                        LogActivity::Save("Pengiriman WA Bulk Gagal setelah {$maxRetries} percobaan - Invoice #{$client->invoice_id}");
                        $failedCount++;
                        $errors[] = "Failed to send WA to client {$client->id} after {$maxRetries} attempts";
                    }

                    sleep(2); // Delay antar pengiriman
                    

                } catch (\Exception $e) {
                    $failedCount++;
                    $errors[] = "Failed to send WA to client {$client->id}: " . $e->getMessage();
                    Log::debug("SendWaInvoice Bulk error for client {$client->id}: " . $e->getMessage());
                }
            }

            if (!empty($errors)) {
                Log::debug("SendWaInvoice Bulk errors: " . json_encode($errors));
            }

        } catch (\Exception $e) {
            Log::debug("SendWaInvoice Bulk main error: " . $e->getMessage());
            return "Terjadi kesalahan: " . $e->getMessage();
        }

        return "Selesai mengirim WA: Berhasil: {$successCount}, Gagal: {$failedCount}";
    }

    public function index()
    {
        return view('sendinvoicewa::index');
    }

    public function sendCustomWA(Request $request)
    {
        if ($request->has('show_loading')) {
            return view('pages.billing.invoices.loading-wa');
        }
                
        $request->validate([
            'message' => 'required|string',
            'delay' => 'required|integer|min:1'
        ]);

        $clients = DB::table("tblclients")
            ->where('status', 'Active')
            ->select('id', 'phonenumber')
            ->get();

        $totalClients = $clients->count();
            
        if ($totalClients == 0) {
            return "Tidak ada client aktif yang ditemukan";
        }

        $successCount = 0;
        $failedCount = 0;

        foreach ($clients as $client) {
            try {
                $invoice = DB::table("tblinvoices")->where(['id' => $request->invoiceid])->first();
                $user = DB::table("tblclients")->where(['id' => $invoice->userid])->first();

                $allitem = '';
                $selectinvoiceitemswa2 = "SELECT CONCAT(tblproducts.name, ' - ', tblhosting.domain) as service, tblinvoiceitems.amount, tblhosting.regdate, tblhosting.packageid FROM tblinvoiceitems, tblhosting, tblproducts WHERE tblinvoiceitems.relid = tblhosting.id AND tblhosting.packageid = tblproducts.id AND tblinvoiceitems.invoiceid = ? AND tblinvoiceitems.type IN ('Hosting')";
                $queryselectinvoiceitemswa2 = DB::select($selectinvoiceitemswa2, [$request->invoiceid]);
                $resultselectinvoiceitemsnumrowswa2 = count($queryselectinvoiceitemswa2);

                if ($resultselectinvoiceitemsnumrowswa2 > 0) {
                    $customdata1 = [];
                    foreach ($queryselectinvoiceitemswa2 as $row1) {
                        $customdata1[] = (array)$row1;
                    }

                    foreach ($customdata1 as $row) {
                        Log::info(["datawaa", $row]);
                        $hosting = $row['service'];
                        $allitem .= $hosting . ", ";
                    }
                }

                $phonenumber = preg_replace("/[^0-9]/", "", trim($user->phonenumber));
                $phonenumber = (substr($phonenumber, 0, 2) != '62') ? '62' . substr($phonenumber, 1) : $phonenumber;
                $totalrupiah = "Rp" . number_format($invoice->total, 2, ',', '.');

                $invoicedata = new \App\Helpers\InvoiceClass($invoice->id);
                $invoiceLink = $invoicedata->getPaymentLink();

                $message = "";
                $messagename = "";
                $norek = "";

                switch ($invoice->paymentmethod) {
                    case 'banktransfer':
                        $messagename = "Bank Transfer BCA";
                        $norek = '037-8770800 A/N RELABS NET DAYACIPTA PT';
                        break;
                    case 'bcava':
                    case 'bcavaxendit':
                    case 'mandiriva':
                    case 'mandirivaxendit':
                    case 'bniva':
                    case 'bnivaxendit':
                    case 'briva':
                    case 'brivaxendit':
                    case 'permatabankva':
                    case 'permatabankvaxendit':
                    case 'sampoernava':
                    case 'sampoernavaxendit':
                    case 'atmbersamaxendit':
                        $message = str_replace(['<strong>', '</strong>'], '*', $invoiceLink->message);
                        break;
                    case 'danaxendit':
                        $messagename = "DANA";
                        $norek = 'Login Akun Relabs -> Buka Invoice -> Ikuti sesuai Petunjuk tertera';
                        break;
                    case 'ovoxendit':
                        $messagename = "OVO";
                        $norek = 'Login Akun Relabs -> Buka Invoice -> Ikuti sesuai Petunjuk tertera';
                        break;
                    case 'linkajaxendit':
                        $messagename = "LinkAja";
                        $norek = 'Login Akun Relabs -> Buka Invoice -> Ikuti sesuai Petunjuk tertera';
                        break;
                    case 'gopaymidtrans':
                        $messagename = "GoPay";
                        $norek = 'Login Akun Relabs -> Buka Invoice -> Ikuti sesuai Petunjuk tertera';
                        break;
                    case 'ccmidtrans':
                        $messagename = "Credit Card (Visa, Mastercard, JBC, American Express)";
                        $norek = 'Login Akun Relabs -> Buka Invoice -> Ikuti sesuai Petunjuk tertera';
                        break;
                    case 'alfamartxendit':
                        $messagename = "Alfamart";
                        $norek = 'Login Akun Relabs -> Buka Invoice -> Ikuti sesuai Petunjuk tertera';
                        break;
                    case 'shopeepayxendit':
                        $messagename = "ShopeePay";
                        $norek = 'Login Akun Relabs -> Buka Invoice -> Ikuti sesuai Petunjuk tertera';
                        break;
                    default:
                        $messagename = "";
                        $norek = '';
                        break;
                }

                $url = 'https://portal.qwords.com/apis/wa/relabs.php';
                $data = [
                    'phone' => $phonenumber,
                    'firstname' => $user->firstname,
                    'message' => $message,
                    'messagename' => $messagename,
                    'norek' => $norek,
                    'allitem' => $allitem,
                    'invoiceid' => $invoice->id,
                    'duedate' => $invoice->duedate,
                    'totalrupiah' => $totalrupiah,
                ];
                $response = Http::post($url, $data);
                    
                Log::info("Send ALL WA response ".$response->body());
                $successCount++;
                    
                sleep($request->delay);

            } catch (\Exception $e) {
                $failedCount++;
                Log::debug("Send ALL WA error ".$e->getMessage());
            }
        }

        return "Selesai mengirim WA: Berhasil: {$successCount}, Gagal: {$failedCount}";
    }

    public function getGroupName($groupId)
    {
        $groupName = DB::table('tblclientgroups')
            ->where('id', $groupId)
            ->value('groupname');
            
        return $groupName ?? 'Kelompok Client';
    }

    public function sendReminderInvoiceWA()
    {
        // Menentukan tanggal dua hari dari sekarang
        $twoDaysFromNow = Carbon::now()->addDays(2)->toDateString();

        // Mengambil semua invoice yang jatuh tempo dua hari dari sekarang dan belum dibayar
        $invoices = DB::table('tblinvoices')
            ->where('duedate', $twoDaysFromNow)
            ->where('status', 'Unpaid')
            ->get();

        $successCount = 0;
        $failedCount = 0;

        foreach ($invoices as $invoice) {
            try {
                // Mengambil data pengguna berdasarkan user ID dari invoice
                $user = DB::table('tblclients')->where('id', $invoice->userid)->first();

                // Memformat nomor telepon
                $phonenumber = preg_replace("/[^0-9]/", "", trim($user->phonenumber));
                $phonenumber = (substr($phonenumber, 0, 2) != '62') ? '62' . substr($phonenumber, 1) : $phonenumber;

                // Memformat total invoice ke dalam format Rupiah
                $totalrupiah = "Rp" . number_format($invoice->total, 2, ',', '.');

                // Buat pesan tanpa link pembayaran
                $message = "Reminder: Invoice #{$invoice->id} is due on {$invoice->duedate}. Total: {$totalrupiah}. Please ensure payment is made on time.";

                // Menyiapkan data untuk dikirim ke API WhatsApp
                $data = [
                    'phone' => $phonenumber,
                    'message' => $message,
                ];

                // Logging untuk debugging
                Log::debug("Sending message: " . $message);

                // Mengirim pesan melalui API
                $url = 'https://portal.qwords.com/apis/wa/relabs.php';
                $response = Http::post($url, $data);

                // Memeriksa apakah pengiriman berhasil
                if ($response->successful()) {
                    LogActivity::Save("Pengiriman WA Berhasil - Invoice #{$invoice->id}");
                    $successCount++;
                } else {
                    LogActivity::Save("Pengiriman WA Gagal - Invoice #{$invoice->id}");
                    $failedCount++;
                }

            } catch (\Exception $e) {
                // Menangani error dan mencatatnya
                Log::debug("SendReminderInvoiceWA error " . $e->getMessage());
                $failedCount++;
            }
        }

        // Mengembalikan hasil pengiriman
        return "Selesai mengirim WA: Berhasil: {$successCount}, Gagal: {$failedCount}";
    }
}