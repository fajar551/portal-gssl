@extends('layouts.basecbms')

@section('title')
    <title>CBMS Addons - My Auction</title>
@endsection

@section('content')
<div class="main-content">
    <div class="page-content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12 mb-2">
                    <h2 class="mb-0">My Auction</h2>
                    <small class="text-muted">Lelang Domain Saya</small>
                </div>
                <div class="col-md-12">
                    @if (Session::get('alert-message'))
                        <div class="alert alert-{{ Session::get('alert-type') }}" role="alert">
                            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                            {!! nl2br(Session::get('alert-message')) !!}
                        </div>
                    @endif
                    @if ($errors->any())
                        <div class="alert alert-danger">
                            <b>Error:</b>
                            <ul>
                                @foreach ($errors->all() as $error)
                                    <li>{{ $error }}</li>
                                @endforeach
                            </ul>
                        </div>
                    @endif
                </div>

                {{-- Link untuk Setting --}}
                <a class="btn btn-sm btn-primary" href="/admin/addonsmodule?module=auction">Setting</a>

                <div class="col-md-12 mt-3">
                    <div class="card">
                        <div class="card-body">
                            <h5>Daftar Lelang Saya</h5>
                            <table class="table table-hover table-striped wrap" id="my_auction_table">
                                <thead>
                                    <tr>
                                        <th>Domain</th>
                                        <th>Harga Terakhir</th>
                                        <th>Tanggal Penutupan</th>
                                        <th>Status</th>
                                        <th class="text-center">Aksi</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    @foreach($list as $data)
                                        <tr>
                                            <td>{{ $data->domain }}</td>
                                            <td>Rp {{ number_format($data->price_last, 0, '.', '.') }}</td>
                                            <td>{{ $data->close_date }}</td>
                                            <td>
                                                @if ($data->status == 'CLOSE_LELANG' || $data->status == 'INVOICE_CREATED')
                                                    CLOSED
                                                @else
                                                    {{ $data->status }}
                                                @endif
                                            </td>
                                            <td class="text-center">
                                                @if ($data->status == 'OPEN_LELANG')
                                                    <a href="{{ url('/index.php?m=auction&page=detail&domain=' . $data->domain) }}" target="_blank" class="btn btn-primary">Detail</a>
                                                @endif
                                                <a href="{{ url('/index.php?m=auction&page=history&domain=' . $data->domain) }}" target="_blank" class="btn btn-default">History</a>
                                            </td>
                                        </tr>
                                    @endforeach
                                </tbody>
                                {{-- <tfoot>
                                    <tr>
                                        <th colspan="5" class="text-right">
                                            <button class="btn btn-success">Save Changes</button>
                                        </th>
                                    </tr>
                                </tfoot> --}}
                            </table>
                        </div>
                    </div>
                </div>
            
                <button class="btn btn-secondary" onclick="window.location.href='{{ url('/admin/addonsmodule?module=auction') }}'">
                    <i class="fas fa-arrow-left"></i> Back To Previous Page 
                </button>
            </div>
        </div>
    </div>
</div>
@endsection

@section('scripts')
    <script src="{{ Theme::asset('assets/libs/datatables.net/js/jquery.dataTables.min.js') }}"></script>
    <script src="{{ Theme::asset('assets/libs/datatables.net-bs4/js/dataTables.bootstrap4.min.js') }}"></script>
    <script>
        $(document).ready(function() {
            $('#my_auction_table').DataTable({
                "columnDefs": [
                    { "orderable": true, "targets": [0, 1, 2, 3] }, 
                    { "orderable": false, "targets": [4] } 
                ],
                "order": [] // Tidak ada kolom yang otomatis diurutkan
            });
        });
    </script>
@endsection
