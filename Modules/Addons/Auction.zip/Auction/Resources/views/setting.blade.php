@extends('layouts.basecbms')

@section('title')
    <title>CBMS Addons - My Auction</title>
@endsection

@section('content')
    <div class="main-content">
        <div class="page-content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-12 mb-2">
                        <h2 class="mb-0">Setting - My Auction</h2>
                        <small class="text-muted">Pengaturan Lelang Saya</small>
                    </div>
                    {{-- alert message --}}
                    <div class="col-md-12">
                        @if (Session::get('alert-message'))
                            <div class="alert alert-{{ Session::get('alert-type') }}" role="alert">
                                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                                {!! nl2br(Session::get('alert-message')) !!}
                            </div>
                        @endif
                        @if ($errors->any())
                            <div class="alert alert-danger">
                                <b>Error:</b>
                                <ul>
                                    @foreach ($errors->all() as $error)
                                        <li>{{ $error }}</li>
                                    @endforeach
                                </ul>
                            </div>
                        @endif
                    </div>
                    {{-- alert message --}}

                    <div class="col-md-12 mt-3">
                        <div class="card">
                            <div class="card-body">

                                <div class="panel panel-default panel-accent-teal">
                                    <form action="{{ route('pages.domain.lelangdomains.action') }}" method="POST">
                                        @csrf <!-- Add CSRF token for security -->
                                        <input type="hidden" name="action" value="save_setting">
                                        <!-- Include action input -->
                                        <div class="form-check">
                                            <input name="notif" type="checkbox" class="form-check-input" id="notif"
                                                {{ isset($setting_notif) && $setting_notif ? 'checked' : '' }}>
                                            <label class="form-check-label" for="notif">Notif domain lelang, jual dan
                                                sewa domain</label>
                                        </div>
                                        <br>
                                        <button class="btn btn-primary bg-color-teal" type="submit">Simpan</button>
                                    </form>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>
                <button class="btn btn-secondary" onclick="window.location.href='{{ url('/admin/addonsmodule?module=auction') }}'">
                    <i class="fas fa-arrow-left"></i> Back To Previous Page 
                </button>
            </div>
        </div>
    </div>
@endsection

@section('scripts')
    <script>
        $(document).ready(function() {
            // Your JS code here
        });
    </script>
@endsection
