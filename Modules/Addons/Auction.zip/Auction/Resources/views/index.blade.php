@extends('layouts.basecbms')

@section('title')
    <title>CBMS Addons - Lelang Domain</title>
@endsection

@section('content')
    <div class="main-content">
        <div class="page-content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-12 mb-2">
                        <h2 class="mb-0">Lelang Domain</h2>
                        <small class="text-muted">By CBMS</small>
                    </div>
                    {{-- alert message --}}
                    <div class="col-md-12">
                        @if (Session::get('alert-message'))
                            <div class="alert alert-{{ Session::get('alert-type') }}" role="alert">
                                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                                {!! nl2br(Session::get('alert-message')) !!}
                            </div>
                        @endif
                        @if ($errors->any())
                            <div class="alert alert-danger">
                                <b>Error:</b>
                                <ul>
                                    @foreach ($errors->all() as $error)
                                        <li>{{ $error }}</li>
                                    @endforeach
                                </ul>
                            </div>
                        @endif
                    </div>
                    {{-- alert message --}}

                    {{-- <button onclick="window.location.href='{{ url('/admin/addonsmodule?module=auction&page=backorder') }}'" class="btn btn-secondary">
                        << Back To Home 
                    </button> --}}
                    <div class="col-md-12">
                        <form action="{{ url('/admin/addonsmodule') }}" method="GET" style="display:inline;">
                            <input type="hidden" name="module" value="auction">
                            <input type="hidden" name="page" value="backorder">
                            <button type="submit" class="btn btn-secondary">
                                Backorder Page
                            </button>
                        </form>   
                    </div>
                    
                    {{-- search and filter --}}
                    <div class="col-md-12 mt-3">
                        <div class="card">
                            <div class="card-body">
                                <div id="accordion" class="custom-accordion mt-1 pb-1">
                                    <div class="card mb-1 shadow-none">
                                        <a href="#collapseOne" class="text-dark" data-toggle="collapse" aria-expanded="true"
                                            aria-controls="collapseOne">
                                            <div class="card-header" id="headingOne">
                                                <h6 class="m-0">
                                                    Search & Filter
                                                    <i class="mdi mdi-minus float-right accor-plus-icon"></i>
                                                </h6>
                                            </div>
                                        </a>
                                        
                                        <div id="collapseOne" class="collapse hide" aria-labelledby="headingOne" data-parent="#accordion">
                                            <div class="card-body">
                                                <form action="{{ route('addons.auction.insertAuction') }}" method="POST" id="form-filters" enctype="multipart/form-data" onsubmit="return filterTable(this)">
                                                    @csrf 
                                                    <div class="row">
                                                        <div class="col-12 col-md-6">
                                                            <div class="form-group">
                                                                <label for="search_domain" class="text-truncate mb-0">Input domain lelang manual</label>
                                                                <input type="text" id="domain" name="domain" class="form-control" placeholder="Domain"> 
                                                                <input type="hidden" id="type" name="type" class="form-control" placeholder="" value="redirect">
                                                            </div>
                                                        </div>
                                                        <div class="col-12 col-md-6">
                                                            <div class="form-group">
                                                                <label for="filter_status">Filter Status</label>
                                                                <select id="filter_status" name="filter_status" class="form-control">
                                                                    <option value="all"> all </option>
                                                                    <option value="open_lelang_backorder"> open_lelang_backorder</option>
                                                                    <option value="invoice_create"> invoice_create</option>
                                                                </select>
                                                            </div>
                                                        </div>
                                                        <div class="col-12 col-md-6 text-right">
                                                            <div class="form-group">
                                                                <button type="submit" class="btn btn-primary">Redirect</button>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </form>
                                            </div>
                                        </div>

                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    {{-- search and filter --}}

                    <div class="col-md-12">
                        <div class="card">
                            <div class="card-body">
                                <h5>Penjualan Hari Ini</h5>
                                <div class="table-responsive">
                                    <table class="table table-hover table-striped wrap" id="history">
                                        <thead>
                                            <tr>
                                                <th scope="col">Id</th>
                                                <th scope="col">Domain</th>
                                                <th scope="col">Price</th>
                                                <th scope="col">Open Date</th>
                                                <th scope="col">Close Date</th>
                                                <th scope="col">Status</th>
                                                <th scope="col">Maxtry</th>
                                                <th scope="col">Owner</th>
                                                <th scope="col">Updated At</th>
                                                <th scope="col">Action</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            @foreach ($all_auction as $val)
                                                <tr>
                                                    <th scope="row">{{ $val->id }}</th>
                                                    <td><a target="_blank" href="http://{{ $val->domain }}">{{ $val->domain }}</a></td>
                                                    <td>
                                                        @if (boolval($val->price))
                                                            Rp{{ number_format($val->price, 0, ',', '.') }}
                                                        @else
                                                            <a href="{{ route('addons.auction.index', ['domain' => $val->domain, 'page' => 'history']) }}" target="_blank"> see history </a>
                                                        @endif
                                                    </td>
                                                    <td>{{ $val->open_date }}</td>
                                                    <td>{{ $val->close_date }}</td>
                                                    <td>
                                                        {{ $val->status === 'OPEN_LELANG' ? '_OPEN_LELANG' : $val->status }}
                                                    </td>
                                                    <td>{{ $val->maxtry }}</td>
                                                    <td>
                                                        <a target="_blank" href="{{ url('admin/clients/clientssummary?userid=' . $val->owner) }}">{{ $val->owner }}</a>
                                                    </td>
                                                    <td>{{ $val->updated_at }}</td>
                                                    <td>
                                                        <div class="d-flex justify-content-center flex-wrap">
                                                            <a class="btn btn-primary m-1" href="{{ route('addons.auction.index', ['domain' => $val->domain, 'page' => 'history']) }}" target="_blank">see history</a>
                                                            @if ($val->status !== 'OPEN_LELANG')
                                                                <button class="btn btn-secondary m-1" onclick="handleReopen('{{ $val->id }}')">Re-Open</button>
                                                                <button class="btn btn-success m-1" onclick="handleRestart('{{ $val->id }}')">Re-Start</button>
                                                            @endif
                                                            <a class="btn btn-danger m-1" href="{{ route('addons.auction.action', ['id_domain' => $val->id, 'action' => 'delete']) }}">Archive</a>
                                                        </div>
                                                    </td>
                                                </tr>
                                            @endforeach
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                
                </div>
            </div>
        </div>
    </div>

    {{-- modal button-restart --}}
    <div id="restart" class="modal" tabindex="-1" role="dialog">
        <div class="modal-dialog modal-dialog-centered" role="document">
          <div class="modal-content">
            <div class="modal-header">
              <h5 class="modal-title">Re Start Lelang</h5>
              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
              </button>
            </div>
            <div class="modal-body">
                <p>Dengan melakukan restart auction, maka semua data history auction ini akan dipindahkan ke table auction_history_old.</p>
              <div class="form-group">
                  <label for="harga-awal">Harga Awal (Rp)</label>
                  <input class="form-control" type="number" id="harga-awal" name="hargaawal" >
              </div>
              <div class="form-group">
                  <label for="dtpick-restart">Close Date</label>
                  <input class="form-control" type="datetime-local" id="dtpick-restart" name="dtpick" >
              </div>
            </div>
            <div class="modal-footer">
              <button type="button" class="btn btn-primary" onclick="prosesReStart()">Proses</button>
              <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            </div>
          </div>
        </div>
      </div>
    {{-- modal button-restart --}}
    
    {{-- modal button-reopen --}}
      <div id="reopen" class="modal" tabindex="-1" role="dialog">
        <div class="modal-dialog modal-dialog-centered" role="document">
          <div class="modal-content">
            <div class="modal-header">
              <h5 class="modal-title">Re Open Lelang</h5>
              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
              </button>
            </div>
            <div class="modal-body">
              <div class="form-group">
                  <label for="dtpick">Close Date</label>
                  <input class="form-control" type="datetime-local" id="dtpick" name="dtpick" >
              </div>
            </div>
            <div class="modal-footer">
              <button type="button" class="btn btn-primary" onclick="prosesReOpen()">Proses</button>
              <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            </div>
          </div>
        </div>
      </div>
    {{-- modal button-reopen --}}

    <!-- Modal Konfirmasi -->
    <div id="confirmModal" class="modal" tabindex="-1" role="dialog">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Konfirmasi</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <p id="confirmMessage">Apakah Anda yakin?</p>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-primary" id="confirmYes">Ya</button>
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Tidak</button>
                </div>
            </div>
        </div>
    </div>
@endsection

@section('scripts')
    <script src="{{ Theme::asset('assets/libs/datatables.net/js/jquery.dataTables.min.js') }}"></script>
    <script src="{{ Theme::asset('assets/libs/datatables.net-bs4/js/dataTables.bootstrap4.min.js') }}"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.3/jquery.validate.min.js"></script>
    <script src="https://cdn.jsdelivr.net/jquery.validation/1.16.0/additional-methods.min.js"></script>
    <script src="{{ Theme::asset('js/notify.min.js') }}"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.29.1/moment.min.js"></script>
    
    <script>
        $(document).ready(function() {
            var table = $('.table').DataTable({
                "order": [
                    [4, "desc"]
                ],
                orderCellsTop: true,
            });

            $('#filter_status').change(function(){
                table.search('').columns().search('').draw();
                if (this.value == 'open_lelang_backorder'){
                    table
                        .column(7)
                        .search( '^$', true, false )
                        .draw();
                        
                    table
                        .column(5)
                        .search('open_lelang')
                        .draw();
                } else if (this.value == 'invoice_create'){
                    table
                        .column(5)
                        .search('invoice_created')
                        .draw();
                }
            })
        });
        
        function handleReopen(id_domain) {
            window.current_domain_id = id_domain
            $('#reopen').modal('show')
        }

        function handleRestart(id_domain) {
            window.current_domain_id = id_domain
            $('#restart').modal('show')
        }

        function prosesReOpen() {
            const val = $('#dtpick').val();
            const formated = moment(val).format('YYYY-MM-DD HH:mm:ss');
            const c = window.confirm('Apakah lelang ingin dibuka kembali?');
            if (c) {
                location.href = '{{ route('addons.auction.action', ['id_domain' => '']) }}' + window.current_domain_id + '&action=reopen&datetime=' + encodeURIComponent(formated);
            }
        }

        function prosesReStart() {
            const val = $('#dtpick-restart').val();
            const hargaawal = $('#harga-awal').val();
            const formated = moment(val).format('YYYY-MM-DD HH:mm:ss');
            const c = window.confirm('Apakah lelang ingin dimulai kembali?');
            if (c) {
                location.href = '{{ route('addons.auction.action', ['id_domain' => '']) }}' + window.current_domain_id + '&action=restart&datetime=' + encodeURIComponent(formated) + '&hargaawal=' + encodeURIComponent(hargaawal);
            }
        }        
        
        window.addEventListener('load', () => {
            const now = new Date();
            now.setMinutes(now.getMinutes() - now.getTimezoneOffset());
            document.getElementById('dtpick').value = now.toISOString().slice(0, -1);
        });

        function showConfirmModal(message, callback) {
            $('#confirmMessage').text(message);
            $('#mainContent').attr('inert', true);
            $('#confirmYes').off('click').on('click', function() {
                callback();
                $('#confirmModal').modal('hide');
                $('#mainContent').removeAttr('inert');
            });
            $('#confirmModal').modal('show');
        }

        $('#confirmModal').on('hidden.bs.modal', function () {
            $('#mainContent').removeAttr('inert');
        });

        // Update the Archive button to use the modal
        $(document).on('click', '.btn-danger', function(e) {
            e.preventDefault();
            const href = $(this).attr('href');
            showConfirmModal('Apakah Anda yakin ingin mengarsipkan item ini?', function() {
                window.location.href = href;
            });
        });
    </script>
@endsection
