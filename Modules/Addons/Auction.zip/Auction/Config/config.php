<?php

return [
    'name' => 'Auction'
];
