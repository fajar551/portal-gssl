<?php

namespace Modules\Addons\SendInvoiceWa\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Helpers\InvoiceClass;

use Carbon\Carbon;
use App\Helpers\Client as HelpersClient;
use App\Helpers\Database;
use App\Helpers\Format;
use App\Models\Account;
use App\Models\Client;
use App\Models\Clientgroup;
use App\Models\Hosting;
use App\Models\Invoice;
use App\Models\Invoiceitem;
use App\Traits\DatatableFilter;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;
use App\Helpers\LogActivity;

class SendInvoiceWaController extends Controller
{

    use DatatableFilter;
    protected $prefix;

    public function __construct()
    {
        $this->middleware(['auth:admin']);
        $this->prefix = Database::prefix();
    }

    public function getLateClient()
    {
        $hostings = Hosting::where('domainstatus', 'Active')
            ->where('nextduedate', '<=', now())
            ->get();

        $userIds = $hostings->pluck('userid');
        $relIds = $hostings->pluck('id');

        $maxDueDates = Invoiceitem::whereIn('userid', $userIds)
            ->whereIn('relid', $relIds)
            ->groupBy(['userid', 'relid'])
            ->selectRaw('userid, relid, MAX(duedate) as max_duedate')
            ->get();

        $maxDueDatesFiltered = $maxDueDates->filter(function ($item) {
            return $item->max_duedate <= now()->subMonths(1);
        });

        $maxDueDatesFilteredReal = $maxDueDatesFiltered->filter(function ($item) {
            return $item->max_duedate >= now()->subMonths(4);
        });

        $invoices = Invoiceitem::whereIn('userid', $maxDueDatesFilteredReal->pluck('userid'))
            ->whereIn('relid', $maxDueDatesFilteredReal->pluck('relid'))
            ->whereIn('duedate', $maxDueDatesFilteredReal->pluck('max_duedate'))
            ->select('invoiceid', 'relid', 'duedate', 'userid')
            ->get();

        $invoicesFormatted = $invoices->reject(function ($item) {
            return $item->userid == 18; // Exclude entries with userid equal to 18
        })->map(function ($item) {
            $client = Client::find($item->userid);

            $fullName = $client ? $client->firstname . ' ' . $client->lastname : 'N/A';

            $email = $client ? $client->email : 'N/A';

            $linkAdmin = $client ? 'https://portal.relabs.id/admin/clients/clientsummary?userid=' . $item->userid : 'N/A';

            $lastInvoiceLink = 'https://portal.relabs.id/admin/billing/invoices/edit/' . $item->invoiceid;

            return [
                'Nama' => $fullName,
                'Email' => $email,
                'Link Admin' => $linkAdmin,
                'Last Invoice' => $lastInvoiceLink,
                'Last Due Date' => $item->duedate,
                'hostingid' => $item->relid,
                'invid' => $item->invoiceid,
                'uid' => $item->userid
            ];
        });

        dd($invoicesFormatted);


        // Create CSV content
        $csvContent = $invoicesFormatted->map(function ($row) {
            return implode(',', $row);
        })->prepend(implode(',', array_keys($invoicesFormatted->first())))->implode("\n");

        // Set headers for CSV download
        $headers = [
            'Content-Type' => 'text/csv',
            'Content-Disposition' => 'attachment; filename="late_clients.csv"',
        ];

        // Return CSV as response
        return response()->make($csvContent, 200, $headers);
    }

    public function resendInvoiceWA(Request $request)
    {

        $invoice = DB::table("tblinvoices")->where(['id' => $request->invoiceid])->first();
        $user = DB::table("tblclients")->where(['id' => $invoice->userid])->first();

        $allitem = '';

        $selectinvoiceitemswa2 = "SELECT CONCAT(tblproducts.name, ' - ', tblhosting.domain) as service, tblinvoiceitems.amount, tblhosting.regdate, tblhosting.packageid FROM tblinvoiceitems, tblhosting, tblproducts WHERE tblinvoiceitems.relid = tblhosting.id AND tblhosting.packageid = tblproducts.id AND tblinvoiceitems.invoiceid = ? AND tblinvoiceitems.type IN ('Hosting')";

        $queryselectinvoiceitemswa2 = DB::select($selectinvoiceitemswa2, [$request->invoiceid]);
        $resultselectinvoiceitemsnumrowswa2 = count($queryselectinvoiceitemswa2);

        if ($resultselectinvoiceitemsnumrowswa2 > 0) {
            $allamountregister = 0;
            $allamountrenewal = 0;
            $jenisproduk = 'Hosting';

            foreach ($queryselectinvoiceitemswa2 as $row1) {
                $customdata1[] = (array)$row1;
            }

            foreach ($customdata1 as $row) {
                Log::info(["datawaa", $row]);
                $hosting = $row['service'];
                $regdate = $row['regdate'];
                $packageid = $row['packageid'];

                $allitem = $allitem . $hosting . ", ";
            }
        };

        $phonenumber = preg_replace("/[^0-9]/", "", trim($user->phonenumber));
        $phonenumber = (substr($phonenumber, 0, 2) != '62') ? '62' . substr($phonenumber, 1) : $phonenumber;
        $totalrupiah = "Rp" . number_format($invoice->total, 2, ',', '.');

        $invoicedata = new \App\Helpers\InvoiceClass($invoice->id);
        $invoiceLink = $invoicedata->getPaymentLink();

        $message = "";
        $messagename = "";

        switch ($invoice->paymentmethod) {
            case 'banktransfer':
                $messagename = "Bank Transfer BCA";
                $norek = '037-8770800 A/N RELABS NET DAYACIPTA PT';
                break;
            case 'bcava':
                $message = str_replace(['<strong>', '</strong>'], '*', $invoiceLink->message);
                break;
            case 'bcavaxendit':
                $message = str_replace(['<strong>', '</strong>'], '*', $invoiceLink->message);
                break;
            case 'mandiriva':
                $message = str_replace(['<strong>', '</strong>'], '*', $invoiceLink->message);
                break;
            case 'mandirivaxendit':
                $message = str_replace(['<strong>', '</strong>'], '*', $invoiceLink->message);
                break;
            case 'bniva':
                $message = str_replace(['<strong>', '</strong>'], '*', $invoiceLink->message);
                break;
            case 'bnivaxendit':
                $message = str_replace(['<strong>', '</strong>'], '*', $invoiceLink->message);
                break;
            case 'briva':
                $message = str_replace(['<strong>', '</strong>'], '*', $invoiceLink->message);
                break;
            case 'brivaxendit':
                $message = str_replace(['<strong>', '</strong>'], '*', $invoiceLink->message);
                break;
            case 'permatabankva':
                $message = str_replace(['<strong>', '</strong>'], '*', $invoiceLink->message);
                break;
            case 'permatabankvaxendit':
                $message = str_replace(['<strong>', '</strong>'], '*', $invoiceLink->message);
                break;
            case 'sampoernava':
                $message = str_replace(['<strong>', '</strong>'], '*', $invoiceLink->message);
                break;
            case 'sampoernavaxendit':
                $message = str_replace(['<strong>', '</strong>'], '*', $invoiceLink->message);
                break;
            case 'atmbersamaxendit':
                $message = str_replace(['<strong>', '</strong>'], '*', $invoiceLink->message);
                break;
            case 'danaxendit':
                $messagename = "DANA";
                $norek = 'Login Akun Relabs -> Buka Invoice -> Ikuti sesuai Petunjuk tertera';
                break;
            case 'ovoxendit':
                $messagename = "OVO";
                $norek = 'Login Akun Relabs -> Buka Invoice -> Ikuti sesuai Petunjuk tertera';
                break;
            case 'linkajaxendit':
                $messagename = "LinkAja";
                $norek = 'Login Akun Relabs -> Buka Invoice -> Ikuti sesuai Petunjuk tertera';
                break;
            case 'gopaymidtrans':
                $messagename = "GoPay";
                $norek = 'Login Akun Relabs -> Buka Invoice -> Ikuti sesuai Petunjuk tertera';
                break;
            case 'ccmidtrans':
                $messagename = "Credit Card (Visa, Mastercard, JBC, American Express)";
                $norek = 'Login Akun Relabs -> Buka Invoice -> Ikuti sesuai Petunjuk tertera';
                break;
            case 'alfamartxendit':
                $messagename = "Alfamart";
                $norek = 'Login Akun Relabs -> Buka Invoice -> Ikuti sesuai Petunjuk tertera';
                break;
            case 'shopeepayxendit':
                $messagename = "ShopeePay";
                $norek = 'Login Akun Relabs -> Buka Invoice -> Ikuti sesuai Petunjuk tertera';
                break;
            default:
                $messagename = "";
                $norek = '';
                break;
        }


        try {

            // Disable notif sampai perhitungannya stabil
            // $pidkhususjogja = [45,46,47];

            if (false) {

                // ga ada notif

            } else {

                $url = 'https://portal.qwords.com/apis/wa/relabs.php';
                $data = [
                    'phone' => $phonenumber,
                    'firstname' => $user->firstname,
                    'message' => $message,
                    'messagename' => $messagename,
                    'norek' => $norek,
                    'allitem' => $allitem,
                    'invoiceid' => $invoice->id,
                    'duedate' => $invoice->duedate,
                    'totalrupiah' => $totalrupiah,
                ];
                // Log::info("SendWaInvoice data ".$data);
                Log::info("SendWaInvoice data " . json_encode($data)); // Perbaikan di sini


                if ($request->preview == true) {
                    dd($data);
                }
                $response = Http::post($url, $data);
                Log::info("SendWaInvoice response " . $response->body());
                LogActivity::Save("Pengiriman WA " . $invoice->id);
                echo "Sukses Terkirim";
            }
        } catch (\Exception $e) {
            Log::debug("SendWaInvoice error " . $e->getMessage());
        }
    }

    public function index()
    {
        return view('sendinvoicewa::index');
    }

    public function resendInvoiceWABulk(Request $request)
    {
        // Validasi input
        $request->validate([
            'groupid' => 'required|numeric'
        ]);

        // Ambil semua client berdasarkan groupid dan memiliki invoice yang unpaid
        $clients = DB::table("tblclients as c")
            ->join('tblinvoices as i', 'c.id', '=', 'i.userid')
            ->where('c.groupid', $request->groupid)
            ->where('c.status', 'Active')
            ->where('i.status', 'Unpaid')
            ->select('c.*', 'i.id as invoice_id', 'i.total', 'i.paymentmethod', 'i.duedate')
            ->distinct()
            ->get();

        $totalClients = $clients->count();

        if ($totalClients == 0) {
            return "Tidak ada client dengan invoice unpaid ditemukan untuk group ini";
        }

        $successCount = 0;
        $failedCount = 0;
        $errors = [];

        foreach ($clients as $index => $client) {
            try {
                $allitem = '';

                // Query untuk mendapatkan item hosting
                $selectinvoiceitemswa2 = "SELECT CONCAT(tblproducts.name, ' - ', tblhosting.domain) as service, tblinvoiceitems.amount, tblhosting.regdate, tblhosting.packageid FROM tblinvoiceitems, tblhosting, tblproducts WHERE tblinvoiceitems.relid = tblhosting.id AND tblhosting.packageid = tblproducts.id AND tblinvoiceitems.invoiceid = ? AND tblinvoiceitems.type IN ('Hosting')";

                $queryselectinvoiceitemswa2 = DB::select($selectinvoiceitemswa2, [$client->invoice_id]);
                $resultselectinvoiceitemsnumrowswa2 = count($queryselectinvoiceitemswa2);

                if ($resultselectinvoiceitemsnumrowswa2 > 0) {
                    $customdata1 = [];
                    foreach ($queryselectinvoiceitemswa2 as $row1) {
                        $customdata1[] = (array)$row1;
                    }

                    foreach ($customdata1 as $row) {
                        Log::info(["datawaa", $row]);
                        $hosting = $row['service'];
                        $allitem .= $hosting . ", ";
                    }
                }

                // Format nomor telepon
                $phonenumber = preg_replace("/[^0-9]/", "", trim($client->phonenumber));
                $phonenumber = (substr($phonenumber, 0, 2) != '62') ? '62' . substr($phonenumber, 1) : $phonenumber;
                $totalrupiah = "Rp" . number_format($client->total, 2, ',', '.');

                $invoicedata = new InvoiceClass($client->invoice_id);
                $invoiceLink = $invoicedata->getPaymentLink();

                $message = "";
                $messagename = "";
                $norek = "";

                // Payment method switch
                switch ($client->paymentmethod) {
                    case 'banktransfer':
                        $messagename = "Bank Transfer BCA";
                        $norek = '037-8770800 A/N RELABS NET DAYACIPTA PT';
                        break;
                        // ... sisanya sama seperti sebelumnya ...
                }

                $data = [
                    'phone' => $phonenumber,
                    'firstname' => $client->firstname,
                    'message' => $message,
                    'messagename' => $messagename,
                    'norek' => $norek,
                    'allitem' => $allitem,
                    'invoiceid' => $client->invoice_id,
                    'duedate' => $client->duedate,
                    'totalrupiah' => $totalrupiah,
                ];

                Log::info("SendWaInvoice data " . json_encode($data));

                $url = 'https://portal.qwords.com/apis/wa/relabs.php';
                $response = Http::post($url, $data);

                Log::info("SendWaInvoice response " . $response->body());
                LogActivity::Save("Pengiriman WA " . $client->invoice_id);

                $successCount++;

                sleep(15);
            } catch (\Exception $e) {
                $failedCount++;
                $errors[] = "Failed to send WA to client {$client->id}: " . $e->getMessage();
                Log::debug("SendWaInvoice error " . $e->getMessage());
            }
        }

        return "Selesai mengirim WA: Berhasil: {$successCount}, Gagal: {$failedCount}";
    }

    // public function sendCustomWA(Request $request)
    // {
    //     // Validasi input
    //     $request->validate([
    //         'message' => 'required|string',
    //         'delay' => 'required|integer|min:1'
    //     ]);

    //     // Ambil semua client yang aktif
    //     $clients = DB::table("tblclients")
    //         ->where('status', 'Active')
    //         ->select('id', 'firstname', 'lastname', 'phonenumber')
    //         ->get();

    //     $totalClients = $clients->count();

    //     if ($totalClients == 0) {
    //         return "Tidak ada client aktif yang ditemukan";
    //     }

    //     $successCount = 0;
    //     $failedCount = 0;
    //     $errors = [];

    //     foreach ($clients as $client) {
    //         try {
    //             // Format nomor telepon
    //             $phonenumber = preg_replace("/[^0-9]/", "", trim($client->phonenumber));
    //             $phonenumber = (substr($phonenumber, 0, 2) != '62') ? '62' . substr($phonenumber, 1) : $phonenumber;

    //             $data = [
    //                 'phone' => $phonenumber,
    //                 'firstname' => $client->firstname,
    //                 'message' => $request->message,
    //                 'messagename' => 'Custom Message',
    //                 'norek' => '',
    //                 'allitem' => '',
    //                 'invoiceid' => '',
    //                 'duedate' => '',
    //                 'totalrupiah' => '',
    //             ];

    //             \Log::info("SendCustomWA data " . json_encode($data));

    //             $url = 'https://portal.qwords.com/apis/wa/relabs.php';
    //             $response = Http::post($url, $data);

    //             \Log::info("SendCustomWA response " . $response->body());
    //             \LogActivity::Save("Pengiriman Custom WA ke " . $client->firstname . " " . $client->lastname);

    //             $successCount++;

    //             // Delay sesuai input user
    //             sleep($request->delay);
    //         } catch (\Exception $e) {
    //             $failedCount++;
    //             $errors[] = "Failed to send WA to client {$client->id}: " . $e->getMessage();
    //             \Log::debug("SendCustomWA error " . $e->getMessage());
    //         }
    //     }

    //     return "Selesai mengirim WA: Berhasil: {$successCount}, Gagal: {$failedCount}";
    // }
    public function sendCustomWA(Request $request)
    {
        $request->validate([
            'message' => 'required|string',
            'delay' => 'required|integer|min:1'
        ]);

        $clients = DB::table("tblclients")
            ->where('status', 'Active')
            ->select('id', 'phonenumber')
            ->get();

        $totalClients = $clients->count();
        
        if ($totalClients == 0) {
            return "Tidak ada client aktif yang ditemukan";
        }

        $successCount = 0;
        $failedCount = 0;

        foreach ($clients as $client) {
            try {
                $phonenumber = preg_replace("/[^0-9]/", "", trim($client->phonenumber));
                $phonenumber = (substr($phonenumber,0,2) !='62') ? '62'.substr($phonenumber,1) : $phonenumber;

                $data = [
                    'phone' => $phonenumber,
                    'message' => $request->message,
                    'isCustomMessage' => true
                ];

                $url = 'https://portal.qwords.com/apis/wa/relabs.php';
                $response = Http::post($url, $data);
                
                Log::info("SendCustomWA response ".$response->body());
                $successCount++;
                
                sleep($request->delay);

            } catch (\Exception $e) {
                $failedCount++;
                Log::debug("SendCustomWA error ".$e->getMessage());
            }
        }

        return "Selesai mengirim WA: Berhasil: {$successCount}, Gagal: {$failedCount}";
    }
}