<?php

return [
    'name' => 'SellDomain'
];
