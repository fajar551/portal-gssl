<?php

return [
    'name' => 'Directadmin'
];
