<?php

namespace Modules\Servers\CPanel\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use Illuminate\Support\Facades\Log;
use Modules\Servers\CPanel\Services\CpanelService;
use App\Helpers\AdminFunctions;
use App\Helpers\ResponseAPI;
use App\Helpers\Database;
use App\Helpers\LogActivity;
use App\Models\Hosting;
use App\Traits\DatatableFilter;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\Http;
use App\Models\Product as ProductModel;

class CPanelController extends Controller
{
    use DatatableFilter;
    protected $prefix;
    protected $cpanelService;

    public function __construct(CpanelService $cpanelService = null)  // Tambahkan default null
    {
        $this->cpanelService = $cpanelService ?? new CpanelService(); // Jika null, buat instance baru
        $this->middleware(['auth:admin']);
        $this->prefix = Database::prefix();
    }
    
    public function index()
    {
        return view('cpanel::index');
    }

    public function moduleCommand(Request $request)
    {
        try {
            $cpanel = app(CpanelService::class);

            $userid = $request->userid;
            $id = $request->id;
            $modop = $request->modop;
            $serviceId = $request->input('id');

            // Validasi permission
            if (!AdminFunctions::checkPermission("Perform Server Operations")) {
                return ResponseAPI::Error([
                    'message' => AdminFunctions::infoBoxMessage('<b>Oh No!</b>', AdminFunctions::getNoPermissionMessage()),
                ]);
            }

            // Ambil data service dengan relasi
            // $service = Hosting::with(['product', 'client', 'server'])->findOrFail($id);
            $service = Hosting::findOrFail($serviceId);
            $username = $service->username;
            $newPackage = $request->input('package');

            // Log awal eksekusi
            Log::info('Starting module command execution', [
                'command' => $modop,
                'service_id' => $id,
                'user_id' => $userid,
                'username' => $service->username,
                'domain' => $service->domain,
                'package' => $service->product->name ?? 'default',
                'server_id' => $service->server
            ]);

            if ($modop == "getpackages") {
                try {
                    // Ambil daftar paket dari cPanel
                    $result = $this->cpanelService->getPackages();

                    Log::info('CPanel getPackages result', [
                        'result' => $result
                    ]);

                    if (!$result['success']) {
                        throw new \Exception($result['message']);
                    }

                    // Gunakan packagename dari service
                    $currentPackage = $service->packagename ?? 'WireBusiness_Fiber_50'; // default fallback
                    $packages = $result['data'];

                    Log::info('Processing packages', [
                        'current_package' => $currentPackage,
                        'available_packages' => $packages
                    ]);

                    // Build HTML options
                    $options = '<option value="">Pilih paket baru</option>';
                    foreach ($packages as $package) {
                        // Normalize package names for comparison
                        $normalizedPackage = trim(str_replace([' ', '-'], '_', strtolower($package)));
                        $normalizedCurrentPackage = trim(str_replace([' ', '-'], '_', strtolower($currentPackage)));

                        Log::info('Comparing packages', [
                            'normalized_package' => $normalizedPackage,
                            'normalized_current' => $normalizedCurrentPackage,
                            'original_package' => $package,
                            'original_current' => $currentPackage
                        ]);

                        // Skip if this is the current package
                        if ($normalizedPackage === $normalizedCurrentPackage) {
                            continue;
                        }

                        $displayName = str_replace('_', ' ', $package);
                        $options .= sprintf(
                            '<option value="%s">%s</option>',
                            htmlspecialchars($package),
                            htmlspecialchars($displayName)
                        );
                    }

                    return response()->json([
                        'result' => 'success',
                        'data' => [
                            'current_package' => $currentPackage,
                            'package_options' => $options
                        ]
                    ]);
                } catch (\Exception $e) {
                    Log::error('Error getting packages', [
                        'error' => $e->getMessage(),
                        'trace' => $e->getTraceAsString()
                    ]);

                    return response()->json([
                        'result' => 'error',
                        'message' => 'Gagal mengambil data paket: ' . $e->getMessage()
                    ]);
                }
            }

            if ($modop === 'changepackage') {
                try {
                    $newPackage = $request->input('packagename');
                    
                    if (empty($newPackage)) {
                        throw new \Exception('Package name cannot be empty');

                    Log::info('Starting package change', [
                        'username' => $service->username,
                        'new_package' => $newPackage,
                        'request_data' => $request->all()
                    ]);
                    
                    // Validasi package name
                    $packages = $this->cpanelService->getPackages();
                    if (!$packages['success']) {
                        throw new \Exception('Failed to get package list: ' . ($packages['message'] ?? 'Unknown error'));
                    }

                    if (!in_array($newPackage, $packages['data'])) {
                        throw new \Exception("Package '$newPackage' not found in WHM");
                    }

                    // Ubah package di WHM
                    $result = $this->cpanelService->changePackage($service->username, $newPackage);
                    
                    if (!$result['success']) {
                        throw new \Exception($result['message'] ?? 'Failed to change package in WHM');
                    }

                    // Tidak perlu update di database karena packageid tidak berubah
                    Log::info('Package changed successfully in WHM', [
                        'username' => $service->username,
                        'new_package' => $newPackage,
                        'whm_response' => $result
                    ]);

                    return response()->json([
                        'result' => 'success',
                        'message' => 'Package changed successfully'
                    ]);

                } catch (\Exception $e) {
                    Log::error('Change package error', [
                        'error' => $e->getMessage(),
                        'username' => $service->username ?? null,
                        'requested_package' => $newPackage ?? null,
                        'trace' => $e->getTraceAsString()
                    ]);

                    return response()->json([
                        'result' => 'error',
                        'message' => $e->getMessage()
                    ]);
                }
            }

            if ($modop == "changepw") {
                $newPassword = $request->input('password');
                if (empty($newPassword)) {
                    throw new \Exception('Password baru tidak boleh kosong');
                }

                // Ambil username dari service
                $username = $service->username;
                if (empty($username)) {
                    throw new \Exception('Username tidak ditemukan');
                }

                $result = $this->cpanelService->changePassword([
                    'username' => $username,
                    'password' => $newPassword
                ]);

                if (!$result['success']) {
                    throw new \Exception($result['message']);
                }

                return ResponseAPI::Success([
                    'message' => AdminFunctions::infoBoxMessage('<b>Success!</b>', 'Password berhasil diubah')
                ]);
            }

            switch ($modop) {
                case "create":
                    // Validasi data hosting
                    $this->validateHostingData($service);

                    // Dekripsi password
                    try {
                        $decryptedPassword = decrypt($service->password);
                    } catch (\Exception $e) {
                        Log::error('Password decryption failed', ['error' => $e->getMessage()]);
                        $decryptedPassword = $service->password;
                    }

                    // Format package name
                    $packageName = str_replace(' ', '_', $service->product->name);

                    // Buat akun cPanel
                    $cpanel = app(CpanelService::class);
                    $result = $cpanel->createAccount([
                        'username' => strtolower($service->username),
                        'domain' => $service->domain,
                        'password' => $decryptedPassword,
                        'package' => $packageName,
                        'ip' => 'n',
                        'cgi' => 1,
                        'hasshell' => 0,
                        'contactemail' => $service->client->email ?? '',
                        'maxftp' => 'unlimited',
                        'maxsql' => 'unlimited',
                        'maxpop' => 'unlimited',
                        'maxlst' => 'unlimited',
                        'maxsub' => 'unlimited',
                        'maxpark' => 'unlimited',
                        'maxaddon' => 'unlimited',
                        'bwlimit' => 'unlimited'
                    ]);

                    Log::info('cPanel API Response', [
                        'service_id' => $id,
                        'response' => $result
                    ]);

                    if (!$result['success']) {
                        throw new \Exception($result['message'] ?? 'Unknown error occurred');
                    }

                    // Update status
                    $service->domainstatus = 'Active';
                    $service->save();

                    return ResponseAPI::Success([
                        'message' => AdminFunctions::infoBoxMessage('<b>Success!</b>', 'Akun berhasil dibuat'),
                        'data' => $result
                    ]);

                case "suspend":
                    $reason = $request->input('reason', 'Suspended by admin');

                    $result = $cpanel->suspendAccount([
                        'username' => $service->username,
                        'reason' => $reason
                    ]);

                    if (!$result['success']) {
                        throw new \Exception($result['message']);
                    }

                    $service->domainstatus = 'Suspended';
                    $service->save();

                    return ResponseAPI::Success([
                        'message' => AdminFunctions::infoBoxMessage('<b>Success!</b>', 'Akun berhasil disuspend')
                    ]);

                case "unsuspend":
                    $result = $cpanel->unsuspendAccount([
                        'username' => $service->username
                    ]);

                    if (!$result['success']) {
                        throw new \Exception($result['message']);
                    }

                    $service->domainstatus = 'Active';
                    $service->save();

                    return ResponseAPI::Success([
                        'message' => AdminFunctions::infoBoxMessage('<b>Success!</b>', 'Akun berhasil diunsuspend')
                    ]);

                case "terminate":
                    $result = $cpanel->terminateAccount([
                        'username' => $service->username
                    ]);

                    if (!$result['success']) {
                        throw new \Exception($result['message']);
                    }

                    $service->domainstatus = 'Terminated';
                    $service->save();

                    return ResponseAPI::Success([
                        'message' => AdminFunctions::infoBoxMessage('<b>Success!</b>', 'Akun berhasil diterminasi')
                    ]);

                case "changepw":
                    $newPassword = $request->input('password');
                    if (empty($newPassword)) {
                        throw new \Exception('Password baru tidak boleh kosong');
                    }

                    $result = $cpanel->changePassword([
                        'username' => $service->username,
                        'password' => $newPassword
                    ]);

                    if (!$result['success']) {
                        throw new \Exception($result['message']);
                    }

                    // Enkripsi dan simpan password baru
                    $service->password = encrypt($newPassword);
                    $service->save();

                    return ResponseAPI::Success([
                        'message' => AdminFunctions::infoBoxMessage('<b>Success!</b>', 'Password berhasil diubah')
                    ]);

                case "custom":
                    // Handle custom commands
                    return $this->handleCustomCommand($request, $service);

                case "singleSignOn":
                    $result = $cpanel->createLoginToken([
                        'username' => $service->username
                    ]);

                    if (!$result['success']) {
                        throw new \Exception($result['message']);
                    }

                    return ResponseAPI::Success([
                        'message' => AdminFunctions::infoBoxMessage('<b>Success!</b>', 'Login token berhasil dibuat'),
                        'data' => [
                            'url' => $result['data']['url'] ?? null
                        ]
                    ]);

                default:
                    return ResponseAPI::Error([
                        'message' => AdminFunctions::infoBoxMessage('<b>Oh No!</b>', 'Invalid module command!')
                    ]);
            }
        } catch (\Exception $e) {
            Log::error('Module Command Error', [
                'error' => $e->getMessage(),
                'command' => $modop ?? 'unknown',
                'service_id' => $id ?? 'unknown',
                'user_id' => $userid ?? 'unknown',
                'trace' => $e->getTraceAsString()
            ]);

            return ResponseAPI::Error([
                'message' => AdminFunctions::infoBoxMessage('<b>Oh No!</b>', $e->getMessage())
            ]);
        }
    }

    private function decryptPassword($password)
    {
        try {
            // Implementasi dekripsi sesuai dengan metode enkripsi yang digunakan
            // Contoh sederhana (sesuaikan dengan metode enkripsi yang digunakan):
            return $password;
        } catch (\Exception $e) {
            Log::error('Password decryption failed', ['error' => $e->getMessage()]);
            throw new \Exception('Gagal mendekripsi password');
        }
    }

    private function create(Request $request)
    {
        $id = $request->id;

        try {
            // Ambil data hosting
            $service = Hosting::findOrFail($id);

            // Validasi data hosting
            $this->validateHostingData($service);

            // Log attempt create
            Log::info('Creating cPanel account', [
                'service_id' => $id,
                'username' => $service->username,
                'domain' => $service->domain,
                'package' => $service->packagename
            ]);

            // Buat akun di cPanel
            $result = $this->cpanelService->createAccount([
                'username' => $service->username,
                'domain' => $service->domain,
                'password' => $service->password,
                'package' => $service->packagename
            ]);

            if (!$result['success']) {
                throw new \Exception($result['message']);
            }

            // Update status service
            $service->domainstatus = 'Active';
            $service->save();

            // Log activity
            LogActivity::Save("Created cPanel Account - Service ID: $id", $request->userid);

            return ResponseAPI::Success([
                'message' => AdminFunctions::infoBoxMessage('<b>Success!</b>', 'Account has been created successfully!')
            ]);
        } catch (\Exception $e) {
            Log::error('Error creating cPanel account', [
                'error' => $e->getMessage(),
                'service_id' => $id
            ]);

            return ResponseAPI::Error([
                'message' => AdminFunctions::infoBoxMessage('<b>Error!</b>', $e->getMessage())
            ]);
        }
    }

    private function renew(Request $request)
    {
        $id = $request->id;
        $aid = $request->aid;
        $modop = $request->modop;

        $result = (new \App\Module\Server())->ServerRenew($id, (int) $aid);
        return $this->getResponse($modop, $result);
    }

    public function suspend(Request $request)
    {
        try {
            $id = $request->id;
            $service = Hosting::findOrFail($id);

            Log::info('Attempting to suspend account', [
                'service_id' => $id,
                'username' => $service->username,
                'domain' => $service->domain,
                'reason' => $request->suspreason
            ]);

            $result = $this->cpanelService->suspendAccount(
                $service->username,
                $request->input('suspreason', 'Account suspended via admin area')
            );

            if (!$result['success']) {
                throw new \Exception($result['message'] ?? 'Failed to suspend account');
            }

            // Update status di database
            $service->domainstatus = Hosting::STATUS_SUSPENDED;
            $service->save();

            LogActivity::Save("Suspended cPanel Account - Service ID: $id", $request->userid);

            return ResponseAPI::Success([
                'message' => AdminFunctions::infoBoxMessage(
                    '<b>Success!</b>',
                    'Account has been suspended successfully!'
                )
            ]);
        } catch (\Exception $e) {
            Log::error('Error suspending cPanel account', [
                'service_id' => $id ?? null,
                'error' => $e->getMessage()
            ]);

            return ResponseAPI::Error($e->getMessage());
        }
    }

    private function unsuspend(Request $request)
    {
        $id = $request->id;

        try {
            $service = Hosting::findOrFail($id);
            $cpanel = app(CpanelService::class);

            $result = $cpanel->unsuspendAccount($service->username);

            if (!$result['success']) {
                throw new \Exception($result['message']);
            }

            // Update service status
            $service->domainstatus = 'Active';
            $service->suspendreason = '';
            $service->save();

            return $this->getResponse('unsuspend', 'success');
        } catch (\Exception $e) {
            return $this->getResponse('unsuspend', $e->getMessage());
        }
    }

    private function terminate(Request $request)
    {
        $id = $request->id;

        try {
            $service = Hosting::findOrFail($id);
            $cpanel = app(CpanelService::class);

            $result = $cpanel->terminateAccount($service->username);

            if (!$result['success']) {
                throw new \Exception($result['message']);
            }

            // Update service status
            $service->domainstatus = 'Terminated';
            $service->termination_date = now();
            $service->save();

            return $this->getResponse('terminate', 'success');
        } catch (\Exception $e) {
            return $this->getResponse('terminate', $e->getMessage());
        }
    }

    public function changePackage($username, $newPackage)
    {
        try {
            Log::info('Starting package change', [
                'username' => $username,
                'new_package' => $newPackage
            ]);

            // 1. Validasi package baru
            $product = ProductModel::where('name', $newPackage)->first();
            if (!$product) {
                throw new \Exception('Package tidak ditemukan');
            }

            // 2. Update hosting
            $hosting = Hosting::where('username', $username)->first();
            if (!$hosting) {
                throw new \Exception('Hosting tidak ditemukan');
            }

            // 3. Update data hosting
            $hosting->packageid = $product->id;
            $hosting->packagename = $product->name;
            $hosting->save();

            // 4. Panggil API cPanel
            $response = Http::withHeaders([
                'Authorization' => 'WHM ' . config('cpanel.username') . ':' . config('cpanel.token')
            ])
                ->withOptions(['verify' => false])
                ->post(config('cpanel.hostname') . '/json-api/changepackage', [
                    'api.version' => 1,
                    'user' => $username,
                    'pkg' => $newPackage
                ]);

            Log::info(
                'Change package response',
                [
                    'response' => $response->json()
                ]
            );

            return [
                'success' => true,
                'data' => $response->json()
            ];
        } catch (\Exception $e) {
            Log::error('Error changing package', [
                'error' => $e->getMessage(),
                'username' => $username,
                'new_package' => $newPackage
            ]);

            return [
                'success' => false,
                'message' => $e->getMessage()
            ];
        }
    }

    private function changepw(Request $request)
    {
        $id = $request->id;

        try {
            $service = Hosting::findOrFail($id);
            $cpanel = app(CpanelService::class);

            // Generate random password
            $newPassword = Str::random(12);

            $result = $cpanel->changePassword($service->username, $newPassword);

            if (!$result['success']) {
                throw new \Exception($result['message']);
            }

            // Update password in database
            $service->password = $newPassword;
            $service->save();

            return $this->getResponse('changepw', 'success');
        } catch (\Exception $e) {
            return $this->getResponse('changepw', $e->getMessage());
        }
    }
    // Helper method untuk validasi data hosting
    private function validateHostingData($service)
    {
        if (empty($service->username)) {
            throw new \Exception('Username tidak boleh kosong');
        }
        if (empty($service->domain)) {
            throw new \Exception('Domain tidak boleh kosong');
        }
        if (empty($service->password)) {
            throw new \Exception('Password tidak boleh kosong');
        }
        if (empty($service->product->name)) {
            throw new \Exception('Package tidak boleh kosong');
        }
    }

    // Helper method untuk handle custom commands
    private function handleCustomCommand($request, $service)
    {
        $command = $request->input('command');
        $params = $request->input('params', []);

        if (empty($command)) {
            throw new \Exception('Custom command tidak boleh kosong');
        }

        $cpanel = app(CpanelService::class);
        $result = $cpanel->executeCustomCommand($command, array_merge([
            'username' => $service->username
        ], $params));

        if (!$result['success']) {
            throw new \Exception($result['message']);
        }

        return ResponseAPI::Success([
            'message' => AdminFunctions::infoBoxMessage('<b>Success!</b>', 'Custom command berhasil dieksekusi'),
            'data' => $result['data']
        ]);
    }

    // Tambahkan validasi sebelum melakukan suspend
    private function validateServiceData($service)
    {
        // Tambahkan validasi lainnya yang sesuai dengan kebutuhan
        // Misalnya, periksa apakah service memiliki status yang valid untuk suspend
        // atau periksa apakah ada kondisi lain yang perlu diperiksa
        // ...
    }

    public function getProducts(Request $request)
    {
        try {
            $serviceId = $request->input('id');

            // Ambil data service
            $service = Hosting::with(['product'])->findOrFail($serviceId);

            // Ambil daftar produk yang sesuai
            $products = ProductModel::where('servertype', $service->product->servertype)
                ->where('type', $service->product->type)
                ->where('hidden', 0)
                ->orderBy('name', 'asc')
                ->get(['id', 'name']);

            return response()->json([
                'success' => true,
                'data' => $products
            ]);
        } catch (\Exception $e) {
            Log::error('Error getting products', [
                'error' => $e->getMessage(),
                'service_id' => $serviceId ?? null
            ]);

            return response()->json([
                'success' => false,
                'message' => $e->getMessage()
            ]);
        }
    }

}