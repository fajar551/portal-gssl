<div class="form-group row">
    <label for="#" class="col-sm-2 col-form-label">Module Commands</label>
    <div class="col-sm-10">
        @if ($module)
            @if ($moduleInterface->functionExists('CreateAccount'))
                <button type="button" class="btn btn-light my-1 mx-1" onclick="modCommand('Create');">
                    Create
                </button>
            @endif

            @if ($moduleInterface->functionExists('Renew'))
                <button type="button" class="btn btn-light my-1 mx-1" onclick="modCommand('Renew');">
                    Renew
                </button>
            @endif

            @if ($moduleInterface->functionExists('SuspendAccount'))
                <button type="button" class="btn btn-light my-1 mx-1" onclick="modCommand('Suspend');">
                    Suspend
                </button>
            @endif

            @if ($moduleInterface->functionExists('UnsuspendAccount'))
                <button type="button" class="btn btn-light my-1 mx-1" onclick="modCommand('Unsuspend');">
                    Unsuspend
                </button>
            @endif

            @if ($moduleInterface->functionExists('TerminateAccount'))
                <button type="button" class="btn btn-light my-1 mx-1" onclick="modCommand('Terminate');">
                    Terminate
                </button>
            @endif

            {{-- @if ($moduleInterface->functionExists('ChangePackage'))
                <button type="button" class="btn btn-light my-1 mx-1" 
                    onclick="moduleCommand('changepackage')"
                    data-package="{{ $service->packagename ?? 'WireBusiness_Fiber_50' }}"
                    data-userid="{{ $userid }}"
                    data-id="{{ $id }}">
                    Change Package
                </button>
            @endif --}}
            {{-- @if ($moduleInterface->functionExists('ChangePackage'))
                <button type="button" class="btn btn-light my-1 mx-1" onclick="moduleCommand('changepackage')"
                    data-package="{{ $service->packagename }}" data-userid="{{ $userid }}"
                    data-id="{{ $id }}">
                    Change Package
                </button>
            @endif --}}

            @if ($moduleInterface->functionExists('ChangePackage'))
                <button type="button" class="btn btn-light my-1 mx-1" 
                    onclick="moduleCommand('changepackage')"
                    {{-- data-package="{{ $service->packagename }}" --}}
                    data-package="{{ $service->packagename }}"
                    data-userid="{{ $userid }}"
                    data-id="{{ $id }}">
                    Change Package
                </button>
            @endif

            @if ($moduleInterface->functionExists('ChangePassword'))
                <button type="button" class="btn btn-light my-1 mx-1" data-toggle="modal"
                    data-target="#changePasswordModal">
                    Change Password
                </button>
            @endif

            @if ($moduleInterface->isApplicationLinkingEnabled() && $moduleInterface->isApplicationLinkSupported())
                <button type="button" class="btn btn-light my-1 mx-1" onclick="modCommand('ManageAppLinks');">
                    Manage App Links
                </button>
            @endif

            @if ($moduleInterface->functionExists('AdminCustomButtonArray'))
                <br>
                {!! implode(' ', $modulebtns) !!}
            @endif
        @endif
    </div>
</div>
