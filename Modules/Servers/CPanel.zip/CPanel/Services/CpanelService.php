<?php

namespace Modules\Servers\CPanel\Services;

use GuzzleHttp\Client;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Http;

class CpanelService
{
    /** @var string */
    protected $baseUrl;
    
    /** @var array */
    protected $headers;
    
    /** @var string */
    protected $hostname;
    
    /** @var string */
    protected $username;
    
    /** @var string */
    protected $token;

    /** @var Client */
    protected $client;

    public function __construct()
    {
        $this->hostname = config('cpanel.hostname');
        $this->username = config('cpanel.username');
        $this->token = config('cpanel.token');

        $this->baseUrl = $this->hostname . '/json-api/';
        $this->headers = [
            'Authorization' => 'WHM ' . $this->username . ':' . $this->token,
            'Content-Type' => 'application/json'
        ];

        // $this->client = new Client([
        //     'verify' => false,
        //     'timeout' => 30,
        //     'headers' => $this->headers
        // ]);
    }

    // Create Account
    public function createAccount($data)
    {
        try {
            // Format package name
            $packageName = str_replace(' ', '_', $data['package']);

            // Basic params
            $params = [
                'api.version' => 2,
                'username' => strtolower($data['username']),
                'domain' => $data['domain'],
                'password' => $data['password'],
                'pkgname' => $packageName ?? 'default',
                'featurelist' => 'default',
                'quota' => 'unlimited',
                'ip' => 'n',
                'cgi' => 1,
                'hasshell' => 0,
                'contactemail' => $data['contactemail'] ?? '',
                'maxftp' => 'unlimited',
                'maxsql' => 'unlimited',
                'maxpop' => 'unlimited',
                'maxlst' => 'unlimited',
                'maxsub' => 'unlimited',
                'maxpark' => 'unlimited',
                'maxaddon' => 'unlimited',
                'bwlimit' => 'unlimited'
            ];

            Log::info('cPanel API Request', [
                'url' => $this->baseUrl . 'createacct',
                'username' => $params['username'],
                'domain' => $params['domain'],
                'package' => $params['pkgname']
            ]);

            $response = Http::withHeaders($this->headers)
                ->withOptions([
                    'verify' => false,
                    'timeout' => 30
                ])
                ->post($this->baseUrl . 'createacct', $params);

            $responseData = $response->json();

            Log::info('cPanel API Response', [
                'status' => $response->status(),
                'data' => $responseData
            ]);

            if ($response->successful()) {
                return [
                    'success' => true,
                    'message' => 'Account created successfully',
                    'data' => $responseData
                ];
            }

            return [
                'success' => false,
                'message' => $responseData['metadata']['reason'] ?? $response->body(),
                'data' => $responseData
            ];
        } catch (\Exception $e) {
            Log::error('cPanel API Error', [
                'error' => $e->getMessage(),
                'trace' => $e->getTraceAsString()
            ]);

            return [
                'success' => false,
                'message' => $e->getMessage(),
                'data' => null
            ];
        }
    }

    // Suspend Account
    public function suspendAccount($params)
    {
        try {
            $headers = [
                'Authorization' => $this->headers['Authorization']
            ];

            Log::info('Attempting to suspend account', [
                'username' => $params['username']
            ]);

            $response = Http::withHeaders($headers)
                ->withOptions([
                    'verify' => false
                ])
                ->asForm()
                ->post($this->baseUrl . 'suspendacct', [
                    'api.version' => 1,
                    'user' => $params['username'],
                    'reason' => $params['reason'] ?? 'Suspended by admin'
                ]);

            Log::info('cPanel Suspend Account Response', [
                'response' => $response->body()
            ]);

            return $this->handleResponse($response);
        } catch (\Exception $e) {
            Log::error('Error in suspendAccount', [
                'error' => $e->getMessage(),
                'username' => $params['username']
            ]);

            return [
                'success' => false,
                'message' => 'Failed to suspend account: ' . $e->getMessage()
            ];
        }
    }

    // Unsuspend Account
    public function unsuspendAccount($params)
    {
        try {
            $headers = [
                'Authorization' => $this->headers['Authorization']
            ];

            Log::info('Attempting to unsuspend account', [
                'username' => $params['username']
            ]);

            $response = Http::withHeaders($headers)
                ->withOptions([
                    'verify' => false
                ])
                ->asForm()
                ->post($this->baseUrl . 'unsuspendacct', [
                    'api.version' => 1,
                    'user' => $params['username']
                ]);

            Log::info('cPanel Unsuspend Account Response', [
                'response' => $response->body()
            ]);

            return $this->handleResponse($response);
        } catch (\Exception $e) {
            Log::error('Error in unsuspendAccount', [
                'error' => $e->getMessage(),
                'username' => $params['username']
            ]);

            return [
                'success' => false,
                'message' => 'Failed to unsuspend account: ' . $e->getMessage()
            ];
        }
    }

    // Terminate Account
    public function terminateAccount($params)
    {
        try {
            $headers = [
                'Authorization' => $this->headers['Authorization']
            ];

            Log::info('Attempting to terminate account', [
                'username' => $params['username']
            ]);

            $response = Http::withHeaders($headers)
                ->withOptions([
                    'verify' => false
                ])
                ->asForm()
                ->post($this->baseUrl . 'removeacct', [
                    'api.version' => 1,
                    'username' => $params['username']
                ]);

            Log::info('cPanel Terminate Account Response', [
                'response' => $response->body()
            ]);

            return $this->handleResponse($response);
        } catch (\Exception $e) {
            Log::error('Error in terminateAccount', [
                'error' => $e->getMessage(),
                'username' => $params['username']
            ]);

            return [
                'success' => false,
                'message' => 'Failed to terminate account: ' . $e->getMessage()
            ];
        }
    }

    // Change Package
    public function changePackage($username, $newPackage)
    {
        try {
            $whmUsername = config('cpanel.username');
            $whmToken = config('cpanel.token');
            $whmHost = config('cpanel.hostname');

            Log::info('Changing package in WHM', [
                'username' => $username,
                'new_package' => $newPackage
            ]);

            $response = Http::withHeaders([
                'Authorization' => 'WHM ' . $whmUsername . ':' . $whmToken
            ])
            ->withOptions([
                'verify' => false
            ])
            ->post($whmHost . '/json-api/changepackage', [
                'api.version' => 1,
                'user' => $username,
                'pkg' => $newPackage
            ]);

            if (!$response->successful()) {
                throw new \Exception('Failed to change package: ' . $response->body());
            }

            $data = $response->json();

            Log::info('WHM change package response:', [
                'response' => $data
            ]);

            if (isset($data['metadata']) && $data['metadata']['result'] == 0) {
                throw new \Exception($data['metadata']['reason'] ?? 'Unknown error occurred');
            }

            return [
                'success' => true,
                'message' => 'Package changed successfully',
                'data' => $data
            ];
        } catch (\Exception $e) {
            Log::error('Error changing package in WHM', [
                'error' => $e->getMessage(),
                'username' => $username,
                'new_package' => $newPackage,
                'trace' => $e->getTraceAsString()
            ]);

            return [
                    'success' => false,
                    'message' => 'Error changing package: ' . $e->getMessage()
                ];
        }
    }

    // Change Password
    public function changePassword($params)
    {
        try {
            // Validasi password
            if (empty($params['password'])) {
                return [
                    'success' => false,
                    'message' => 'Password baru tidak boleh kosong'
                ];
            }

            // Validasi minimal panjang password
            if (strlen($params['password']) < 8) {
                return [
                    'success' => false,
                    'message' => 'Password minimal 8 karakter'
                ];
            }

            // Validasi kompleksitas password
            if (!preg_match('/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/', $params['password'])) {
                return [
                    'success' => false,
                    'message' => 'Password harus mengandung huruf besar, huruf kecil, angka, dan karakter khusus'
                ];
            }

            $headers = [
                'Authorization' => $this->headers['Authorization']
            ];

            Log::info('Attempting to change password', [
                'username' => $params['username']
            ]);

            $response = Http::withHeaders($headers)
                ->withOptions([
                    'verify' => false
                ])
                ->asForm()
                ->post($this->baseUrl . 'passwd', [
                    'api.version' => 1,
                    'user' => $params['username'],
                    'password' => $params['password']
                ]);

            Log::info('cPanel Change Password Response', [
                'response' => $response->body()
            ]);

            return $this->handleResponse($response);
        } catch (\Exception $e) {
            Log::error('Error in changePassword', [
                'error' => $e->getMessage(),
                'username' => $params['username']
            ]);

            return [
                'success' => false,
                'message' => 'Failed to change password: ' . $e->getMessage()
            ];
        }
    }

    public function checkAccount($params)
    {
        try {
            $headers = [
                'Authorization' => $this->headers['Authorization']
            ];

            Log::info('Checking cPanel account', [
                'username' => $params['username']
            ]);

            $response = Http::withHeaders($headers)
                ->withOptions([
                    'verify' => false
                ])
                ->get($this->baseUrl . 'listaccts', [
                    'api.version' => 1,
                    'search' => $params['username'],
                    'searchtype' => 'user'
                ]);

            $data = json_decode($response->body(), true);

            Log::info('cPanel Check Account Response', [
                'response' => $data
            ]);

            if (isset($data['data']['acct']) && count($data['data']['acct']) > 0) {
                return [
                    'success' => true,
                    'exists' => true,
                    'data' => $data['data']['acct'][0]
                ];
            }

            return [
                'success' => true,
                'exists' => false
            ];
        } catch (\Exception $e) {
            Log::error('cPanel Check Account Error', [
                'error' => $e->getMessage(),
                'username' => $params['username']
            ]);
            return [
                'success' => false,
                'exists' => false,
                'message' => $e->getMessage()
            ];
        }
    }

    protected function handleResponse($response)
    {
        try {
            $data = $response->json();

            // Log response untuk debugging
            Log::info('Handling cPanel Response', [
                'data' => $data
            ]);

            // Cek status response
            if ($response->successful()) {
                return [
                    'success' => true,
                    'data' => $data['data'] ?? $data,
                    'message' => $data['message'] ?? 'Success'
                ];
            }

            return [
                'success' => false,
                'message' => $data['errors'][0] ?? $data['message'] ?? 'Unknown error occurred'
            ];
        } catch (\Exception $e) {
            Log::error('Error handling response', [
                'error' => $e->getMessage(),
                'response' => $response->body()
            ]);

            return [
                'success' => false,
                'message' => 'Error processing response: ' . $e->getMessage()
            ];
        }
    }

    protected function validatePackageName($packageName)
    {
        try {
            Log::info('Memvalidasi nama paket', ['package' => $packageName]);

            // Validasi format nama paket
            if (!preg_match('/^[a-zA-Z0-9_]+$/', $packageName)) {
                Log::warning('Format nama paket tidak valid', ['package' => $packageName]);
                return false;
            }

            // Cek keberadaan paket di cPanel
            $response = Http::withHeaders($this->headers)
                ->withOptions(['verify' => false])
                ->get($this->baseUrl . 'listpkgs');

            $data = $response->json();

            if (isset($data['pkg'])) {
                $availablePackages = array_map(function ($pkg) {
                    return $pkg['name'];
                }, $data['pkg']);

                $exists = in_array($packageName, $availablePackages);

                Log::info('Hasil validasi paket', [
                    'package' => $packageName,
                    'exists' => $exists,
                    'available_packages' => $availablePackages
                ]);

                return $exists;
            }

            return false;
        } catch (\Exception $e) {
            Log::error('Error validasi nama paket', [
                'error' => $e->getMessage(),
                'package' => $packageName
            ]);
            return false;
        }
    }

    public function getPackages()
    {
        try {
            $whmUsername = config('cpanel.username');
            $whmToken = config('cpanel.token');
            $whmHost = config('cpanel.hostname');

            Log::info('Fetching packages from WHM', [
                'host' => $whmHost,
                'username' => $whmUsername
            ]);

            // Gunakan endpoint yang benar untuk WHM API v1
            $response = Http::withHeaders([
                'Authorization' => 'WHM ' . $whmUsername . ':' . $whmToken
            ])
            ->withOptions([
                'verify' => false
            ])
            ->get($whmHost . '/json-api/listpkgs', [
                'api.version' => 1
            ]);

            if (!$response->successful()) {
                throw new \Exception('Failed to fetch packages: ' . $response->body());
            }

            $data = $response->json();
            
            // Debug response
            Log::debug('WHM API Response:', [
                'response' => $data
            ]);

            // Periksa struktur data yang benar dari WHM API
            if (!isset($data['data']) || !isset($data['data']['pkg'])) {
                throw new \Exception('Invalid package data format from WHM');
            }

            // Extract package names dari struktur yang benar
            $packages = array_map(function($pkg) {
                return $pkg['name'];
            }, $data['data']['pkg']);

            Log::info('Successfully fetched packages from WHM', [
                'packages' => $packages
            ]);

            return [
                'success' => true,
                'data' => $packages
            ];

        } catch (\Exception $e) {
            Log::error('Error getting packages from WHM', [
                'error' => $e->getMessage(),
                'trace' => $e->getTraceAsString()
            ]);

            return [
                'success' => false,
                'message' => 'Error getting packages: ' . $e->getMessage()
            ];
        }
    }
}