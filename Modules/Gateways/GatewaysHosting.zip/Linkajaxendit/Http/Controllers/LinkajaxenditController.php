<?php

namespace Modules\Gateways\Linkajaxendit\Http\Controllers;

use Illuminate\Contracts\Support\Renderable;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use Auth;

class LinkajaxenditController extends Controller
{
    function MetaData()
    {
        return array(
            'DisplayName' => 'LinkAja Xendit',
            'APIVersion' => '1.1', // Use API Version 1.1
            'DisableLocalCreditCardInput' => true,
            'TokenisedStorage' => false,
        );
    }

    function config()
    {
        return [
            'FriendlyName' => array(
                'Type' => 'System',
                'Value' => 'LinkAja Xendit',
            ),
            "UsageNotes" => array(
                "Type" => "System",
                "Value" => "Lihat dan kelola secret keys Anda di <a href=\"https://dashboard.xendit.co/settings/developers#api-keys\">Dasboard Xendit</a>",
            ),
            'secretKeyTest' => array(
                'FriendlyName' => 'Secret Key Test',
                'Type' => 'password',
                'Size' => '25',
                'Default' => '',
                'Description' => 'Enter secret key here',
            ),
            'secretKeyLive' => array(
                'FriendlyName' => 'Secret Key Live',
                'Type' => 'password',
                'Size' => '25',
                'Default' => '',
                'Description' => 'Enter secret key here',
            ),
            'tokenCallbackTest' => array(
                'FriendlyName' => 'Token verifikasi callback test',
                'Type' => 'text',
                'Size' => '25',
                'Default' => '',
                'Description' => 'Enter your token here',
            ),
            'tokenCallbackLive' => array(
                'FriendlyName' => 'Token verifikasi callback live',
                'Type' => 'text',
                'Size' => '25',
                'Default' => '',
                'Description' => 'Enter your token here',
            ),
            'clientId' => array(
                'FriendlyName' => 'Client id notification',
                'Type' => 'text',
                'Size' => '25',
                'Default' => '',
                'Description' => 'Client id for recieve email notification',
            ),
            'testMode' => array(
                'FriendlyName' => 'Test Mode',
                'Type' => 'yesno',
                'Description' => 'Tick to enable test mode',
            ),
            'instructions' => array(
                'FriendlyName' => 'Payment instructions',
                'Type' => 'textarea',
                'Rows' => '5',
                'Description' => 'The instructions you want displaying to customers who choose this payment method',
                'Default' => $this->getDefaultInstructions(),
            ),
            'emailTemplate' => array(
                'FriendlyName' => 'Email template',
                'Type' => 'dropdown',
                'Options' => $this->getEmailTemplates(),
                'Description' => 'Choose one',
            ),
        ];
    }

    public function link($params = [])
    {
        $invoiceid = $params['invoiceid'];

        return view('linkajaxendit::index', [
            'url' => url("linkajaxendit/payNow"),
            'invoiceid' => $invoiceid,
            'langpaynow' => $params["langpaynow"],
        ]);
    }

    private function call($method = 'post', $url = '', $token = '', array $postfield = [])
    {
        $postfield = json_encode($postfield);

        $curl = curl_init();
        curl_setopt_array($curl, array(
            CURLOPT_URL => $url,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => '',
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 0,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => strtoupper($method),
            CURLOPT_POSTFIELDS => $postfield,
            CURLOPT_HTTPHEADER => array(
                'Content-Type: application/json',
                'Authorization: Basic '.base64_encode("$token:"),
            ),
        ));

        $response = curl_exec($curl);

        curl_close($curl);
        return json_decode($response);
    }

    public function payNow(Request $request)
    {
        $invoiceid = $request->input('invoiceid');

        try {
            $invoice = new \App\Helpers\InvoiceClass($invoiceid);
            $params = $invoice->getGatewayInvoiceParams();

            $testMode = $params["testMode"];
            $secretKey = $testMode ? $params["secretKeyTest"] : $params["secretKeyLive"];
            $tokenModule = $testMode ? $params["tokenCallbackTest"] : $params["tokenCallbackLive"];
            $clientdetails = $params['clientdetails'];
            $userid = $clientdetails['userid'];
            $name = trim($clientdetails['firstname'].' '.$clientdetails['lastname']);
            $url = "https://api.xendit.co/ewallets/charges";
            $query = [
                "invoiceid" => $invoiceid,
            ];
            $return_url = url("linkajaxendit/process_payment");
            $return_url .= "?".http_build_query($query);

            $items = [];
            foreach ($invoice->getLineItems(true) as $key => $invoiceitem) {
                $items[] = [
                    'reference_id' => (string) $invoiceitem['relid'],
                    'name' => $invoiceitem['description'],
                    'category' => !empty($invoiceitem['type']) ? $invoiceitem['type'] : 'Custom',
                    'currency' => 'IDR',
                    'price' => ceil($invoiceitem['rawamount']),
                    'quantity' => 1,
                    'type' => 'PRODUCT',
                    'metadata' => [
                        'id' => $invoiceitem['id'],
                        'taxed' => $invoiceitem['taxed'],
                        'currency' => $invoiceitem['amount']->getCurrency(),
                    ],
                ];
            }

            $ewalletChargeParams = [
                'reference_id' => $invoiceid.'-'.time(),
                'currency' => 'IDR',
                'amount' => ceil($params['amount']),
                'checkout_method' => 'ONE_TIME_PAYMENT',
                'channel_code' => 'ID_LINKAJA',
                'channel_properties' => [
                    'success_redirect_url' => $return_url,
                ],
                'basket' => $items,
                'metadata' => [
                    'invoiceid' => $invoiceid,
                    'userid' => $userid,
                    'gateway' => 'linkajaxendit',
                    'customsubject' => "Ada Pembayaran Masuk ke LinkAja Xendit Relabs",
                ],
            ];
            $response = $this->call("post", $url, $secretKey, $ewalletChargeParams);
            \Log::debug("=== paynow link aja");
            \Log::debug(json_decode(json_encode($response), true));
            if (isset($response->error_code)) {
                throw new \Exception($response->message);
            }

            return response()->json([
                'result' => 'success',
                'message' => 'ok',
                'redirect_url' => $response->actions->desktop_web_checkout_url,
            ], 200);
        } catch (\Exception $e) {
            return response()->json([
                'result' => 'error',
                'message' => $e->getMessage(),
            ], 200);
        }
    }

    public function process_payment(Request $request)
    {
        $auth = Auth::guard('web')->user();
        $userid = $auth ? $auth->id : 0;
        $invoiceid = $request->input('invoiceid');

        try {
            $invoice = new \App\Helpers\InvoiceClass($invoiceid);
            $params = $invoice->getGatewayInvoiceParams();

            // check kepemilikan invoice
            if ($params["clientdetails"]["userid"] != $userid) {
                return abort(403);
            }

            // check status
            if ($invoice->getData("status") == "Paid") {
                return redirect($params['returnurl']);
            }

            return view("linkajaxendit::process_payment", [
                "returnurl" => $params['returnurl'],
            ]);
        } catch (\Exception $e) {
            return view("linkajaxendit::error_process_payment", [
                "message" => $e->getMessage(),
            ]);
        }
    }

    private function getDefaultInstructions()
    {
        return '
        under construction
        '; 
    }

    private function getEmailTemplates()
    {
        $data = [];
        $data[""] = "-- None --";
        $emailTemplates = \Illuminate\Support\Facades\DB::table("tblemailtemplates")->where(["type" => "invoice", "custom" => "1"])->get();
        foreach ($emailTemplates as $emailTemplate) {
            $data[$emailTemplate->name] = $emailTemplate->name;
        }

        return $data;
    }
}
