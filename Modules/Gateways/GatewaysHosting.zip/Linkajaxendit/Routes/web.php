<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::prefix('linkajaxendit')->group(function() {
    Route::post('/payNow', 'LinkajaxenditController@payNow');
    Route::get('/process_payment', 'LinkajaxenditController@process_payment');
});
