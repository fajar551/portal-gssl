
<a href="{{$url}}" class="btn btn-primary">{{$langpaynow}}</a>
<div class="text-center">
    <div class="my-4 font-weight-bold text-white">Or scan with QR</div>
    <div class="my-4">
    {!! QrCode::size(200)->generate($qrCode); !!}
    </div>
</div>
