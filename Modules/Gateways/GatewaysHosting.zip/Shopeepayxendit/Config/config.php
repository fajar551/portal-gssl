<?php

return [
    'name' => 'Shopeepayxendit'
];
