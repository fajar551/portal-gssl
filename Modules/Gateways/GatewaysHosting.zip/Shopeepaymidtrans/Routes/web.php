<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::prefix('shopeepaymidtrans')->group(function() {
    Route::get('/', 'ShopeepaymidtransController@index');
    Route::post('/payNow', 'ShopeepaymidtransController@payNow');
    Route::match(['get', 'post'], '/callback', 'ShopeepaymidtransController@callback');
    Route::get('/process_payment', 'ShopeepaymidtransController@process_payment');
});
