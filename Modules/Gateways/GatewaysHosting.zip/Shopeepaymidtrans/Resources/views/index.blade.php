<button onclick="payNow()" class="btn btn-primary">{{$langpaynow}}</button>

<script>
    $(document).ready(function() {
        setInterval(update, 5000);
    });
    function update() {
        $.ajax({
            type : 'GET',
            url : "{{$url_update}}",
            data: {id: "{{$invoiceid}}", _token: "{{csrf_token()}}"},
            success : function(data){
                if(data.status){
                    location.reload();
                }	
            },
        });
    };
    function payNow() {
        $.ajax({
            url: "{{$url}}",
            type: "post",
            data: {
                _token: "{{csrf_token()}}",
                invoiceid: "{{$invoiceid}}",
            },
            success: function(res) {
                console.log(res);
                if (res.result == 'error') {
                    alert(res.message);
                } else {
                    location.href = res.redirect_url;
                }
            },
            error: function() {
                console.log('error');
            },
        });
    }
</script>
