<?php

return [
    'name' => 'Shopeepaymidtrans'
];
