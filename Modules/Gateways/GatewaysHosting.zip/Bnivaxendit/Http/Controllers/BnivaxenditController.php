<?php

namespace Modules\Gateways\Bnivaxendit\Http\Controllers;

use Illuminate\Contracts\Support\Renderable;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use DB;

class BnivaxenditController extends Controller
{
    function MetaData()
    {
        return array(
            'DisplayName' => 'BNI VA Xendit',
            'APIVersion' => '1.1', // Use API Version 1.1
            'DisableLocalCreditCardInput' => true,
            'TokenisedStorage' => false,
        );
    }

    function config()
    {
        return [
            'FriendlyName' => array(
                'Type' => 'System',
                'Value' => 'BNI VA Xendit',
            ),
            "UsageNotes" => array(
                "Type" => "System",
                "Value" => "Lihat dan kelola secret keys Anda di <a href=\"https://dashboard.xendit.co/settings/developers#api-keys\">Dasboard Xendit</a>",
            ),
            'secretKeyTest' => array(
                'FriendlyName' => 'Secret Key Test',
                'Type' => 'password',
                'Size' => '25',
                'Default' => '',
                'Description' => 'Enter secret key here',
            ),
            'secretKeyLive' => array(
                'FriendlyName' => 'Secret Key Live',
                'Type' => 'password',
                'Size' => '25',
                'Default' => '',
                'Description' => 'Enter secret key here',
            ),
            'tokenCallbackTest' => array(
                'FriendlyName' => 'Token verifikasi callback test',
                'Type' => 'text',
                'Size' => '25',
                'Default' => '',
                'Description' => 'Enter your token here',
            ),
            'tokenCallbackLive' => array(
                'FriendlyName' => 'Token verifikasi callback live',
                'Type' => 'text',
                'Size' => '25',
                'Default' => '',
                'Description' => 'Enter your token here',
            ),
            'merchantCode' => array(
                'FriendlyName' => 'Merchant Code',
                'Type' => 'text',
                'Size' => '25',
                'Default' => '',
                'Description' => '<i>Note: merchant number</i>',
            ),
            'vaPrefix' => array(
                'FriendlyName' => 'VA Prefix',
                'Type' => 'text',
                'Size' => '25',
                'Default' => '9999',
                'Description' => '<i>Note: Not a merchant number</i>. Example: 1234',
            ),
            'vaDigits' => array(
                'FriendlyName' => 'VA number digit length',
                'Type' => 'text',
                'Size' => '25',
                'Default' => '6',
                'Description' => 'Digit length after prefix.',
            ),
            'clientId' => array(
                'FriendlyName' => 'Client id notification',
                'Type' => 'text',
                'Size' => '25',
                'Default' => '',
                'Description' => 'Client id for recieve email notification',
            ),
            'isFixed' => array(
                'FriendlyName' => 'Fixed Va',
                'Type' => 'yesno',
                'Description' => 'Tick to enable fixed virtual account',
            ),
            'testMode' => array(
                'FriendlyName' => 'Test Mode',
                'Type' => 'yesno',
                'Description' => 'Tick to enable test mode',
            ),
            'instructions' => array(
                'FriendlyName' => 'Payment instructions',
                'Type' => 'textarea',
                'Rows' => '5',
                'Description' => 'The instructions you want displaying to customers who choose this payment method',
                'Default' => $this->getDefaultInstructions(),
            ),
            'emailTemplate' => array(
                'FriendlyName' => 'Email template',
                'Type' => 'dropdown',
                'Options' => $this->getEmailTemplates(),
                'Description' => 'Choose one',
            ),
        ];
    }

    public function link($params = [])
    {
        $isFixed = $params["isFixed"];
        $testMode = $params["testMode"];
        $secretKey = $testMode ? $params["secretKeyTest"] : $params["secretKeyLive"];
        $clientdetails = $params['clientdetails'];
        $userid = $clientdetails['userid'];
        $invoiceid = $params['invoiceid'];
        $name = trim($clientdetails['firstname'].' '.$clientdetails['lastname']);
        $url = "https://api.xendit.co/callback_virtual_accounts";
        
        /**
         * Note: Change this
         */
        $bank_code = "BNI";
        $view = "bnivaxendit::index";
        $url_update = url('bnivaxendit');
        $message_link = "Silahkan melakukan pembayaran ke nomor BNI Virtual Account Anda berikut: <strong>%s</strong>";
        $customfield_name = "Fixed VA $bank_code";

        try {
            if ($isFixed) {
                $customfield_id = $this->loadCustomfield($customfield_name);
    
                // get customfield value
                $condition = array("fieldid" => $customfield_id, "relid" => $userid);
                $customfieldvalue = DB::table("tblcustomfieldsvalues")->where($condition)->first();
                $value = $customfieldvalue ? $customfieldvalue->value : 0;
    
                // check exists
                if ($value) {
                    $virtualaccountnumber = $customfieldvalue->value;
                } else {
                    $number = str_pad($userid,$params['vaDigits'],"0",STR_PAD_LEFT); 
                    $virtual_account_number = $params['vaPrefix'].$number;
                    $external_id = $bank_code."-".$number;
                    $postfields = [
                        "external_id" => $external_id,
                        "bank_code" => $bank_code,
                        "name" => $name,
                        "virtual_account_number" => $virtual_account_number,
                    ];
                    $response = $this->call($url, $secretKey, $postfields);
                    // \Log::debug(json_decode(json_encode($response), true));
                    if (isset($response->error_code)) {
                        if ($response->error_code == 'DUPLICATE_CALLBACK_VIRTUAL_ACCOUNT_ERROR') {
                            $virtualaccountnumber = $params['merchantCode'].$virtual_account_number;

                            DB::table("tblcustomfieldsvalues")->updateOrInsert(
                                $condition,
                                ['value' => $virtualaccountnumber]
                            );
                        } else {
                            throw new \Exception($response->message);
                        }
                    } else {
                        $virtualaccountnumber = $response->account_number;
                        
                        // save customfield value
                        $condition["value"] = $virtualaccountnumber;
                        DB::table("tblcustomfieldsvalues")->insert($condition);
                    }
                }
    
                return view($view, [
                    "message" => sprintf($message_link, $virtualaccountnumber),
                    "invoiceid" => $invoiceid,
                    "url_update" => $url_update,
                    "instructions" => $params['instructions'],
                ]);
            } else {
                $external_id = $invoiceid."-".$userid;
                $postfields = [
                    "external_id" => $external_id,
                    "bank_code" => $bank_code,
                    "name" => $name,
                ];
                $response = $this->call($url, $secretKey, $postfields);
                if (isset($response->error_code)) {
                    throw new \Exception($response->message);
                }
                
                $virtualaccountnumber = $response->account_number;
                
                return view($view, [
                    "message" => sprintf($message_link, $virtualaccountnumber),
                    "invoiceid" => $invoiceid,
                    "url_update" => $url_update,
                    "instructions" => $params['instructions'],
                ]);
            }
        } catch (\Exception $e) {
            return $e->getMessage();
        }
    }

    private function call($url = '', $token = '', array $postfield = [])
    {
        $postfield = json_encode($postfield);

        $curl = curl_init();
        curl_setopt_array($curl, array(
            CURLOPT_URL => $url,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => '',
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 0,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => 'POST',
            CURLOPT_POSTFIELDS => $postfield,
            CURLOPT_HTTPHEADER => array(
                'Content-Type: application/json',
                'Authorization: Basic '.base64_encode("$token:"),
            ),
        ));

        $response = curl_exec($curl);

        curl_close($curl);
        return json_decode($response);
    }

    private function loadCustomfield($fieldname)
    {
        DB::beginTransaction();
        try {
            $table = "tblcustomfields";
            $condition = array("type" => "client", "fieldname" => $fieldname, "relid" => 0);

            $customfield = DB::table($table)->where($condition)->first();
            if (!$customfield) {
                $condition["fieldtype"] = "text";
                $condition["adminonly"] = "on";
                $condition["required"] = "";
                $condition["showorder"] = "";
                $condition["showinvoice"] = "";
                $condition["sortorder"] = "";
                $id = DB::table($table)->insertGetId($condition);
            } else {
                $id = $customfield->id;
            }

            DB::commit();
            return $id;
        } catch (\Exception $e) {
            DB::rollback();
            return 0;
        }
    }

    public function index(Request $request)
    {
        $postData = array(
            'invoiceid' => $request->input('id'),
        );
        $response = (new \App\Helpers\HelperApi)->localAPI('GetInvoice', $postData);
        if ($response['result'] == 'success') {
            if($response['status'] == 'Paid'){
                return response()->json(['status' => true], 200);
            }else{
                return response()->json(['status' => false], 200);
            }
        } else {
            return response()->json(['status' => false], 200);
        }
    }

    private function getDefaultInstructions()
    {
        return '
        <div class="bg_light" style="box-sizing: border-box; -ms-text-size-adjust: 100%; -webkit-text-size-adjust: 100%; text-align: center; background-color: #fafafa; background-image: none; background-repeat: repeat; background-position: top left; background-attachment: scroll;">
        <div class="container" style="box-sizing: border-box; -ms-text-size-adjust: 100%; -webkit-text-size-adjust: 100%; width: 100%; padding-right: 15px; padding-left: 15px; margin-right: auto; margin-left: auto;">
        <div class="row" style="box-sizing: border-box; -ms-text-size-adjust: 100%; -webkit-text-size-adjust: 100%; display: flex; -ms-flex-wrap: wrap; flex-wrap: wrap; margin-right: -15px; margin-left: -15px;">
        <div class="col-md-12" style="box-sizing: border-box; -ms-text-size-adjust: 100%; -webkit-text-size-adjust: 100%; position: relative; width: 100%; padding-right: 15px; padding-left: 15px;">
        <div class="bank-payment" style="box-sizing: border-box; font-weight: bold; font-size: 14px; font-family: \'montserrat\', sans-serif; color: #555; padding: 2.5em;"><img style="box-sizing: border-box; -ms-text-size-adjust: 100%; -webkit-text-size-adjust: 100%; width: 130px; vertical-align: middle; border-style: none; -ms-interpolation-mode: bicubic;" src="https://qwords.com/logo-email-template/bni.png"><br style="box-sizing: border-box; -ms-text-size-adjust: 100%; -webkit-text-size-adjust: 100%;">BNI Virtual Account: {$nova}</div>
        </div>
        </div>
        </div>
        </div>
        <div class="bg_white" style="box-sizing: border-box; -ms-text-size-adjust: 100%; -webkit-text-size-adjust: 100%; background-color: #ffffff; background-image: none; background-repeat: repeat; background-position: top left; background-attachment: scroll;">
        <div class="container" style="box-sizing: border-box; -ms-text-size-adjust: 100%; -webkit-text-size-adjust: 100%; width: 100%; padding-right: 15px; padding-left: 15px; margin-right: auto; margin-left: auto;">
        <div class="row" style="box-sizing: border-box; -ms-text-size-adjust: 100%; -webkit-text-size-adjust: 100%; display: flex; -ms-flex-wrap: wrap; flex-wrap: wrap; margin-right: -15px; margin-left: -15px;">
        <div class="col-md-12" style="box-sizing: border-box; -ms-text-size-adjust: 100%; -webkit-text-size-adjust: 100%; position: relative; width: 100%; padding-right: 15px; padding-left: 15px;">
        <div class="payment-atm" style="box-sizing: border-box; -ms-text-size-adjust: 100%; -webkit-text-size-adjust: 100%; margin-top: 30px; border: 1px solid #f7863b;">
        <div class="table-responsive" style="box-sizing: border-box; -ms-text-size-adjust: 100%; -webkit-text-size-adjust: 100%; display: block; width: 100%; overflow-x: auto; -webkit-overflow-scrolling: touch;">
        <table class="table" style="box-sizing: border-box; -ms-text-size-adjust: 100%; -webkit-text-size-adjust: 100%; border-collapse: collapse; mso-table-lspace: 0pt !important; mso-table-rspace: 0pt !important; width: 100%; margin-bottom: 1rem; color: #212529;">
        <thead style="box-sizing: border-box; -ms-text-size-adjust: 100%; -webkit-text-size-adjust: 100%; background-color: #f7863b; background-image: none; background-repeat: repeat; background-position: top left; background-attachment: scroll; color: white;">
        <tr style="box-sizing: border-box; -ms-text-size-adjust: 100%; -webkit-text-size-adjust: 100%;">
        <th style="box-sizing: border-box; border-bottom: 2px none #dee2e6; text-align: inherit; border-top: 1px solid #dee2e6; vertical-align: bottom; font-family:\ montserrat\, sans-serif; padding: 0.75rem; height: 41px;">ATM BNI</th>
        </tr>
        </thead>
        </table>
        </div>
        <div class="primary-list mt-25" style="box-sizing: border-box; -ms-text-size-adjust: 100%; -webkit-text-size-adjust: 100%;">
        <ol style="box-sizing: border-box; margin-top: 0; margin-bottom: 1rem; font-family: \'montserrat\', sans-serif; font-size: 14px; line-height: 1.5; color: #555;">
        <li style="box-sizing: border-box; -ms-text-size-adjust: 100%; -webkit-text-size-adjust: 100%;">Pilih Menu Lain</li>
        <li style="box-sizing: border-box; -ms-text-size-adjust: 100%; -webkit-text-size-adjust: 100%;">Pilih Menu Transfer</li>
        <li style="box-sizing: border-box; -ms-text-size-adjust: 100%; -webkit-text-size-adjust: 100%;">Pilih Ke Rekening BNI</li>
        <li style="box-sizing: border-box; -ms-text-size-adjust: 100%; -webkit-text-size-adjust: 100%;">Masukkan Nominal. misal, 10000</li>
        <li style="box-sizing: border-box; -ms-text-size-adjust: 100%; -webkit-text-size-adjust: 100%;">Masukkan Nomor Virtual Account. {$nova}</li>
        <li style="box-sizing: border-box; -ms-text-size-adjust: 100%; -webkit-text-size-adjust: 100%;">Pilih Ya</li>
        <li style="box-sizing: border-box; -ms-text-size-adjust: 100%; -webkit-text-size-adjust: 100%;">Ambil Bukti Pembayaran Anda.</li>
        <li style="box-sizing: border-box; -ms-text-size-adjust: 100%; -webkit-text-size-adjust: 100%;">Selesai</li>
        </ol>
        </div>
        </div>
        <div class="payment-atm" style="box-sizing: border-box; -ms-text-size-adjust: 100%; -webkit-text-size-adjust: 100%; margin-top: 30px; border: 1px solid #f7863b;">
        <div class="table-responsive" style="box-sizing: border-box; -ms-text-size-adjust: 100%; -webkit-text-size-adjust: 100%; display: block; width: 100%; overflow-x: auto; -webkit-overflow-scrolling: touch;">
        <table class="table" style="box-sizing: border-box; -ms-text-size-adjust: 100%; -webkit-text-size-adjust: 100%; border-collapse: collapse; mso-table-lspace: 0pt !important; mso-table-rspace: 0pt !important; width: 100%; margin-bottom: 1rem; color: #212529;">
        <thead style="box-sizing: border-box; -ms-text-size-adjust: 100%; -webkit-text-size-adjust: 100%; background-color: #f7863b; background-image: none; background-repeat: repeat; background-position: top left; background-attachment: scroll; color: white;">
        <tr style="box-sizing: border-box; -ms-text-size-adjust: 100%; -webkit-text-size-adjust: 100%;">
        <th style="box-sizing: border-box; border-bottom-style: none; text-align: inherit; border-top-width: 1px; border-top-style: solid; border-top-color: #dee2e6; vertical-align: bottom; border-bottom-width: 2px; border-bottom-color: #dee2e6; font-family: \'montserrat\', sans-serif; padding: .75rem;">SMS Banking BNI</th>
        </tr>
        </thead>
        </table>
        </div>
        <div class="primary-list mt-25" style="box-sizing: border-box; -ms-text-size-adjust: 100%; -webkit-text-size-adjust: 100%;">
        <ol style="box-sizing: border-box; margin-top: 0; margin-bottom: 1rem; font-family: \'montserrat\', sans-serif; font-size: 14px; line-height: 1.5; color: #555;">
        <li style="box-sizing: border-box; -ms-text-size-adjust: 100%; -webkit-text-size-adjust: 100%;">Masuk Aplikasi SMS Banking BNI.</li>
        <li style="box-sizing: border-box; -ms-text-size-adjust: 100%; -webkit-text-size-adjust: 100%;">Pilih Menu Transfer</li>
        <li style="box-sizing: border-box; -ms-text-size-adjust: 100%; -webkit-text-size-adjust: 100%;">Pilih Trf Rekening BNI</li>
        <li style="box-sizing: border-box; -ms-text-size-adjust: 100%; -webkit-text-size-adjust: 100%;">Masukkan Nomor Virtual Account {$nova}</li>
        <li style="box-sizing: border-box; -ms-text-size-adjust: 100%; -webkit-text-size-adjust: 100%;">Masukkan Jumlah Tagihan. misal, 10000</li>
        <li style="box-sizing: border-box; -ms-text-size-adjust: 100%; -webkit-text-size-adjust: 100%;">Pilih Proses</li>
        <li style="box-sizing: border-box; -ms-text-size-adjust: 100%; -webkit-text-size-adjust: 100%;">Pada Pop Up Message, Pilih Setuju</li>
        <li style="box-sizing: border-box; -ms-text-size-adjust: 100%; -webkit-text-size-adjust: 100%;">Anda Akan Mendapatkan Pesan Konfirmasi.</li>
        <li style="box-sizing: border-box; -ms-text-size-adjust: 100%; -webkit-text-size-adjust: 100%;">Masukkan 2 Angka Dari PIN Anda Dengan Mengikuti Petunjuk Yang Tertera Pada Pesan.</li>
        <li style="box-sizing: border-box; -ms-text-size-adjust: 100%; -webkit-text-size-adjust: 100%;">Bukti bayar ditampilkan.</li>
        <li style="box-sizing: border-box; -ms-text-size-adjust: 100%; -webkit-text-size-adjust: 100%;">Selesai.</li>
        </ol>
        </div>
        </div>
        <div class="payment-atm" style="box-sizing: border-box; -ms-text-size-adjust: 100%; -webkit-text-size-adjust: 100%; margin-top: 30px; border: 1px solid #f7863b;">
        <div class="table-responsive" style="box-sizing: border-box; -ms-text-size-adjust: 100%; -webkit-text-size-adjust: 100%; display: block; width: 100%; overflow-x: auto; -webkit-overflow-scrolling: touch;">
        <table class="table" style="box-sizing: border-box; -ms-text-size-adjust: 100%; -webkit-text-size-adjust: 100%; border-collapse: collapse; mso-table-lspace: 0pt !important; mso-table-rspace: 0pt !important; width: 100%; margin-bottom: 1rem; color: #212529;">
        <thead style="box-sizing: border-box; -ms-text-size-adjust: 100%; -webkit-text-size-adjust: 100%; background-color: #f7863b; background-image: none; background-repeat: repeat; background-position: top left; background-attachment: scroll; color: white;">
        <tr style="box-sizing: border-box; -ms-text-size-adjust: 100%; -webkit-text-size-adjust: 100%;">
        <th style="box-sizing: border-box; border-bottom-style: none; text-align: inherit; border-top-width: 1px; border-top-style: solid; border-top-color: #dee2e6; vertical-align: bottom; border-bottom-width: 2px; border-bottom-color: #dee2e6; font-family: \'montserrat\', sans-serif; padding: .75rem;">Mobile Banking BNI</th>
        </tr>
        </thead>
        </table>
        </div>
        <div class="primary-list mt-25" style="box-sizing: border-box; -ms-text-size-adjust: 100%; -webkit-text-size-adjust: 100%;">
        <ol style="box-sizing: border-box; margin-top: 0; margin-bottom: 1rem; font-family: \'montserrat\', sans-serif; font-size: 14px; line-height: 1.5; color: #555;">
        <li style="box-sizing: border-box; -ms-text-size-adjust: 100%; -webkit-text-size-adjust: 100%;">Pilih Transfer</li>
        <li style="box-sizing: border-box; -ms-text-size-adjust: 100%; -webkit-text-size-adjust: 100%;">Pilih Antar Rekening BNI</li>
        <li style="box-sizing: border-box; -ms-text-size-adjust: 100%; -webkit-text-size-adjust: 100%;">Pilih Rekening Tujuan</li>
        <li style="box-sizing: border-box; -ms-text-size-adjust: 100%; -webkit-text-size-adjust: 100%;">Pilih Input Rekening Baru</li>
        <li style="box-sizing: border-box; -ms-text-size-adjust: 100%; -webkit-text-size-adjust: 100%;">Masukkan Nomor Virtual Account sebagai Nomor Rekening {$nova}</li>
        <li style="box-sizing: border-box; -ms-text-size-adjust: 100%; -webkit-text-size-adjust: 100%;">Klik Lanjut</li>
        <li style="box-sizing: border-box; -ms-text-size-adjust: 100%; -webkit-text-size-adjust: 100%;">Klik Lanjut Kembali.</li>
        <li style="box-sizing: border-box; -ms-text-size-adjust: 100%; -webkit-text-size-adjust: 100%;">Masukkan Nominal Tagihan. misal, 10000</li>
        <li style="box-sizing: border-box; -ms-text-size-adjust: 100%; -webkit-text-size-adjust: 100%;">Klik Lanjut</li>
        <li style="box-sizing: border-box; -ms-text-size-adjust: 100%; -webkit-text-size-adjust: 100%;">Periksa Detail Konfirmasi. Pastikan Data Sudah Benar.</li>
        <li style="box-sizing: border-box; -ms-text-size-adjust: 100%; -webkit-text-size-adjust: 100%;">Jika Sudah Benar, Masukkan Password Transaksi.</li>
        <li style="box-sizing: border-box; -ms-text-size-adjust: 100%; -webkit-text-size-adjust: 100%;">Klik Lanjut.</li>
        <li style="box-sizing: border-box; -ms-text-size-adjust: 100%; -webkit-text-size-adjust: 100%;">Bukti Pembayaran Ditampilkan.</li>
        <li style="box-sizing: border-box; -ms-text-size-adjust: 100%; -webkit-text-size-adjust: 100%;">Selesai.</li>
        </ol>
        </div>
        </div>
        <div class="payment-atm" style="box-sizing: border-box; -ms-text-size-adjust: 100%; -webkit-text-size-adjust: 100%; margin-top: 30px; border: 1px solid #f7863b;">
        <div class="table-responsive" style="box-sizing: border-box; -ms-text-size-adjust: 100%; -webkit-text-size-adjust: 100%; display: block; width: 100%; overflow-x: auto; -webkit-overflow-scrolling: touch;">
        <table class="table" style="box-sizing: border-box; -ms-text-size-adjust: 100%; -webkit-text-size-adjust: 100%; border-collapse: collapse; mso-table-lspace: 0pt !important; mso-table-rspace: 0pt !important; width: 100%; margin-bottom: 1rem; color: #212529;">
        <thead style="box-sizing: border-box; -ms-text-size-adjust: 100%; -webkit-text-size-adjust: 100%; background-color: #f7863b; background-image: none; background-repeat: repeat; background-position: top left; background-attachment: scroll; color: white;">
        <tr style="box-sizing: border-box; -ms-text-size-adjust: 100%; -webkit-text-size-adjust: 100%;">
        <th style="box-sizing: border-box; border-bottom-style: none; text-align: inherit; border-top-width: 1px; border-top-style: solid; border-top-color: #dee2e6; vertical-align: bottom; border-bottom-width: 2px; border-bottom-color: #dee2e6; font-family: \'montserrat\', sans-serif; padding: .75rem;">Internet Banking</th>
        </tr>
        </thead>
        </table>
        </div>
        <div class="primary-list mt-25" style="box-sizing: border-box; -ms-text-size-adjust: 100%; -webkit-text-size-adjust: 100%;">
        <ol style="box-sizing: border-box; margin-top: 0; margin-bottom: 1rem; font-family: \'montserrat\', sans-serif; font-size: 14px; line-height: 1.5; color: #555;">
        <li style="box-sizing: border-box; -ms-text-size-adjust: 100%; -webkit-text-size-adjust: 100%;">Masuk Internet Banking</li>
        <li style="box-sizing: border-box; -ms-text-size-adjust: 100%; -webkit-text-size-adjust: 100%;">Pilih Transaksi</li>
        <li style="box-sizing: border-box; -ms-text-size-adjust: 100%; -webkit-text-size-adjust: 100%;">Pilih Info dan Administrasi</li>
        <li style="box-sizing: border-box; -ms-text-size-adjust: 100%; -webkit-text-size-adjust: 100%;">Pilih Atur Rekening Tujuan</li>
        <li style="box-sizing: border-box; -ms-text-size-adjust: 100%; -webkit-text-size-adjust: 100%;">Pilih Tambah Rekening Tujuan</li>
        <li style="box-sizing: border-box; -ms-text-size-adjust: 100%; -webkit-text-size-adjust: 100%;">Klik Ok</li>
        <li style="box-sizing: border-box; -ms-text-size-adjust: 100%; -webkit-text-size-adjust: 100%;">Masukkan Nomor Order Sebagai Nama Singkat misal, Invoice-1234.</li>
        <li style="box-sizing: border-box; -ms-text-size-adjust: 100%; -webkit-text-size-adjust: 100%;">Masukkan Nomor Virtual Account Sebagai Nomor Rekening {$nova}</li>
        <li style="box-sizing: border-box; -ms-text-size-adjust: 100%; -webkit-text-size-adjust: 100%;">Lengkapi Semua Data Yang Diperlukan.</li>
        <li style="box-sizing: border-box; -ms-text-size-adjust: 100%; -webkit-text-size-adjust: 100%;">Klik Lanjutkan.</li>
        <li style="box-sizing: border-box; -ms-text-size-adjust: 100%; -webkit-text-size-adjust: 100%;">Masukkan Kode Otentikasi Token lalu, Proses.</li>
        <li style="box-sizing: border-box; -ms-text-size-adjust: 100%; -webkit-text-size-adjust: 100%;">Rekening Tujuan Berhasil Ditambahkan.</li>
        <li style="box-sizing: border-box; -ms-text-size-adjust: 100%; -webkit-text-size-adjust: 100%;">Pilih Menu Transfer</li>
        <li style="box-sizing: border-box; -ms-text-size-adjust: 100%; -webkit-text-size-adjust: 100%;">Pilih Transfer Antar Rek. BNI</li>
        <li style="box-sizing: border-box; -ms-text-size-adjust: 100%; -webkit-text-size-adjust: 100%;">Pilih Rekening Tujuan dengan Nama Singkat Yang Sudah Anda Tambahkan. misal, Invoice-1234</li>
        <li style="box-sizing: border-box; -ms-text-size-adjust: 100%; -webkit-text-size-adjust: 100%;">Masukkan Nominal. misal, 10000</li>
        <li style="box-sizing: border-box; -ms-text-size-adjust: 100%; -webkit-text-size-adjust: 100%;">Masukkan Kode Otentikasi Token</li>
        <li style="box-sizing: border-box; -ms-text-size-adjust: 100%; -webkit-text-size-adjust: 100%;">Bukti Pembayaran Ditampilkan.</li>
        <li style="box-sizing: border-box; -ms-text-size-adjust: 100%; -webkit-text-size-adjust: 100%;">Selesai.</li>
        </ol>
        </div>
        </div>
        </div>
        </div>
        </div>
        </div>
        <div style="margin-top: 30px; text-align: center; font-family:\ montserrat\,sans-serif; color: #555; line-height: 1.5;">
        <p>&nbsp;</p>
        <p><em><strong>BNI VA memerlukan waktu 10-15 menit untuk proses pengecekan transaksi dari sistem Bank BNI.</strong></em></p>
        </div>
        <div class="email-section bg_white" style="box-sizing: border-box; -ms-text-size-adjust: 100%; -webkit-text-size-adjust: 100%; background-color: #ffffff; background-image: none; background-repeat: repeat; background-position: top left; background-attachment: scroll; padding-top: 30px; padding-bottom: 30px;">
        <div class="container" style="box-sizing: border-box; -ms-text-size-adjust: 100%; -webkit-text-size-adjust: 100%; width: 100%; padding-right: 15px; padding-left: 15px; margin-right: auto; margin-left: auto;">
        <div class="row" style="box-sizing: border-box; -ms-text-size-adjust: 100%; -webkit-text-size-adjust: 100%; display: flex; -ms-flex-wrap: wrap; flex-wrap: wrap; margin-right: -15px; margin-left: -15px;">
        <div class="col-md-12" style="box-sizing: border-box; -ms-text-size-adjust: 100%; -webkit-text-size-adjust: 100%; position: relative; width: 100%; padding-right: 15px; padding-left: 15px;">
        <div class="description-email" style="box-sizing: border-box; -ms-text-size-adjust: 100%; -webkit-text-size-adjust: 100%;">
        <h6 style="box-sizing: border-box; -ms-text-size-adjust: 100%; -webkit-text-size-adjust: 100%; margin-bottom: .5rem; font-weight: 500; line-height: 1.2; font-size: 1rem; font-family: \'montserrat\', sans-serif; color: #000000; margin-top: 0;">Catatan</h6>
        <p style="box-sizing: border-box; margin-top: 0; margin-bottom: 1rem; font-size: 14px; font-family: \'montserrat\', sans-serif; line-height: 1.5; color: #555;">Metode Pembayaran Virtual Account tidak diperuntukan melalui Teller.</p>
        </div>
        </div>
        </div>
        </div>
        </div>
        '; 
    }

    private function getEmailTemplates()
    {
        $data = [];
        $data[""] = "-- None --";
        $emailTemplates = DB::table("tblemailtemplates")->where(["type" => "invoice", "custom" => "1"])->get();
        foreach ($emailTemplates as $emailTemplate) {
            $data[$emailTemplate->name] = $emailTemplate->name;
        }

        return $data;
    }
}
