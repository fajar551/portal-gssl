<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::prefix('akulakumidtrans')->group(function() {
    Route::get('/', 'AkulakumidtransController@index');
    Route::post('/payNow', 'AkulakumidtransController@payNow');
});
