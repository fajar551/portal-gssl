<?php

namespace Modules\Gateways\Akulakumidtrans\Http\Controllers;

use Illuminate\Contracts\Support\Renderable;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller;

class AkulakumidtransController extends Controller
{
    function MetaData()
    {
        return array(
            'DisplayName' => 'Akulaku Midtrans',
            'APIVersion' => '1.1', // Use API Version 1.1
            'DisableLocalCreditCardInput' => true,
            'TokenisedStorage' => false,
        );
    }

    function config()
    {
        return [
            'FriendlyName' => array(
                'Type' => 'System',
                'Value' => 'Akulaku Midtrans',
            ),
            "UsageNotes" => array(
                "Type" => "System",
                "Value" => "Lihat dan kelola server keys Anda di <a href=\"https://dashboard.sandbox.midtrans.com/settings/config_info\">Dasboard Midtrans</a>",
            ),
            'serverKeyTest' => array(
                'FriendlyName' => 'Server Key Test',
                'Type' => 'password',
                'Size' => '25',
                'Default' => '',
                'Description' => 'Enter Server key here',
            ),
            'serverKeyLive' => array(
                'FriendlyName' => 'Server Key Live',
                'Type' => 'password',
                'Size' => '25',
                'Default' => '',
                'Description' => 'Enter Server key here',
            ),
            'clientId' => array(
                'FriendlyName' => 'Client id notification',
                'Type' => 'text',
                'Size' => '25',
                'Default' => '',
                'Description' => 'Client id for recieve email notification',
            ),
            'testMode' => array(
                'FriendlyName' => 'Test Mode',
                'Type' => 'yesno',
                'Description' => 'Tick to enable test mode',
            ),
            'instructions' => array(
                'FriendlyName' => 'Payment instructions',
                'Type' => 'textarea',
                'Rows' => '5',
                'Description' => 'The instructions you want displaying to customers who choose this payment method',
                'Default' => $this->getDefaultInstructions(),
            ),
            'emailTemplate' => array(
                'FriendlyName' => 'Email template',
                'Type' => 'dropdown',
                'Options' => $this->getEmailTemplates(),
                'Description' => 'Choose one',
            ),
        ];
    }

    public function link($params)
    {
        $invoiceid = $params['invoiceid'];

        return view('akulakumidtrans::index', [
            'url' => url("akulakumidtrans/payNow"),
            "url_update" => url("akulakumidtrans"),
            'invoiceid' => $invoiceid,
            'langpaynow' => $params["langpaynow"],
        ]);
    }

    private function call($method = 'post', $url = '', $token = '', array $postfield = [])
    {
        $postfield = json_encode($postfield);

        $curl = curl_init();
        curl_setopt_array($curl, array(
            CURLOPT_URL => $url,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => '',
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 0,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => strtoupper($method),
            CURLOPT_POSTFIELDS => $postfield,
            CURLOPT_HTTPHEADER => array(
                'Content-Type: application/json',
                'Accept: application/json',
                'Authorization: Basic '.base64_encode("$token:"),
            ),
        ));

        $response = curl_exec($curl);

        curl_close($curl);
        return json_decode($response);
    }

    public function payNow(Request $request)
    {
        try {
            $invoiceid = $request->input('invoiceid');

            $invoice = new \App\Helpers\InvoiceClass($invoiceid);
            $params = $invoice->getGatewayInvoiceParams();

            $testMode = $params["testMode"];
            $serverKey = $testMode ? $params["serverKeyTest"] : $params["serverKeyLive"];
            $clientIdNotification = $params["clientId"];
            $clientdetails = $params['clientdetails'];
            $userid = $clientdetails['userid'];
            $name = trim($clientdetails['firstname'].' '.$clientdetails['lastname']);
            $baseurl = $testMode ? "https://api.sandbox.midtrans.com/v2/charge" : "https://api.midtrans.com/v2/charge";

            // items
            $items = [];
            foreach ($invoice->getLineItems(true) as $key => $invoiceitem) {
                $items[] = [
                    'id' => (string) $invoiceitem['relid'],
                    'price' => round($invoiceitem['rawamount']),
                    'quantity' => 1,
                    'name' => $invoiceitem['description'],
                    'category' => !empty($invoiceitem['type']) ? $invoiceitem['type'] : 'Custom',
                    'merchant_name' => $params["companyname"],
                ];
            }

            $charge = [
                "payment_type" => "akulaku",
                "transaction_details" => [
                    "order_id" => $invoiceid."-".time(),
                    "gross_amount" => round($params["amount"], 2),
                ],
                "item_details" => $items,
                "customer_details" => [
                    "email" => $clientdetails['email'],
                    "first_name" => $clientdetails['firstname'],
                    "last_name" => $clientdetails['lastname'],
                    "phone" => str_replace(".", "", $clientdetails['phonenumberformatted']),
                ],
            ];
            $response = $this->call("post", $baseurl, $serverKey, $charge);
            \Log::debug("== akulaku midtrans response");
            \Log::debug(json_decode(json_encode($response), true));
            if ($response->status_code != 201) {
                throw new \Exception($response->status_message);
            }

            return response()->json([
                'result' => 'success',
                'message' => 'ok',
                'redirect_url' => $response->redirect_url,
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'result' => 'error',
                'message' => $e->getMessage(),
            ]);
        }
    }

    public function index(Request $request)
    {
        $postData = array(
            'invoiceid' => $request->input('id'),
        );
        $response = (new \App\Helpers\HelperApi)->localAPI('GetInvoice', $postData);
        if ($response['result'] == 'success') {
            if($response['status'] == 'Paid'){
                return response()->json(['status' => true], 200);
            }else{
                return response()->json(['status' => false], 200);
            }
        } else {
            return response()->json(['status' => false], 200);
        }
    }

    private function getDefaultInstructions()
    {
        return '
        under construction
        '; 
    }

    private function getEmailTemplates()
    {
        $data = [];
        $data[""] = "-- None --";
        $emailTemplates = \Illuminate\Support\Facades\DB::table("tblemailtemplates")->where(["type" => "invoice", "custom" => "1"])->get();
        foreach ($emailTemplates as $emailTemplate) {
            $data[$emailTemplate->name] = $emailTemplate->name;
        }

        return $data;
    }
}
