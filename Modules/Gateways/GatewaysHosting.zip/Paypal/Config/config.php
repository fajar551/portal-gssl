<?php

return [
    'name' => 'Paypal'
];
