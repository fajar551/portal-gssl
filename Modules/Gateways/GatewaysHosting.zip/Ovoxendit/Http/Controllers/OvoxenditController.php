<?php

namespace Modules\Gateways\Ovoxendit\Http\Controllers;

use Illuminate\Contracts\Support\Renderable;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use Illuminate\Support\Str;
use Auth, Validator;

class OvoxenditController extends Controller
{
    function MetaData()
    {
        return array(
            'DisplayName' => 'OVO Xendit',
            'APIVersion' => '1.1', // Use API Version 1.1
            'DisableLocalCreditCardInput' => true,
            'TokenisedStorage' => false,
        );
    }

    function config()
    {
        return [
            'FriendlyName' => array(
                'Type' => 'System',
                'Value' => 'OVO Xendit',
            ),
            "UsageNotes" => array(
                "Type" => "System",
                "Value" => "Lihat dan kelola secret keys Anda di <a href=\"https://dashboard.xendit.co/settings/developers#api-keys\">Dasboard Xendit</a>",
            ),
            'secretKeyTest' => array(
                'FriendlyName' => 'Secret Key Test',
                'Type' => 'password',
                'Size' => '25',
                'Default' => '',
                'Description' => 'Enter secret key here',
            ),
            'secretKeyLive' => array(
                'FriendlyName' => 'Secret Key Live',
                'Type' => 'password',
                'Size' => '25',
                'Default' => '',
                'Description' => 'Enter secret key here',
            ),
            'tokenCallbackTest' => array(
                'FriendlyName' => 'Token verifikasi callback test',
                'Type' => 'text',
                'Size' => '25',
                'Default' => '',
                'Description' => 'Enter your token here',
            ),
            'tokenCallbackLive' => array(
                'FriendlyName' => 'Token verifikasi callback live',
                'Type' => 'text',
                'Size' => '25',
                'Default' => '',
                'Description' => 'Enter your token here',
            ),
            'clientId' => array(
                'FriendlyName' => 'Client id notification',
                'Type' => 'text',
                'Size' => '25',
                'Default' => '',
                'Description' => 'Client id for recieve email notification',
            ),
            'testMode' => array(
                'FriendlyName' => 'Test Mode',
                'Type' => 'yesno',
                'Description' => 'Tick to enable test mode',
            ),
            'instructions' => array(
                'FriendlyName' => 'Payment instructions',
                'Type' => 'textarea',
                'Rows' => '5',
                'Description' => 'The instructions you want displaying to customers who choose this payment method',
                'Default' => $this->getDefaultInstructions(),
            ),
            'emailTemplate' => array(
                'FriendlyName' => 'Email template',
                'Type' => 'dropdown',
                'Options' => $this->getEmailTemplates(),
                'Description' => 'Choose one',
            ),
        ];
    }

    public function link($params = [])
    {
        $invoiceid = $params['invoiceid'];

        return view('ovoxendit::index', [
            'url' => url("ovoxendit/payNow"),
            "url_update" => url('ovoxendit'),
            'invoiceid' => $invoiceid,
            'langpaynow' => $params["langpaynow"],
        ]);
    }

    private function call($method = 'post', $url = '', $token = '', array $postfield = [])
    {
        $postfield = json_encode($postfield);

        $curl = curl_init();
        curl_setopt_array($curl, array(
            CURLOPT_URL => $url,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => '',
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 0,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => strtoupper($method),
            CURLOPT_POSTFIELDS => $postfield,
            CURLOPT_HTTPHEADER => array(
                'Content-Type: application/json',
                'Authorization: Basic '.base64_encode("$token:"),
            ),
        ));

        $response = curl_exec($curl);

        curl_close($curl);
        return json_decode($response);
    }

    public function payNow(Request $request)
    {
        try {
            $invoiceid = $request->input('invoiceid');
            $phonenumber = $request->input('phonenumber');

            // validate phone
            if (!Str::startsWith($phonenumber, '62')) {
                throw new \Exception("Phone number must be starts with 62");
            }

            $invoice = new \App\Helpers\InvoiceClass($invoiceid);
            $params = $invoice->getGatewayInvoiceParams();

            $testMode = $params["testMode"];
            $secretKey = $testMode ? $params["secretKeyTest"] : $params["secretKeyLive"];
            $tokenModule = $testMode ? $params["tokenCallbackTest"] : $params["tokenCallbackLive"];
            $clientdetails = $params['clientdetails'];
            $userid = $clientdetails['userid'];
            $name = trim($clientdetails['firstname'].' '.$clientdetails['lastname']);
            $url = "https://api.xendit.co/ewallets/charges";

            $items = [];
            foreach ($invoice->getLineItems(true) as $key => $invoiceitem) {
                $items[] = [
                    'reference_id' => (string) $invoiceitem['relid'],
                    'name' => $invoiceitem['description'],
                    'category' => !empty($invoiceitem['type']) ? $invoiceitem['type'] : 'Custom',
                    'currency' => 'IDR',
                    'price' => ceil($invoiceitem['rawamount']),
                    'quantity' => 1,
                    'type' => 'PRODUCT',
                    'metadata' => [
                        'id' => $invoiceitem['id'],
                        'taxed' => $invoiceitem['taxed'],
                        'currency' => $invoiceitem['amount']->getCurrency(),
                    ],
                ];
            }

            $ewalletChargeParams = [
                'reference_id' => $invoiceid.'-'.time(),
                'currency' => 'IDR',
                'amount' => $testMode ? 80001 : ceil($params['amount']),
                'checkout_method' => 'ONE_TIME_PAYMENT',
                'channel_code' => 'ID_OVO',
                'channel_properties' => [
                    'mobile_number' => "+$phonenumber",
                ],
                'basket' => $items,
                'metadata' => [
                    'invoiceid' => $invoiceid,
                    'userid' => $userid,
                    'gateway' => 'ovoxendit',
                    'customsubject' => "Ada Pembayaran Masuk ke OVO Xendit Relabs",
                ],
            ];

            $response = $this->call("post", $url, $secretKey, $ewalletChargeParams);
            \Log::debug("=== paynow ovo");
            \Log::debug(json_decode(json_encode($response), true));
            if (isset($response->error_code)) {
                throw new \Exception($response->message);
            }

            $html='<p>Permintaan pembayaran berhasil dibuat.</p>';
            $html.='<p><b>Status :</b> '.$response->status.'</p>';
            $html.='<p><b>Phone :</b> '.$phonenumber.'</p>';
            $html.='<p><b>Amount :</b> '.$response->charge_amount.'</p>';
            $html.='<p><b>Cara Bayar :</b></p>';
            $html.='<ol>
                <li>Periksa notifikasi pada aplikasi OVO Anda.</li>
                <li>Lakukan pembayaran sesuai jumlah yang ditentukan</li>
                <li>Pembayaran berhasil dilakukan</li>
                <li>Kembali ke halaman ini, kemudian <a href="">Refresh</a> halaman ini</li>
            </ol>';

            return response()->json([
                'result' => 'success',
                'html' => $html,
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'result' => 'error',
                'message' => $e->getMessage(),
            ]);
        }
    }

    public function index(Request $request)
    {
        $postData = array(
            'invoiceid' => $request->input('id'),
        );
        $response = (new \App\Helpers\HelperApi)->localAPI('GetInvoice', $postData);
        if ($response['result'] == 'success') {
            if($response['status'] == 'Paid'){
                return response()->json(['status' => true], 200);
            }else{
                return response()->json(['status' => false], 200);
            }
        } else {
            return response()->json(['status' => false], 200);
        }
    }

    private function getDefaultInstructions()
    {
        return '
        under construction
        '; 
    }

    private function getEmailTemplates()
    {
        $data = [];
        $data[""] = "-- None --";
        $emailTemplates = \Illuminate\Support\Facades\DB::table("tblemailtemplates")->where(["type" => "invoice", "custom" => "1"])->get();
        foreach ($emailTemplates as $emailTemplate) {
            $data[$emailTemplate->name] = $emailTemplate->name;
        }

        return $data;
    }
}
