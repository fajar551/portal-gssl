<!-- Button trigger modal -->
<button type="button" class="btn btn-primary" data-toggle="modal" data-target="#paywithovo">
    {{$langpaynow}}
</button>
  
  <!-- Modal -->
  <div class="modal fade" id="paywithovo" tabindex="-1" role="dialog" aria-labelledby="paywithovoLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
      <form id="payment-form" action="" method="post">
          <div class="modal-content">
            <div class="modal-header">
              <h5 class="modal-title" id="paywithovoLabel">Bayar dengan OVO</h5>
              {{-- <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
              </button> --}}
            </div>
            <div class="modal-body text-left">
              <div class="alert alert-danger" id="errorMsg" style="display: none;"></div>
              <div class="alert alert-info" id="note">
                <b>Catatan:</b> Anda harus memiliki akun OVO terdaftar yang aktif dengan nomor telepon Indonesia sebelum melakukan pembayaran.
              </div>
              <div class="form-group" id="input-nomor">
                <label for="email">Nomor</label>
                <input id="phone" type="number" class="form-control" name="phone" autocomplete="off" placeholder="contoh: 628123456789">
              </div>
              <div class="alert alert-success" id="successContainer" style="display: none;"></div>
            </div>
            <div class="modal-footer">
              <button type="button" class="btn btn-secondary closed" data-dismiss="modal">Tutup</button>
              <button type="submit" class="btn btn-primary submit">Bayar</button>
            </div>
          </div>
      </form>
    </div>
  </div>

<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.3/jquery.validate.min.js"></script>
<script src="https://cdn.jsdelivr.net/jquery.validation/1.16.0/additional-methods.min.js"></script>
<script>
    $(document).ready(function() {
        // update
        setInterval(update, 5000);

        var $form = $('#payment-form');
        $form.validate({
            normalizer: function (value) {
                return value ? value.trim() : value;
            },
            errorElement: 'small',
            errorClass: "text-danger font-weight-normal is-invalid",
            rules: {
                phone: {
                    required: true,
                    number: true
                },
            },
        });
        $form.submit(function(event) {
            event.preventDefault();
            var isFormValid = $form.valid();
            if (!isFormValid) {
                return false;
            }
            $form.find('.submit').prop('disabled', true);
            $form.find('.closed').prop('disabled', true);
            // console.log('ok');
            $.ajax({
                url: "{{$url}}",
                type: 'post',
                data: {
                    _token: "{{csrf_token()}}",
                    invoiceid: "{{$invoiceid}}",
                    phonenumber: $("#phone").val(),
                },
                success: function(res) {
                    $form.find('.submit').prop('disabled', false);
                    $form.find('.closed').prop('disabled', false);
                    // console.log(res);
                    if (res.result == 'success') {
                        $("#errorMsg").hide();
                        $("#input-nomor").remove();
                        $("#note").remove();
                        $("#successContainer").html(res.html).show();
                        $form.find('.submit').remove();
                    } else {
                        $("#errorMsg").text(res.message).show();
                    }
                },
                error: function() {
                    $form.find('.submit').prop('disabled', false);
                    $form.find('.closed').prop('disabled', false);
                    $("#errorMsg").text('Error! Contact your administrator').show();
                }
            });
        });
    });
    function update() {
        $.ajax({
            type : 'GET',
            url : "{{$url_update}}",
            data: {id: "{{$invoiceid}}", _token: "{{csrf_token()}}"},
            success : function(data){
                if(data.status){
                    location.reload();
                }	
            },
        });
    };
</script>
