<?php

namespace Modules\Gateways\Bsivaxendit\Http\Controllers;

use Illuminate\Contracts\Support\Renderable;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use DB;

class BsivaxenditController extends Controller
{
    function MetaData()
    {
        return array(
            'DisplayName' => 'BSI VA Xendit',
            'APIVersion' => '1.1', // Use API Version 1.1
            'DisableLocalCreditCardInput' => true,
            'TokenisedStorage' => false,
        );
    }

    function config()
    {
        return [
            'FriendlyName' => array(
                'Type' => 'System',
                'Value' => 'BSI VA Xendit',
            ),
            "UsageNotes" => array(
                "Type" => "System",
                "Value" => "Lihat dan kelola secret keys Anda di <a href=\"https://dashboard.xendit.co/settings/developers#api-keys\">Dasboard Xendit</a>",
            ),
            'secretKeyTest' => array(
                'FriendlyName' => 'Secret Key Test',
                'Type' => 'password',
                'Size' => '25',
                'Default' => '',
                'Description' => 'Enter secret key here',
            ),
            'secretKeyLive' => array(
                'FriendlyName' => 'Secret Key Live',
                'Type' => 'password',
                'Size' => '25',
                'Default' => '',
                'Description' => 'Enter secret key here',
            ),
            'tokenCallbackTest' => array(
                'FriendlyName' => 'Token verifikasi callback test',
                'Type' => 'text',
                'Size' => '25',
                'Default' => '',
                'Description' => 'Enter your token here',
            ),
            'tokenCallbackLive' => array(
                'FriendlyName' => 'Token verifikasi callback live',
                'Type' => 'text',
                'Size' => '25',
                'Default' => '',
                'Description' => 'Enter your token here',
            ),
            'merchantCode' => array(
                'FriendlyName' => 'Merchant Code',
                'Type' => 'text',
                'Size' => '25',
                'Default' => '',
                'Description' => '<i>Note: merchant number</i>',
            ),
            'vaPrefix' => array(
                'FriendlyName' => 'VA Prefix',
                'Type' => 'text',
                'Size' => '25',
                'Default' => '9999',
                'Description' => '<i>Note: Not a merchant number</i>. Example: 1234',
            ),
            'vaDigits' => array(
                'FriendlyName' => 'VA number digit length',
                'Type' => 'text',
                'Size' => '25',
                'Default' => '6',
                'Description' => 'Digit length after prefix.',
            ),
            'clientId' => array(
                'FriendlyName' => 'Client id notification',
                'Type' => 'text',
                'Size' => '25',
                'Default' => '',
                'Description' => 'Client id for recieve email notification',
            ),
            'isFixed' => array(
                'FriendlyName' => 'Fixed Va',
                'Type' => 'yesno',
                'Description' => 'Tick to enable fixed virtual account',
            ),
            'testMode' => array(
                'FriendlyName' => 'Test Mode',
                'Type' => 'yesno',
                'Description' => 'Tick to enable test mode',
            ),
            'instructions' => array(
                'FriendlyName' => 'Payment instructions',
                'Type' => 'textarea',
                'Rows' => '5',
                'Description' => 'The instructions you want displaying to customers who choose this payment method',
                'Default' => $this->getDefaultInstructions(),
            ),
            'emailTemplate' => array(
                'FriendlyName' => 'Email template',
                'Type' => 'dropdown',
                'Options' => $this->getEmailTemplates(),
                'Description' => 'Choose one',
            ),
        ];
    }

    public function link($params)
    {
        try {
            $isFixed = $params["isFixed"];
            $testMode = $params["testMode"];
            $secretKey = $testMode ? $params["secretKeyTest"] : $params["secretKeyLive"];
            $clientdetails = $params['clientdetails'];
            $userid = $clientdetails['userid'];
            $invoiceid = $params['invoiceid'];
            $name = trim($clientdetails['firstname'].' '.$clientdetails['lastname']);
            $url = "https://api.xendit.co/callback_virtual_accounts";
            
            /**
             * Note: Change this
             */
            $bank_code = "BSI";
            $view = "bsivaxendit::index";
            $url_update = url('bsivaxendit');
            $message_link = "Silahkan melakukan pembayaran ke nomor BSI Virtual Account Anda berikut: <strong>%s</strong>";
            $customfield_name = "Fixed VA $bank_code";

            if ($isFixed) {
                $customfield_id = $this->loadCustomfield($customfield_name);
    
                // get customfield value
                $condition = array("fieldid" => $customfield_id, "relid" => $userid);
                $customfieldvalue = DB::table("tblcustomfieldsvalues")->where($condition)->first();
                $value = $customfieldvalue ? $customfieldvalue->value : 0;

                // check exists
                if ($value) {
                    $virtualaccountnumber = $customfieldvalue->value;
                } else {
                    $number = str_pad($userid,$params['vaDigits'],"0",STR_PAD_LEFT); 
                    $virtual_account_number = $params['vaPrefix'].$number;
                    $external_id = $bank_code."-".$number;
                    $postfields = [
                        "external_id" => $external_id,
                        "bank_code" => $bank_code,
                        "name" => $name,
                        "virtual_account_number" => $virtual_account_number,
                    ];
                    $response = $this->call($url, $secretKey, $postfields);
                    // \Log::debug(json_decode(json_encode($response), true));
                    if (isset($response->error_code)) {
                        if ($response->error_code == 'DUPLICATE_CALLBACK_VIRTUAL_ACCOUNT_ERROR') {
                            $virtualaccountnumber = $params['merchantCode'].$virtual_account_number;

                            DB::table("tblcustomfieldsvalues")->updateOrInsert(
                                $condition,
                                ['value' => $virtualaccountnumber]
                            );
                        } else {
                            throw new \Exception($response->message);
                        }
                    } else {
                        $virtualaccountnumber = $response->account_number;
                        
                        // save customfield value
                        $condition["value"] = $virtualaccountnumber;
                        DB::table("tblcustomfieldsvalues")->insert($condition);
                    }
                }

                return view($view, [
                    "message" => sprintf($message_link, $virtualaccountnumber),
                    "invoiceid" => $invoiceid,
                    "url_update" => $url_update,
                    "instructions" => $params['instructions'],
                ]);
            } else {
                $external_id = $invoiceid."-".$userid;
                $postfields = [
                    "external_id" => $external_id,
                    "bank_code" => $bank_code,
                    "name" => $name,
                    "is_closed" => true,
                    "is_single_use" => true,
                    "expected_amount" => round($params['amount'], 2),
                    "description" => $params['description'],
                ];
                $response = $this->call($url, $secretKey, $postfields);
                \Log::debug("== bsi va xendit");
                \Log::debug(json_decode(json_encode($response), true));
                if (isset($response->error_code)) {
                    throw new \Exception($response->message);
                }
                
                $virtualaccountnumber = $response->account_number;
                
                return view($view, [
                    "message" => sprintf($message_link, $virtualaccountnumber),
                    "invoiceid" => $invoiceid,
                    "url_update" => $url_update,
                    "instructions" => $params['instructions'],
                ]);
            }
            
        } catch (\Exception $e) {
            return $e->getMessage();
        }
    }

    private function call($url = '', $token = '', array $postfield = [])
    {
        $postfield = json_encode($postfield);

        $curl = curl_init();
        curl_setopt_array($curl, array(
            CURLOPT_URL => $url,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => '',
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 0,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => 'POST',
            CURLOPT_POSTFIELDS => $postfield,
            CURLOPT_HTTPHEADER => array(
                'Content-Type: application/json',
                'Authorization: Basic '.base64_encode("$token:"),
            ),
        ));

        $response = curl_exec($curl);

        curl_close($curl);
        return json_decode($response);
    }

    private function loadCustomfield($fieldname)
    {
        DB::beginTransaction();
        try {
            $table = "tblcustomfields";
            $condition = array("type" => "client", "fieldname" => $fieldname, "relid" => 0);

            $customfield = DB::table($table)->where($condition)->first();
            if (!$customfield) {
                $condition["fieldtype"] = "text";
                $condition["adminonly"] = "on";
                $condition["required"] = "";
                $condition["showorder"] = "";
                $condition["showinvoice"] = "";
                $condition["sortorder"] = "";
                $id = DB::table($table)->insertGetId($condition);
            } else {
                $id = $customfield->id;
            }

            DB::commit();
            return $id;
        } catch (\Exception $e) {
            DB::rollback();
            return 0;
        }
    }

    public function index(Request $request)
    {
        $postData = array(
            'invoiceid' => $request->input('id'),
        );
        $response = (new \App\Helpers\HelperApi)->localAPI('GetInvoice', $postData);
        if ($response['result'] == 'success') {
            if($response['status'] == 'Paid'){
                return response()->json(['status' => true], 200);
            }else{
                return response()->json(['status' => false], 200);
            }
        } else {
            return response()->json(['status' => false], 200);
        }
    }

    private function getDefaultInstructions()
    {
        return '
        under construction
        '; 
    }

    private function getEmailTemplates()
    {
        $data = [];
        $data[""] = "-- None --";
        $emailTemplates = \Illuminate\Support\Facades\DB::table("tblemailtemplates")->where(["type" => "invoice", "custom" => "1"])->get();
        foreach ($emailTemplates as $emailTemplate) {
            $data[$emailTemplate->name] = $emailTemplate->name;
        }

        return $data;
    }
}
