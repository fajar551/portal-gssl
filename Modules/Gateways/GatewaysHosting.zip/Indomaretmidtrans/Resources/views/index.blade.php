<div id="payNowContainer">
    <button onclick="payNow()" class="btn btn-primary">{{$langpaynow}}</button>
</div>
<div id="resultContainer"></div>

<script>
    $(document).ready(function() {
        setInterval(update, 5000);
    });
    function update() {
        $.ajax({
            type : 'GET',
            url : "{{$url_update}}",
            data: {id: "{{$invoiceid}}", _token: "{{csrf_token()}}"},
            success : function(data){
                if(data.status){
                    location.reload();
                }	
            },
        });
    };
    function payNow() {
        var payNowContainer = $("#payNowContainer");
        var resultContainer = $("#resultContainer");
        $.ajax({
            url: "{{$url}}",
            type: "post",
            data: {
                _token: "{{csrf_token()}}",
                invoiceid: "{{$invoiceid}}",
            },
            success: function(res) {
                console.log(res);
                payNowContainer.hide();
                resultContainer.html(res.html);
            },
            error: function() {
                console.log('error');
                payNowContainer.hide();
                resultContainer.html('<p class="text-danger">Payment Error! Please contact your administrator.</p>');
            },
        });
    }
</script>
