<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Payment</title>
</head>
<body>
    <p>Pembayaran sedang di proses... Mohon tunggu, Anda akan dikembalikan ke halaman invoice</p>
    <script type="text/javascript">
        window.setTimeout(function() {
            window.location.href = "{{$returnurl}}";
        }, 10000);
    </script>
</body>
</html>
