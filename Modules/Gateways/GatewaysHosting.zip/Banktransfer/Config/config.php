<?php

return [
    'name' => 'Banktransfer'
];
