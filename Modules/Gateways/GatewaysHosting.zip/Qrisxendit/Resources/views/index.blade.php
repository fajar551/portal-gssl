<p>Anda dapat membayar melalui jaringan QRIS.</p>
<div>
    {!! QrCode::size(250)->generate($qrcode); !!}
</div>
<p>
    Bayar dengan GoPay, Linkaja, OVO <a href="https://aspi-indonesia.or.id/informasi-qris" target="_blank">Lihat lainnya</a>
</p>

<!--<button type="button" class="btn btn-primary" data-toggle="modal" data-target="#qrisModal">-->
<!--    Bayar Sekarang-->
<!--</button>-->
  
<div class="modal fade" id="qrisModal" tabindex="-1" role="dialog" aria-labelledby="qrisModalLabel" aria-hidden="true">
<div class="modal-dialog" role="document">
    <div class="modal-content text-left">
        <div class="modal-header">
            <h5 class="modal-title" id="qrisModalLabel">Scan Kode QR Berikut</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
        <div class="modal-body">
            <div class="alert alert-info" role="alert">
                Anda dapat membayar melalui jaringan QRIS (misal, OVO, Gopay, Dana, LinkAja, BCA, Shopeepay, <a href="https://aspi-indonesia.or.id/informasi-qris" target="_blank">lihat lebih banyak</a>).
            </div>
            <div class="text-center">
                {!! QrCode::size(250)->generate($qrcode); !!}
            </div>
            <p class="mt-4">
                <strong>Catatan:</strong> halaman ini aka me-<a href="">refresh</a> otomasi setelah pembayaran berhasil dilakukan.
            </p>
        </div>
        <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-dismiss="modal">Tutup</button>
        </div>
    </div>
</div>
</div>

<script>
    $(document).ready(function() {
        setInterval(update, 5000);
    });
    function update() {
        $.ajax({
            type : 'POST',
            url : "{{url('qrisxendit/ajax')}}",
            data: {id: "{{$invoiceid}}", _token: "{{csrf_token()}}"},
            success : function(data){
                if(data.status){
                    location.reload();
                }	
            },
        });
    };
</script>
