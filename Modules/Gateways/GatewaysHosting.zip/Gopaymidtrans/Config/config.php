<?php

return [
    'name' => 'Gopaymidtrans'
];
