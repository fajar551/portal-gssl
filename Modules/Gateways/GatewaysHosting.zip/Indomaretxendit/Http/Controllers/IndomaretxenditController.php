<?php

namespace Modules\Gateways\Indomaretxendit\Http\Controllers;

use Illuminate\Contracts\Support\Renderable;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller;

class IndomaretxenditController extends Controller
{
    function MetaData()
    {
        return array(
            'DisplayName' => 'Indomaret Xendit',
            'APIVersion' => '1.1', // Use API Version 1.1
            'DisableLocalCreditCardInput' => true,
            'TokenisedStorage' => false,
        );
    }

    function config()
    {
        return [
            'FriendlyName' => array(
                'Type' => 'System',
                'Value' => 'Indomaret Xendit',
            ),
            "UsageNotes" => array(
                "Type" => "System",
                "Value" => "Lihat dan kelola secret keys Anda di <a href=\"https://dashboard.xendit.co/settings/developers#api-keys\">Dasboard Xendit</a>.",
            ),
            'secretKeyTest' => array(
                'FriendlyName' => 'Secret Key Test',
                'Type' => 'password',
                'Size' => '25',
                'Default' => '',
                'Description' => 'Enter secret key here',
            ),
            'secretKeyLive' => array(
                'FriendlyName' => 'Secret Key Live',
                'Type' => 'password',
                'Size' => '25',
                'Default' => '',
                'Description' => 'Enter secret key here',
            ),
            'tokenCallbackTest' => array(
                'FriendlyName' => 'Token verifikasi callback test',
                'Type' => 'text',
                'Size' => '25',
                'Default' => '',
                'Description' => 'Enter your token here',
            ),
            'tokenCallbackLive' => array(
                'FriendlyName' => 'Token verifikasi callback live',
                'Type' => 'text',
                'Size' => '25',
                'Default' => '',
                'Description' => 'Enter your token here',
            ),
            'clientId' => array(
                'FriendlyName' => 'Client id notification',
                'Type' => 'text',
                'Size' => '25',
                'Default' => '',
                'Description' => 'Client id for recieve email notification',
            ),
            'testMode' => array(
                'FriendlyName' => 'Test Mode',
                'Type' => 'yesno',
                'Description' => 'Tick to enable test mode',
            ),
            'instructions' => array(
                'FriendlyName' => 'Payment instructions',
                'Type' => 'textarea',
                'Rows' => '5',
                'Description' => 'The instructions you want displaying to customers who choose this payment method',
                'Default' => $this->getDefaultInstructions(),
            ),
            'emailTemplate' => array(
                'FriendlyName' => 'Email template',
                'Type' => 'dropdown',
                'Options' => $this->getEmailTemplates(),
                'Description' => 'Choose one',
            ),
        ];
    }

    public function link($params)
    {
        try {
            $testMode = $params["testMode"];
            $secretKey = $testMode ? $params["secretKeyTest"] : $params["secretKeyLive"];
            $clientdetails = $params['clientdetails'];
            $userid = $clientdetails['userid'];
            $invoiceid = $params['invoiceid'];
            $name = trim($clientdetails['firstname'].' '.$clientdetails['lastname']);
            $url = "https://api.xendit.co/fixed_payment_code";
            
            // Change this
            $view = "indomaretxendit::index";
            $message_link = "Kode Bayar Indomaret Anda: <strong>%s</strong>";

            $paramsData = [
                'external_id' => (string) $invoiceid,
                'retail_outlet_name' => 'INDOMARET',
                'name' => $name,
                'expected_amount' => round($params['amount'], 2),
                'is_single_use' => true,
            ];
            $response = $this->call($url, $secretKey, $paramsData);
            \Log::debug("===indomaret link===");
            \Log::debug(json_decode(json_encode($response), true));
            if (isset($response->error_code)) {
                throw new \Exception($response->message);
            }

            return view($view, [
                "message" => sprintf($message_link, $response->payment_code),
                "invoiceid" => $invoiceid,
                "url_update" => url("indomaretxendit"),
            ]);
        } catch (\Exception $e) {
            return $e->getMessage();
        }
    }

    private function call($url = '', $token = '', array $postfield = [])
    {
        $postfield = json_encode($postfield);

        $curl = curl_init();
        curl_setopt_array($curl, array(
            CURLOPT_URL => $url,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => '',
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 0,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => 'POST',
            CURLOPT_POSTFIELDS => $postfield,
            CURLOPT_HTTPHEADER => array(
                'Content-Type: application/json',
                'Authorization: Basic '.base64_encode("$token:"),
            ),
        ));

        $response = curl_exec($curl);

        curl_close($curl);
        return json_decode($response);
    }

    public function index(Request $request)
    {
        $postData = array(
            'invoiceid' => $request->input('id'),
        );
        $response = (new \App\Helpers\HelperApi)->localAPI('GetInvoice', $postData);
        if ($response['result'] == 'success') {
            if($response['status'] == 'Paid'){
                return response()->json(['status' => true], 200);
            }else{
                return response()->json(['status' => false], 200);
            }
        } else {
            return response()->json(['status' => false], 200);
        }
    }

    private function getDefaultInstructions()
    {
        return '
        under construction
        '; 
    }

    private function getEmailTemplates()
    {
        $data = [];
        $data[""] = "-- None --";
        $emailTemplates = \Illuminate\Support\Facades\DB::table("tblemailtemplates")->where(["type" => "invoice", "custom" => "1"])->get();
        foreach ($emailTemplates as $emailTemplate) {
            $data[$emailTemplate->name] = $emailTemplate->name;
        }

        return $data;
    }
}
