<?php

namespace Modules\Gateways\Sampoernavaxendit\Listeners;

use App\Events\InvoiceCreation;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Contracts\Queue\ShouldQueue;

class Createva
{
    /**
     * Create the event listener.
     *
     * @return void
     */
    public function __construct()
    {
        //
    }

    /**
     * Handle the event.
     *
     * @param InvoiceCreation $event
     * @return void
     */
    public function handle(InvoiceCreation $event)
    {
        //
        $source = $event->source;
        $user = $event->user; // mixed
        $invoiceid = $event->invoiceid;
        $status = $event->status;
        // \Log::debug("sampoernavaxendit Createva start");

        \Illuminate\Support\Facades\DB::beginTransaction();
        try {
            $invoice = new \App\Helpers\InvoiceClass($invoiceid);
            $params = $invoice->getGatewayInvoiceParams();
            $paymentmethod = $params["paymentmethod"];

            /**
             * Note: Change this
             */
            $bank_code = "SAHABAT_SAMPOERNA";
            $gateway = "sampoernavaxendit";
            $customfield_name = "Fixed VA $bank_code";

            // check gateway
            if (strtolower($paymentmethod) == $gateway) {
                $isFixed = $params["isFixed"];
                $testMode = $params["testMode"];
                $secretKey = $testMode ? $params["secretKeyTest"] : $params["secretKeyLive"];
                $clientdetails = $params['clientdetails'];
                $userid = $clientdetails['userid'];
                $invoiceid = $params['invoiceid'];
                $name = trim($clientdetails['firstname'].' '.$clientdetails['lastname']);
                $url = "https://api.xendit.co/callback_virtual_accounts";
    
                if ($isFixed) {
                    $customfield_id = $this->loadCustomfield($customfield_name);

                    // check value
                    $value = $this->getCustomfieldValue($customfield_id, $userid);

                    // if value not exists, then fill the value first
                    if (!$value) {
                        $number = str_pad($userid,$params['vaDigits'],"0",STR_PAD_LEFT); 
                        $virtual_account_number = $params['vaPrefix'].$number;
                        $external_id = $bank_code."-".$number;
                        $postfields = [
                            "external_id" => $external_id,
                            "bank_code" => $bank_code,
                            "name" => $name,
                            "virtual_account_number" => $virtual_account_number,
                        ];
                        $response = $this->call($url, $secretKey, $postfields);
                        // \Log::debug(json_decode(json_encode($response), true));
                        if (isset($response->error_code)) {
                            throw new \Exception($response->message);
                        } else {
                            $virtualaccountnumber = $response->account_number;
                            
                            // save customfield value
                            $condition = array("fieldid" => $customfield_id, "relid" => $userid);
                            $condition["value"] = $virtualaccountnumber;
                            \Illuminate\Support\Facades\DB::table("tblcustomfieldsvalues")->insert($condition);
                            $nova = $virtualaccountnumber;
                        }
                    } else {
                        $nova = $value;
                    }

                    // send email
                    $customvars = [
                        "nova" => $nova,
                    ];
                    $this->sendemail($invoiceid, $params["emailTemplate"] ?? "", $customvars);
                }
            }
            \Illuminate\Support\Facades\DB::commit();
        } catch (\Exception $e) {
            \Log::debug("Error Createva hooks with invoiceid: $invoiceid");
            \Log::debug($e->getMessage());
            \Illuminate\Support\Facades\DB::rollback();
        }
    }
    
    private function sendemail($invoiceid, $emailTemplate, $customvars = [])
    {
        if ($emailTemplate) {
            $values["id"] = $invoiceid;
            $values["messagename"] = $emailTemplate;
            $values["customvars"] = base64_encode(serialize($customvars));
            $response = (new \App\Helpers\HelperApi)->localAPI('SendEmail', $values);
            return $response;
        }
    }

    private function getCustomfieldValue($customfield_id, $userid)
    {
        // get customfield value
        $condition = array("fieldid" => $customfield_id, "relid" => $userid);
        $customfieldvalue =  \Illuminate\Support\Facades\DB::table("tblcustomfieldsvalues")->where($condition)->first();
        $value = $customfieldvalue ? $customfieldvalue->value : "";
        // \Log::debug("getCustomfieldValue: $value");
        return $value;
    }

    private function loadCustomfield($fieldname)
    {
        \Illuminate\Support\Facades\DB::beginTransaction();
        try {
            $table = "tblcustomfields";
            $condition = array("type" => "client", "fieldname" => $fieldname, "relid" => 0);

            $customfield = \Illuminate\Support\Facades\DB::table($table)->where($condition)->first();
            if (!$customfield) {
                $condition["fieldtype"] = "text";
                $condition["adminonly"] = "on";
                $condition["required"] = "";
                $condition["showorder"] = "";
                $condition["showinvoice"] = "";
                $condition["sortorder"] = "";
                $id = \Illuminate\Support\Facades\DB::table($table)->insertGetId($condition);
            } else {
                $id = $customfield->id;
            }

            \Illuminate\Support\Facades\DB::commit();
            return $id;
        } catch (\Exception $e) {
            \Illuminate\Support\Facades\DB::rollback();
            return 0;
        }
    }

    private function call($url = '', $token = '', array $postfield = [])
    {
        $postfield = json_encode($postfield);

        $curl = curl_init();
        curl_setopt_array($curl, array(
            CURLOPT_URL => $url,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => '',
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 0,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => 'POST',
            CURLOPT_POSTFIELDS => $postfield,
            CURLOPT_HTTPHEADER => array(
                'Content-Type: application/json',
                'Authorization: Basic '.base64_encode("$token:"),
            ),
        ));

        $response = curl_exec($curl);

        curl_close($curl);
        return json_decode($response);
    }
}
