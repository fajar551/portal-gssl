<?php

return [
    'name' => 'Sampoernavaxendit'
];
