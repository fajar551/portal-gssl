<?php

namespace Modules\Gateways\Sampoernavaxendit\Http\Controllers;

use Illuminate\Contracts\Support\Renderable;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use DB;

class SampoernavaxenditController extends Controller
{
    function MetaData()
    {
        return array(
            'DisplayName' => 'Sampoerna VA Xendit',
            'APIVersion' => '1.1', // Use API Version 1.1
            'DisableLocalCreditCardInput' => true,
            'TokenisedStorage' => false,
        );
    }

    function config()
    {
        return [
            'FriendlyName' => array(
                'Type' => 'System',
                'Value' => 'Sampoerna VA Xendit',
            ),
            "UsageNotes" => array(
                "Type" => "System",
                "Value" => "Lihat dan kelola secret keys Anda di <a href=\"https://dashboard.xendit.co/settings/developers#api-keys\">Dasboard Xendit</a>",
            ),
            'secretKeyTest' => array(
                'FriendlyName' => 'Secret Key Test',
                'Type' => 'password',
                'Size' => '25',
                'Default' => '',
                'Description' => 'Enter secret key here',
            ),
            'secretKeyLive' => array(
                'FriendlyName' => 'Secret Key Live',
                'Type' => 'password',
                'Size' => '25',
                'Default' => '',
                'Description' => 'Enter secret key here',
            ),
            'tokenCallbackTest' => array(
                'FriendlyName' => 'Token verifikasi callback test',
                'Type' => 'text',
                'Size' => '25',
                'Default' => '',
                'Description' => 'Enter your token here',
            ),
            'tokenCallbackLive' => array(
                'FriendlyName' => 'Token verifikasi callback live',
                'Type' => 'text',
                'Size' => '25',
                'Default' => '',
                'Description' => 'Enter your token here',
            ),
            'merchantCode' => array(
                'FriendlyName' => 'Merchant Code',
                'Type' => 'text',
                'Size' => '25',
                'Default' => '',
                'Description' => '<i>Note: merchant number</i>',
            ),
            'vaPrefix' => array(
                'FriendlyName' => 'VA Prefix',
                'Type' => 'text',
                'Size' => '25',
                'Default' => '9999',
                'Description' => '<i>Note: Not a merchant number</i>. Example: 1234',
            ),
            'vaDigits' => array(
                'FriendlyName' => 'VA number digit length',
                'Type' => 'text',
                'Size' => '25',
                'Default' => '6',
                'Description' => 'Digit length after prefix.',
            ),
            'clientId' => array(
                'FriendlyName' => 'Client id notification',
                'Type' => 'text',
                'Size' => '25',
                'Default' => '',
                'Description' => 'Client id for recieve email notification',
            ),
            'isFixed' => array(
                'FriendlyName' => 'Fixed Va',
                'Type' => 'yesno',
                'Description' => 'Tick to enable fixed virtual account',
            ),
            'testMode' => array(
                'FriendlyName' => 'Test Mode',
                'Type' => 'yesno',
                'Description' => 'Tick to enable test mode',
            ),
            'instructions' => array(
                'FriendlyName' => 'Payment instructions',
                'Type' => 'textarea',
                'Rows' => '5',
                'Description' => 'The instructions you want displaying to customers who choose this payment method',
                'Default' => $this->getDefaultInstructions(),
            ),
            'emailTemplate' => array(
                'FriendlyName' => 'Email template',
                'Type' => 'dropdown',
                'Options' => $this->getEmailTemplates(),
                'Description' => 'Choose one',
            ),
        ];
    }

    public function link($params = [])
    {
        $isFixed = $params["isFixed"];
        $testMode = $params["testMode"];
        $secretKey = $testMode ? $params["secretKeyTest"] : $params["secretKeyLive"];
        $clientdetails = $params['clientdetails'];
        $userid = $clientdetails['userid'];
        $invoiceid = $params['invoiceid'];
        $name = trim($clientdetails['firstname'].' '.$clientdetails['lastname']);
        $url = "https://api.xendit.co/callback_virtual_accounts";
        
        /**
         * Note: Change this
         */
        $bank_code = "SAHABAT_SAMPOERNA";
        $view = "sampoernavaxendit::index";
        $url_update = url('sampoernavaxendit');
        $message_link = "Silahkan melakukan pembayaran ke nomor Sampoerna Virtual Account Anda berikut: <strong>%s</strong>";
        $customfield_name = "Fixed VA $bank_code";

        try {
            if ($isFixed) {
                $customfield_id = $this->loadCustomfield($customfield_name);
    
                // get customfield value
                $condition = array("fieldid" => $customfield_id, "relid" => $userid);
                $customfieldvalue = DB::table("tblcustomfieldsvalues")->where($condition)->first();
                $value = $customfieldvalue ? $customfieldvalue->value : 0;
    
                // check exists
                if ($value) {
                    $virtualaccountnumber = $customfieldvalue->value;
                } else {
                    $number = str_pad($userid,$params['vaDigits'],"0",STR_PAD_LEFT); 
                    $virtual_account_number = $params['vaPrefix'].$number;
                    $external_id = $bank_code."-".$number;
                    $postfields = [
                        "external_id" => $external_id,
                        "bank_code" => $bank_code,
                        "name" => $name,
                        "virtual_account_number" => $virtual_account_number,
                    ];
                    $response = $this->call($url, $secretKey, $postfields);
                    // \Log::debug(json_decode(json_encode($response), true));
                    if (isset($response->error_code)) {
                        if ($response->error_code == 'DUPLICATE_CALLBACK_VIRTUAL_ACCOUNT_ERROR') {
                            $virtualaccountnumber = $params['merchantCode'].$virtual_account_number;

                            DB::table("tblcustomfieldsvalues")->updateOrInsert(
                                $condition,
                                ['value' => $virtualaccountnumber]
                            );
                        } else {
                            throw new \Exception($response->message);
                        }
                    } else {
                        $virtualaccountnumber = $response->account_number;
                        
                        // save customfield value
                        $condition["value"] = $virtualaccountnumber;
                        DB::table("tblcustomfieldsvalues")->insert($condition);
                    }
                }
    
                return view($view, [
                    "message" => sprintf($message_link, $virtualaccountnumber),
                    "invoiceid" => $invoiceid,
                    "url_update" => $url_update,
                    "instructions" => $params['instructions'],
                ]);
            } else {
                $external_id = $invoiceid."-".$userid;
                $postfields = [
                    "external_id" => $external_id,
                    "bank_code" => $bank_code,
                    "name" => $name,
                ];
                $response = $this->call($url, $secretKey, $postfields);
                if (isset($response->error_code)) {
                    throw new \Exception($response->message);
                }
                
                $virtualaccountnumber = $response->account_number;
                
                return view($view, [
                    "message" => sprintf($message_link, $virtualaccountnumber),
                    "invoiceid" => $invoiceid,
                    "url_update" => $url_update,
                    "instructions" => $params['instructions'],
                ]);
            }
        } catch (\Exception $e) {
            return $e->getMessage();
        }
    }

    private function call($url = '', $token = '', array $postfield = [])
    {
        $postfield = json_encode($postfield);

        $curl = curl_init();
        curl_setopt_array($curl, array(
            CURLOPT_URL => $url,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => '',
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 0,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => 'POST',
            CURLOPT_POSTFIELDS => $postfield,
            CURLOPT_HTTPHEADER => array(
                'Content-Type: application/json',
                'Authorization: Basic '.base64_encode("$token:"),
            ),
        ));

        $response = curl_exec($curl);

        curl_close($curl);
        return json_decode($response);
    }

    private function loadCustomfield($fieldname)
    {
        DB::beginTransaction();
        try {
            $table = "tblcustomfields";
            $condition = array("type" => "client", "fieldname" => $fieldname, "relid" => 0);

            $customfield = DB::table($table)->where($condition)->first();
            if (!$customfield) {
                $condition["fieldtype"] = "text";
                $condition["adminonly"] = "on";
                $condition["required"] = "";
                $condition["showorder"] = "";
                $condition["showinvoice"] = "";
                $condition["sortorder"] = "";
                $id = DB::table($table)->insertGetId($condition);
            } else {
                $id = $customfield->id;
            }

            DB::commit();
            return $id;
        } catch (\Exception $e) {
            DB::rollback();
            return 0;
        }
    }

    public function index(Request $request)
    {
        $postData = array(
            'invoiceid' => $request->input('id'),
        );
        $response = (new \App\Helpers\HelperApi)->localAPI('GetInvoice', $postData);
        if ($response['result'] == 'success') {
            if($response['status'] == 'Paid'){
                return response()->json(['status' => true], 200);
            }else{
                return response()->json(['status' => false], 200);
            }
        } else {
            return response()->json(['status' => false], 200);
        }
    }

    private function getDefaultInstructions()
    {
        return '
        <div class="bg_light" style="box-sizing: border-box; -ms-text-size-adjust: 100%; -webkit-text-size-adjust: 100%; text-align: center; background-color: #fafafa; background-image: none; background-repeat: repeat; background-position: top left; background-attachment: scroll;">
        <div class="container" style="box-sizing: border-box; -ms-text-size-adjust: 100%; -webkit-text-size-adjust: 100%; width: 100%; padding-right: 15px; padding-left: 15px; margin-right: auto; margin-left: auto;">
        <div class="row" style="box-sizing: border-box; -ms-text-size-adjust: 100%; -webkit-text-size-adjust: 100%; display: flex; -ms-flex-wrap: wrap; flex-wrap: wrap; margin-right: -15px; margin-left: -15px;">
        <div class="col-md-12" style="box-sizing: border-box; -ms-text-size-adjust: 100%; -webkit-text-size-adjust: 100%; position: relative; width: 100%; padding-right: 15px; padding-left: 15px;">
        <div class="bank-payment" style="box-sizing: border-box; font-weight: bold; font-size: 14px; font-family: \'montserrat\', sans-serif; color: #212121; padding: 2.5em;"><img style="box-sizing: border-box; -ms-text-size-adjust: 100%; -webkit-text-size-adjust: 100%; width: 130px; vertical-align: middle; border-style: none; -ms-interpolation-mode: bicubic;" src="https://qwords.com/logo-email-template/banksampoerna.png"><br style="box-sizing: border-box; -ms-text-size-adjust: 100%; -webkit-text-size-adjust: 100%;">Sampoerna Virtual Account {$nova}</div>
        </div>
        </div>
        </div>
        </div>
        <div class="bg_white" style="box-sizing: border-box; -ms-text-size-adjust: 100%; -webkit-text-size-adjust: 100%; background-color: #ffffff; background-image: none; background-repeat: repeat; background-position: top left; background-attachment: scroll;">
        <div class="container" style="box-sizing: border-box; -ms-text-size-adjust: 100%; -webkit-text-size-adjust: 100%; width: 100%; padding-right: 15px; padding-left: 15px; margin-right: auto; margin-left: auto;">
        <div class="row" style="box-sizing: border-box; -ms-text-size-adjust: 100%; -webkit-text-size-adjust: 100%; display: flex; -ms-flex-wrap: wrap; flex-wrap: wrap; margin-right: -15px; margin-left: -15px;">
        <div class="col-md-12" style="box-sizing: border-box; -ms-text-size-adjust: 100%; -webkit-text-size-adjust: 100%; position: relative; width: 100%; padding-right: 15px; padding-left: 15px;">
        <div class="payment-atm" style="box-sizing: border-box; -ms-text-size-adjust: 100%; -webkit-text-size-adjust: 100%; margin-top: 30px; border: 1px solid #f7863b;">
        <div class="table-responsive" style="box-sizing: border-box; -ms-text-size-adjust: 100%; -webkit-text-size-adjust: 100%; display: block; width: 100%; overflow-x: auto; -webkit-overflow-scrolling: touch;">
        <table class="table" style="box-sizing: border-box; -ms-text-size-adjust: 100%; -webkit-text-size-adjust: 100%; border-collapse: collapse; mso-table-lspace: 0pt !important; mso-table-rspace: 0pt !important; width: 100%; margin-bottom: 1rem; color: #212529;">
        <thead style="box-sizing: border-box; -ms-text-size-adjust: 100%; -webkit-text-size-adjust: 100%; background-color: #f7863b; background-image: none; background-repeat: repeat; background-position: top left; background-attachment: scroll; color: white;">
        <tr style="box-sizing: border-box; -ms-text-size-adjust: 100%; -webkit-text-size-adjust: 100%;">
        <th style="box-sizing: border-box; border-bottom-style: none; text-align: inherit; border-top-width: 1px; border-top-style: solid; border-top-color: #dee2e6; vertical-align: bottom; border-bottom-width: 2px; border-bottom-color: #dee2e6; font-family: \'montserrat\', sans-serif; padding: .75rem;">ATM Bank Sahabat Sampoerna</th>
        </tr>
        </thead>
        </table>
        </div>
        <div class="primary-list mt-25" style="box-sizing: border-box; -ms-text-size-adjust: 100%; -webkit-text-size-adjust: 100%;">
        <ol style="box-sizing: border-box; margin-top: 0; margin-bottom: 1rem; font-family: \'montserrat\', sans-serif; font-size: 14px; line-height: 1.5; color: #555;">
        <li style="box-sizing: border-box; -ms-text-size-adjust: 100%; -webkit-text-size-adjust: 100%;">Pilih Menu Transaksi</li>
        <li style="box-sizing: border-box; -ms-text-size-adjust: 100%; -webkit-text-size-adjust: 100%;">Pilih Lainnya</li>
        <li style="box-sizing: border-box; -ms-text-size-adjust: 100%; -webkit-text-size-adjust: 100%;">Pilih Transfer</li>
        <li style="box-sizing: border-box; -ms-text-size-adjust: 100%; -webkit-text-size-adjust: 100%;">Pilih Transfer ke Bank Sahabat Sampoerna</li>
        <li style="box-sizing: border-box; -ms-text-size-adjust: 100%; -webkit-text-size-adjust: 100%;">Input Virtual Account Number {$nova}</li>
        <li style="box-sizing: border-box; -ms-text-size-adjust: 100%; -webkit-text-size-adjust: 100%;">Input Nominal</li>
        <li style="box-sizing: border-box; -ms-text-size-adjust: 100%; -webkit-text-size-adjust: 100%;">Select Benar</li>
        <li style="box-sizing: border-box; -ms-text-size-adjust: 100%; -webkit-text-size-adjust: 100%;">Select Ya</li>
        <li style="box-sizing: border-box; -ms-text-size-adjust: 100%; -webkit-text-size-adjust: 100%;">Ambil bukti bayar anda</li>
        <li style="box-sizing: border-box; -ms-text-size-adjust: 100%; -webkit-text-size-adjust: 100%;">Selesai</li>
        </ol>
        </div>
        </div>
        <div class="payment-atm" style="box-sizing: border-box; -ms-text-size-adjust: 100%; -webkit-text-size-adjust: 100%; margin-top: 30px; border: 1px solid #f7863b;">
        <div class="table-responsive" style="box-sizing: border-box; -ms-text-size-adjust: 100%; -webkit-text-size-adjust: 100%; display: block; width: 100%; overflow-x: auto; -webkit-overflow-scrolling: touch;">
        <table class="table" style="box-sizing: border-box; -ms-text-size-adjust: 100%; -webkit-text-size-adjust: 100%; border-collapse: collapse; mso-table-lspace: 0pt !important; mso-table-rspace: 0pt !important; width: 100%; margin-bottom: 1rem; color: #212529;">
        <thead style="box-sizing: border-box; -ms-text-size-adjust: 100%; -webkit-text-size-adjust: 100%; background-color: #f7863b; background-image: none; background-repeat: repeat; background-position: top left; background-attachment: scroll; color: white;">
        <tr style="box-sizing: border-box; -ms-text-size-adjust: 100%; -webkit-text-size-adjust: 100%;">
        <th style="box-sizing: border-box; border-bottom-style: none; text-align: inherit; border-top-width: 1px; border-top-style: solid; border-top-color: #dee2e6; vertical-align: bottom; border-bottom-width: 2px; border-bottom-color: #dee2e6; font-family: \'montserrat\', sans-serif; padding: .75rem;">Mobile Banking Bank Sahabat Sampoerna</th>
        </tr>
        </thead>
        </table>
        </div>
        <div class="primary-list mt-25" style="box-sizing: border-box; -ms-text-size-adjust: 100%; -webkit-text-size-adjust: 100%;">
        <ol style="box-sizing: border-box; margin-top: 0; margin-bottom: 1rem; font-family: \'montserrat\', sans-serif; font-size: 14px; line-height: 1.5; color: #555;">
        <li style="box-sizing: border-box; -ms-text-size-adjust: 100%; -webkit-text-size-adjust: 100%;">Login Mobile Banking</li>
        <li style="box-sizing: border-box; -ms-text-size-adjust: 100%; -webkit-text-size-adjust: 100%;">Pilih Transfer Dana</li>
        <li style="box-sizing: border-box; -ms-text-size-adjust: 100%; -webkit-text-size-adjust: 100%;">Pilih Transfer ke Antar Bank</li>
        <li style="box-sizing: border-box; -ms-text-size-adjust: 100%; -webkit-text-size-adjust: 100%;">Input kode Bank Sahabat yaitu 523</li>
        <li style="box-sizing: border-box; -ms-text-size-adjust: 100%; -webkit-text-size-adjust: 100%;">Pilih Ya</li>
        <li>Input Nomor Virtual Account {$nova}</li>
        <li style="box-sizing: border-box; -ms-text-size-adjust: 100%; -webkit-text-size-adjust: 100%;">Input Nominal</li>
        <li style="box-sizing: border-box; -ms-text-size-adjust: 100%; -webkit-text-size-adjust: 100%;">Input token M-Banking anda</li>
        <li style="box-sizing: border-box; -ms-text-size-adjust: 100%; -webkit-text-size-adjust: 100%;">Bukti bayar ditampilkan</li>
        <li style="box-sizing: border-box; -ms-text-size-adjust: 100%; -webkit-text-size-adjust: 100%;">Selesai</li>
        </ol>
        </div>
        </div>
        <div class="payment-atm" style="box-sizing: border-box; -ms-text-size-adjust: 100%; -webkit-text-size-adjust: 100%; margin-top: 30px; border: 1px solid #f7863b;">
        <div class="table-responsive" style="box-sizing: border-box; -ms-text-size-adjust: 100%; -webkit-text-size-adjust: 100%; display: block; width: 100%; overflow-x: auto; -webkit-overflow-scrolling: touch;">
        <table class="table" style="box-sizing: border-box; -ms-text-size-adjust: 100%; -webkit-text-size-adjust: 100%; border-collapse: collapse; mso-table-lspace: 0pt !important; mso-table-rspace: 0pt !important; width: 100%; margin-bottom: 1rem; color: #212529;">
        <thead style="box-sizing: border-box; -ms-text-size-adjust: 100%; -webkit-text-size-adjust: 100%; background-color: #f7863b; background-image: none; background-repeat: repeat; background-position: top left; background-attachment: scroll; color: white;">
        <tr style="box-sizing: border-box; -ms-text-size-adjust: 100%; -webkit-text-size-adjust: 100%;">
        <th style="box-sizing: border-box; border-bottom-style: none; text-align: inherit; border-top-width: 1px; border-top-style: solid; border-top-color: #dee2e6; vertical-align: bottom; border-bottom-width: 2px; border-bottom-color: #dee2e6; font-family: \'montserrat\', sans-serif; padding: .75rem;">Internet Banking Bank Sahabat Sampoerna</th>
        </tr>
        </thead>
        </table>
        </div>
        <div class="primary-list mt-25" style="box-sizing: border-box; -ms-text-size-adjust: 100%; -webkit-text-size-adjust: 100%;">
        <ol style="box-sizing: border-box; margin-top: 0; margin-bottom: 1rem; font-family: \'montserrat\', sans-serif; font-size: 14px; line-height: 1.5; color: #555;">
        <li style="box-sizing: border-box; -ms-text-size-adjust: 100%; -webkit-text-size-adjust: 100%;">Login Internet Banking</li>
        <li style="box-sizing: border-box; -ms-text-size-adjust: 100%; -webkit-text-size-adjust: 100%;">Pilih Transfer Dana</li>
        <li style="box-sizing: border-box; -ms-text-size-adjust: 100%; -webkit-text-size-adjust: 100%;">Pilih Transfer ke Rekening Bank Sahabat Sampoerna</li>
        <li style="box-sizing: border-box; -ms-text-size-adjust: 100%; -webkit-text-size-adjust: 100%;">Input Nomor Virtual Account {$nova}</li>
        <li style="box-sizing: border-box; -ms-text-size-adjust: 100%; -webkit-text-size-adjust: 100%;">Input Nominal</li>
        <li style="box-sizing: border-box; -ms-text-size-adjust: 100%; -webkit-text-size-adjust: 100%;">Input token i-Banking anda</li>
        <li style="box-sizing: border-box; -ms-text-size-adjust: 100%; -webkit-text-size-adjust: 100%;">Bukti bayar akan ditampilkan</li>
        <li style="box-sizing: border-box; -ms-text-size-adjust: 100%; -webkit-text-size-adjust: 100%;">Selesai</li>
        </ol>
        </div>
        </div>
        </div>
        </div>
        </div>
        </div>
        <div class="email-section bg_white" style="box-sizing: border-box; -ms-text-size-adjust: 100%; -webkit-text-size-adjust: 100%; background-color: #ffffff; background-image: none; background-repeat: repeat; background-position: top left; background-attachment: scroll; padding-top: 30px; padding-bottom: 30px;">
        <div class="container" style="box-sizing: border-box; -ms-text-size-adjust: 100%; -webkit-text-size-adjust: 100%; width: 100%; padding-right: 15px; padding-left: 15px; margin-right: auto; margin-left: auto;">
        <div class="row" style="box-sizing: border-box; -ms-text-size-adjust: 100%; -webkit-text-size-adjust: 100%; display: flex; -ms-flex-wrap: wrap; flex-wrap: wrap; margin-right: -15px; margin-left: -15px;">
        <div class="col-md-12" style="box-sizing: border-box; -ms-text-size-adjust: 100%; -webkit-text-size-adjust: 100%; position: relative; width: 100%; padding-right: 15px; padding-left: 15px;">
        <div class="description-email" style="box-sizing: border-box; -ms-text-size-adjust: 100%; -webkit-text-size-adjust: 100%;">
        <h6 style="box-sizing: border-box; -ms-text-size-adjust: 100%; -webkit-text-size-adjust: 100%; margin-bottom: .5rem; font-weight: 500; line-height: 1.2; font-size: 1rem; font-family: \'montserrat\', sans-serif; color: #000000; margin-top: 0;">Catatan</h6>
        <p style="box-sizing: border-box; margin-top: 0; margin-bottom: 1rem; font-size: 14px; font-family: \'montserrat\', sans-serif; line-height: 1.5; color: #555;">Metode Pembayaran Virtual Account tidak diperuntukan melalui Teller.</p>
        </div>
        </div>
        </div>
        </div>
        </div>
        '; 
    }

    private function getEmailTemplates()
    {
        $data = [];
        $data[""] = "-- None --";
        $emailTemplates = DB::table("tblemailtemplates")->where(["type" => "invoice", "custom" => "1"])->get();
        foreach ($emailTemplates as $emailTemplate) {
            $data[$emailTemplate->name] = $emailTemplate->name;
        }

        return $data;
    }
}
