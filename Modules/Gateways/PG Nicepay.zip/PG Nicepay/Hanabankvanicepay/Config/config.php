<?php

return [
    'name' => 'Hanabankvanicepay'
];
